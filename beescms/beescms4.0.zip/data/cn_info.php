<?php
$_confing=array (
  'web_name' => 'BEES企业网站管理系统_企业建站系统_外贸网站建设_企业CMS_PHP营销企业网站模板_免费开源的PHP企业网站程序',
  'web_index_name' => 'BEES企业网站管理系统_企业建站系统_外贸网站建设_企业CMS_PHP营销企业网站模板_免费开源的PHP企业网站程序',
  'web_rewrite' => '0',
  'is_cache' => '0',
  'cache_time' => '30',
  'web_logo' => 'img/20121210/201212102144457490.gif',
  'web_template' => 'default',
  'phone_template' => 'default_phone',
  'web_powerby' => 'BEESCMS企业网站管理系统_企业网站制作更便利,企业网站建设和管理更方便<br>
空间域名QQ：2429256177 <br>',
  'web_tongji' => '',
  'web_keywords' => '',
  'web_description' => 'BEES企业网站管理系统，是一套模板程序完全分离，采用PHP+MYSQL技术开发，具备强大的SEO功能，简单操作的自助建站系统，只要会打字就能建设企业网站，更有免费营销企业网站模板提供下载，是建设外贸网站，公司企业网站的好助手',
  'web_yinxiao' => '',
  'hot_key' => 'BEESCMS|教程|帮助|企业网站程序',
  'all_key' => '企业网站|BEESCMS|程序|使用帮助',
  'nav' => 'websys',
  'admin_p_nav' => 'allsys',
);
?>