<?php
$admin_group=array (
  0 => 
  array (
    'id' => '2',
    'admin_group_name' => '信息发布员 ',
    'admin_group_info' => '发布信息内容的管理员',
    'admin_group_purview' => 'content_create,content_edit',
    'is_disable' => '0',
  ),
  1 => 
  array (
    'id' => '1',
    'admin_group_name' => '超级管理员',
    'admin_group_info' => '可以管理后台所有功能，没有任何限制',
    'admin_group_purview' => 'all_purview',
    'is_disable' => '0',
  ),
);?>