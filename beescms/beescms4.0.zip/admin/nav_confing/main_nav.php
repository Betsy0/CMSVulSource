<?php
/**
 * $Author: BEESCMS $
 * ============================================================================
 * 网站地址: http://www.beescms.com
 * 您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
*/
$admin_main_nav=array(
	 array('main_nav'=>'index','name'=>'首页'),
	 array('main_nav'=>'sys','name'=>'设置'),
	 array('main_nav'=>'category','name'=>'栏目'),
	 array('main_nav'=>'content','name'=>'内容'),
	 array('main_nav'=>'tpl','name'=>'模板'),
	 array('main_nav'=>'html','name'=>'生成'),
	 array('main_nav'=>'feeds','name'=>'反馈'),
	 array('main_nav'=>'user','name'=>'用户'),
	 array('main_nav'=>'lang','name'=>'语言'),
	 array('main_nav'=>'tools','name'=>'工具')
)
?>
