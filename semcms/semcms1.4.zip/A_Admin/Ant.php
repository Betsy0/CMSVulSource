<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>© SEMCMS外贸网站商城管理系统</title>
</head>
<frameset rows="*" cols="200,85%" framespacing="0" frameborder="no" border="0">
  <frame src="Ant_left.php"  name="leftFrame" scrolling="auto" noresize="noresize" id="leftFrame" title="leftFrame" />
  <frameset rows="70,90%" cols="*" framespacing="0" border="0">
    <frame src="Ant_top.php" name="topFrame" scrolling="No" noresize="noresize" id="topFrame" title="topFrame" />
    <frame src="Ant_mid.php" name="mainFrame" id="mainFrame" />
  </frameset>
</frameset>
<noframes><body>
</body></noframes>
</html>
 