<?php
ini_set('display_errors','off');
!defined('DB_CHARSET') && define('DB_CHARSET','utf8');  // 数据库保存编码, 不可缺少
header('Content-Type:text/html; charset=utf-8' );      // 本程序执行编码

if(strpos($_SERVER["SERVER_SOFTWARE"],'Apache') !== false){
}else{
	 echo '<script language="javascript">alert(\'您好,您的系统不支持Apache,请更换运行环境\');</script>';
	 echo '<font color="red">您好,您的系统不支持Apache,请更换运行环境,本系统需支持 php5.6 + mysql 5.6 + Apache 否则会影响功能使用！</a>';
	 exit;
}
 
if(isset($_GET['type'])){
	$type=$_GET['type'];
}else{
	$type="";
}
if ($type=="cs"){
	$post=$_POST;
	//连接mysql错误：'.mysqli_connect_error().
	 $conn = mysqli_connect($post['dbhost'],$post['dbuser'],$post['dbpw']);
	 if ($conn){
	 	echo '数据库链接成功!';
	 }else{
	 	echo '连接mysql错误,请检查数据库账号密码';
	 	exit;
	 }
	 
}elseif ($type=="install") {
	$post=$_POST;
	$sql_file = dirname(__FILE__)."/scshop.sql";
	run_sql_file($sql_file,$post);

}elseif ($type=="installcom"){
   	//重命名后台路径
    run_rename();
	//删除安装文件
	delDirAndFile(dirname(__FILE__));
	// 安装完成
	echo "<li class='nextstep'>恭喜安装完成。<br>注意 : 如果install目录没有清除,请手动清除！</li>";
	 
}

/* 执行mysql数据文件.参数:数据文件,数据库账号信息 */

function run_sql_file($sql_file,$dbconfig){
 
	$host = $dbconfig['dbhost'];
	$dbname = $dbconfig['dbname'];
	$user = $dbconfig['dbuser'];
	$pwd = $dbconfig['dbpw'];
	if (isset($dbconfig['mk_newdb'])){
		$mknew=$dbconfig['mk_newdb'];
	}else{
		$mknew="";
	}
	

	// 连接mysql数据库
	$conn = mysqli_connect($host,$user,$pwd) or die( '失败:连接mysql错误,请检查数据库账号密码');
	if ($mknew==1){ //如果选择新建 执行下面两句
	// 删除旧的数据库 
	 mysqli_query($conn,"DROP database IF EXISTS {$dbname} ;") or die ("失败:重新建立新的数据库 操作失败，无法删除【旧】数据库, 请检查mysql操作权限"); 
	// 重新建立新数据库
	 mysqli_query($conn,"CREATE DATABASE {$dbname} CHARACTER SET ".DB_CHARSET." ;" ) or die ("失败:无法创建数据库, 请检查mysql操作权限"); 
	}
	// 选择数据库
	mysqli_select_db($conn,$dbname) or die("<li>失败:没有找到接数据库名 {$dbname} ,请选新建选项</li>");
	/* ############ 数据文件分段执行 ######### */
	$sql_str = file_get_contents($sql_file);
	$piece = array(); // 数据段
	preg_match_all("@([\s\S]+?;)\h*[\n\r]@",$sql_str,$piece); // 数据以分号;\n\r换行  为分段标记
	!empty( $piece[1] ) && $piece = $piece[1];
	$count = count($piece);
	if ( $count <= 0 ){
		exit('失败:mysql数据文件: '. $sql_file .' , 不是正确的数据文件,请检查安装包.');
	}
	$tb_list = array(); // 表名列表
	preg_match_all( '@CREATE\h+TABLE\h+[`]?([^`]+)[`]?@',$sql_str,$tb_list );
	!empty( $tb_list[1] ) && $tb_list = $tb_list[1];
	$tb_count = count($tb_list);

	// 开始循环执行
	for($i=0;$i<$count ;$i++){
		$sql = $piece[$i] ;
		mysqli_query($conn,"SET character_set_connection='".DB_CHARSET."', character_set_results='".DB_CHARSET."', character_set_client='binary'");
		$result = mysqli_query($conn,$sql);
		// 建表数量
		if ($i < $tb_count) {
			echo "<li>创建表: ".$tb_list[$i];
			if($result){
				 echo " <font color='green'>成功安装</font> ......</li>";		
			}else {
				 echo "<font color='red'>失败</font> , 原因:".mysqli_error($conn)."-> 解决方法 : 清除数据库内容 或 新建数据库名勾选! <font color=red>->或者MYSQL数据库版本不对:需5.6+版本</font></li>";
			}
		}
		// // 执行其它语句
		// else {
		// 	if(!$result){

		// 		echo "<li>sql语句执行<font color='red'>失败</font> , 原因:".mysqli_error($conn)."</li>";
		// 	}
		// }
	}

		//更改数据库配置文件
        $template_o = file_get_contents('Sample_db_conn.php');
        $templateUrl = '../Core/Program/db_con.php';
        $output = str_replace('<{dataurl>}',$host, $template_o);
        $output = str_replace('<{datauser}>', $user, $output);
        $output = str_replace('<{datapassword>}',$pwd, $output);
        $output = str_replace('<{dataname>}', $dbname, $output);
        if(file_put_contents($templateUrl, $output)==false){
        	echo "<li><font color='red'>无法修改数据库配置文件，请手动修改。</font></li>";
        }   
}

function run_rename(){
        //更改后台路径 ->随机生成
		      $ht_filename="";
		      function Randkey($length){
				$key="";
			    $pattern = '1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLOMNOPQRSTUVWXYZ';
			    for($i=0;$i<$length;$i++){

			        $key.=$pattern[rand(0,61)];
			    } 
			     return $key;
		     } 
		    $ht_filename=Randkey(6);
		    $ht_lastname=Randkey(2);
        if(rename('../A_Admin','../'.$ht_filename.'_A'.$ht_lastname)){
        	echo"<li class='nextstep'><font color=green>请牢记以下信息(先复制以下内容)</font><br><font color='red'>网站后台地址为 : 你的域名+".$ht_filename."_A".$ht_lastname."/</font><br><font color='red'>后台默认帐户: Admin 密码 : semcms (登陆后进行修改)</font></li><li class='nextstep'><span><a href='../".$ht_filename."_A".$ht_lastname."/'>点击转到后台</a></span>  <span><a href='../'>点击转到首页</a></span></li>";
        } else{
        	echo "<li class='nextstep'><font color=red>无法修改后台路径,请查看文件夹A_Admin权限,或手动更改A_Admin名称</font></li>";
        	echo"<li class='nextstep'><font color=green>请牢记以下信息(先复制以下内容)</font><br><font color='red'>网站后台地址为 : 你的域名+A_Admin/ </font><br><font color='red'>后台默认帐户: Admin 密码 : semcms (登陆后进行修改)</font></li><li class='nextstep'><span><a href='../A_Admin/'>点击转到后台</span></a> <span><a href='../'>点击转到首页</a></span></li>";
        }
        
}

// 删除安装文件
function delDirAndFile($dirName){
		if ($handle = opendir("$dirName" )){
		while (false !== ( $item = readdir( $handle ))) {
			if ($item != "." && $item != ".." ) {
				if (is_dir("$dirName/$item")){
					delDirAndFile("$dirName/$item");
				}else{
					if( unlink("$dirName/$item") )echo "<li class='nextstep'>成功删除文件: $dirName/$item</li>";
				}
			}
		}
		closedir($handle);
		if(rmdir($dirName)) echo "<li class='nextstep'>成功删除目录: $dirName</li>";
		}
}

