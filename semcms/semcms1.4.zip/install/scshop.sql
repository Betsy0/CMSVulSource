-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: 2021-09-01 14:18:41
-- 服务器版本： 5.6.35
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Tscshop`
--

-- --------------------------------------------------------

--
-- 表的结构 `sc_address`
--

CREATE TABLE `sc_address` (
  `ID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `add_firstname` char(200) DEFAULT NULL,
  `add_lastname` char(200) DEFAULT NULL,
  `add_dress` varchar(500) DEFAULT NULL,
  `add_dresstwo` char(200) DEFAULT NULL,
  `add_contry` char(200) DEFAULT NULL,
  `add_state` char(200) DEFAULT NULL,
  `add_city` char(200) DEFAULT NULL,
  `add_zipcode` char(100) DEFAULT NULL,
  `add_company` char(200) DEFAULT NULL,
  `add_tel` char(200) DEFAULT NULL,
  `add_default` char(10) DEFAULT '0' COMMENT '默认地址设定',
  `add_type` char(20) DEFAULT '' COMMENT '地址类型 0:ship 1:共用 2:bild',
  `add_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sc_address`
--

INSERT INTO `sc_address` (`ID`, `userID`, `add_firstname`, `add_lastname`, `add_dress`, `add_dresstwo`, `add_contry`, `add_state`, `add_city`, `add_zipcode`, `add_company`, `add_tel`, `add_default`, `add_type`, `add_time`) VALUES
(3, 2, 'SEM', 'CMS', '188# JinQing JiaoJiang', NULL, '45', 'Zhejiang', 'TaiZhou', '310000', 'SEMCMS CO.,LTD', '13812345678', '0', '', '2021-03-10 07:18:57');

-- --------------------------------------------------------

--
-- 表的结构 `sc_banner`
--

CREATE TABLE `sc_banner` (
  `ID` int(11) NOT NULL,
  `ant_img` varchar(200) DEFAULT NULL,
  `banner_url` varchar(200) DEFAULT NULL,
  `banner_fenlei` varchar(50) DEFAULT NULL,
  `languageID` int(11) DEFAULT NULL,
  `banner_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `banner_paixu` int(11) DEFAULT '10000'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sc_banner`
--

INSERT INTO `sc_banner` (`ID`, `ant_img`, `banner_url`, `banner_fenlei`, `languageID`, `banner_time`, `banner_paixu`) VALUES
(2, '../Images/banner/210309053051_8928.jpg,', 'https://www.semcms.cn/', '3', 1, '2021-03-10 09:45:31', 10000),
(5, '../Images/banner/210309030324_1964.jpg,', '#', '1', 1, '2021-03-09 07:03:40', 10000),
(6, '../Images/banner/210309053144_5378.jpg,', '#', '3', 1, '2021-03-09 09:31:51', 10000);

-- --------------------------------------------------------

--
-- 表的结构 `sc_blogcat`
--

CREATE TABLE `sc_blogcat` (
  `ID` int(11) NOT NULL,
  `b_name` char(200) DEFAULT NULL COMMENT '分类名称',
  `b_title` char(200) DEFAULT NULL COMMENT '分类meate标签',
  `b_key` char(200) DEFAULT NULL COMMENT '分类keywords',
  `b_des` char(220) DEFAULT NULL COMMENT '分类des',
  `b_sortdes` varchar(500) DEFAULT NULL COMMENT '分类概况',
  `contents` text COMMENT '详细描述',
  `b_open` int(11) DEFAULT '1' COMMENT '是否显示',
  `b_url` char(200) DEFAULT NULL COMMENT '自定 url',
  `b_paixu` int(11) DEFAULT '1000' COMMENT '排序',
  `b_tj` int(11) DEFAULT '0' COMMENT '推荐',
  `ant_img` char(200) DEFAULT NULL COMMENT '图片',
  `languageID` int(11) DEFAULT NULL,
  `b_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '添加时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sc_blogcat`
--

INSERT INTO `sc_blogcat` (`ID`, `b_name`, `b_title`, `b_key`, `b_des`, `b_sortdes`, `contents`, `b_open`, `b_url`, `b_paixu`, `b_tj`, `ant_img`, `languageID`, `b_time`) VALUES
(3, 'Smart Watch', 'Smart Watch', 'Smart Watch', 'Smart Watch', 'Smart Watch', 'Smart Watch', 1, 'Smart-Watch', 104, 1, NULL, 1, '2021-03-09 07:47:46'),
(4, 'Smart Watches', 'Smart Watch', 'Smart Watch', 'Smart Watch', 'Smart Watch', 'Smart Watch', 1, 'SmartWatch', 10000, 0, NULL, 1, '2021-03-09 07:48:48');

-- --------------------------------------------------------

--
-- 表的结构 `sc_categories`
--

CREATE TABLE `sc_categories` (
  `ID` int(11) NOT NULL,
  `category_mtitle` char(200) DEFAULT NULL,
  `category_name` char(100) DEFAULT NULL,
  `category_pid` int(11) DEFAULT NULL,
  `category_path` char(200) DEFAULT NULL,
  `category_key` char(200) DEFAULT NULL,
  `category_des` char(240) DEFAULT NULL,
  `category_sortdes` char(220) DEFAULT NULL,
  `contents` text,
  `ant_img` varchar(250) DEFAULT NULL,
  `category_url` char(100) DEFAULT NULL,
  `category_paixu` int(11) DEFAULT '0',
  `category_open` int(11) DEFAULT '1',
  `category_tj` int(11) DEFAULT '0',
  `onlyid` char(50) DEFAULT NULL,
  `category_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `languageID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sc_categories`
--

INSERT INTO `sc_categories` (`ID`, `category_mtitle`, `category_name`, `category_pid`, `category_path`, `category_key`, `category_des`, `category_sortdes`, `contents`, `ant_img`, `category_url`, `category_paixu`, `category_open`, `category_tj`, `onlyid`, `category_time`, `languageID`) VALUES
(1, 'Smart Watch', 'Smart Watch', 0, '0,1,', 'Smart Watch', 'Smart Watch', 'Smart Watch', 'Semcms is very suitable for foreign trade enterprises and E-commerce Internet applications. Since its first release in December 2009, semcms has continuously expanded its share of foreign trade market by relying on excellent user experience and leading technology.', '../Images/catalog/210308034500_4495.jpg,', 'Smart-Watch', 10000, 1, 1, '72986045d55daa5717936', '2021-03-08 07:45:02', 1),
(2, '', 'A-Smart Watch', 0, '0,2,', '', '', '', '', '../Images/catalog/210309054730_8073.jpg,', 'A-Smart-Watch', 10000, 1, 1, '538560474422e1a534085', '2021-03-09 09:47:43', 1),
(3, '', 'B-Smart Watch', 0, '0,3,', '', '', '', '', '../Images/catalog/210309054803_1637.jpg,', 'B-SmartWatch', 10000, 1, 1, '361760474444e49966397', '2021-03-09 09:48:15', 1),
(4, '', 'C-Smart Watch', 0, '0,4,', '', '', '', '', '../Images/catalog/210309054832_5544.jpg,', 'C-Smart-Watch', 10000, 1, 1, '7909604744648c5194309', '2021-03-09 09:48:40', 1),
(8, 'D Smart Watch', 'D Smart Watch', 0, '0,8,', 'hello world,hello china', 'D Smart Watch ,hello world,hello china', 'D Smart Watch', 'D Smart Watch &lt;br /&gt;\r\n&lt;br /&gt;', '../Images/catalog/abc-001_7718.jpg,', 'D-Smart-Watch', 10000, 1, 0, '356560485ed2a1f3f8425', '2021-03-10 06:00:36', 1),
(9, 'Smart Watch 2', 'Smart Watch 2', 8, '0,8,9,', 'Smart Watch 2', 'Smart Watch 2', 'Smart Watch 2', 'Smart Watch 2', '../Images/catalog/210310020145_2769.jpg,', 'Smart-Watch-2', 10000, 1, 0, '4731604860b8ac18e5423', '2021-03-10 06:02:03', 1),
(10, 'Smart Watch 2', 'Smart Watch 3', 9, '0,8,9,10,', 'Smart Watch 2', 'Smart Watch 2', 'Smart Watch 2', 'Smart Watch 2', '../Images/catalog/210310020235_3158.jpg,', 'Smart-Watch-4', 10000, 1, 0, '415604860f31eaa34498', '2021-03-10 06:02:51', 1);

-- --------------------------------------------------------

--
-- 表的结构 `sc_config`
--

CREATE TABLE `sc_config` (
  `ID` int(11) NOT NULL,
  `web_name` char(100) DEFAULT NULL,
  `web_url` char(100) DEFAULT NULL,
  `web_logo` char(100) DEFAULT NULL,
  `web_ico` char(100) DEFAULT NULL,
  `web_copy` text,
  `web_email` char(100) DEFAULT NULL,
  `web_otherct` varchar(1000) DEFAULT NULL,
  `web_wathsapp` char(100) DEFAULT NULL,
  `web_tel` char(100) DEFAULT NULL,
  `web_plist` int(11) DEFAULT NULL,
  `web_nlist` int(11) DEFAULT NULL,
  `web_inlist` int(11) DEFAULT '0' COMMENT '新',
  `web_iflist` int(11) DEFAULT '0' COMMENT '推',
  `web_itlist` int(11) NOT NULL DEFAULT '0' COMMENT '特',
  `web_irlist` int(11) DEFAULT '0' COMMENT '人气',
  `web_meate` varchar(1000) DEFAULT NULL,
  `web_google` varchar(5000) DEFAULT NULL,
  `web_share` varchar(2000) DEFAULT NULL,
  `web_shejiao` varchar(1000) DEFAULT NULL,
  `web_umail` char(100) DEFAULT NULL,
  `web_pmail` char(100) DEFAULT NULL,
  `web_dmail` char(20) DEFAULT NULL,
  `web_smail` char(100) DEFAULT NULL,
  `web_tmail` char(100) DEFAULT NULL,
  `web_jmail` char(100) DEFAULT NULL,
  `web_mailopen` int(11) NOT NULL DEFAULT '0',
  `web_jtopen` int(11) DEFAULT '0',
  `web_zsyopen` int(11) DEFAULT '0',
  `web_duo` int(11) NOT NULL DEFAULT '0',
  `web_Template` varchar(50) DEFAULT NULL,
  `web_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `web_https` int(11) NOT NULL DEFAULT '0',
  `web_prices` char(10) DEFAULT '5',
  `web_add` char(200) DEFAULT NULL,
  `web_cp` varchar(500) DEFAULT NULL,
  `web_sc` char(200) DEFAULT NULL,
  `web_zg` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sc_config`
--

INSERT INTO `sc_config` (`ID`, `web_name`, `web_url`, `web_logo`, `web_ico`, `web_copy`, `web_email`, `web_otherct`, `web_wathsapp`, `web_tel`, `web_plist`, `web_nlist`, `web_inlist`, `web_iflist`, `web_itlist`, `web_irlist`, `web_meate`, `web_google`, `web_share`, `web_shejiao`, `web_umail`, `web_pmail`, `web_dmail`, `web_smail`, `web_tmail`, `web_jmail`, `web_mailopen`, `web_jtopen`, `web_zsyopen`, `web_duo`, `web_Template`, `web_time`, `web_https`, `web_prices`, `web_add`, `web_cp`, `web_sc`, `web_zg`) VALUES
(1, 'semcms', 'http://127.0.0.1/', '../Images/other/210228031021_8062.png', '../Images/other/favicon_8356.ico', 'CopyRight SEMCMS 2002-2021 sem-cms.cn  ©', 'service@sem-cms.com', '&lt;li&gt;&lt;i class=&quot;fa fa fa-envelope-o&quot;&gt;&lt;/i&gt; &lt;a href=&#039;mailto:info@sem-cms.com&#039;&gt;info@sem-cms.com&lt;/a&gt;&lt;/li&gt;\r\n&lt;li&gt;&lt;i class=&quot;fa fa-skype&quot; aria-hidden=&quot;true&quot;&gt;&lt;/i&gt; &lt;a href=&#039;skype:semcms?chat&#039;&gt;semcms&lt;/a&gt;&lt;/li&gt;\r\n&lt;li&gt;&lt;i class=&quot;fa fa-whatsapp&quot; aria-hidden=&quot;true&quot;&gt;&lt;/i&gt; 86-13812345678&lt;/li&gt;\r\n&lt;li&gt;&lt;i class=&quot;fa fa-phone fa-lg&quot;&gt;&lt;/i&gt; 86-0576-81234567&lt;/li&gt;', '13812345678', '+86（0576）88888888', 100, 27, 8, 8, 8, 8, '&lt;meta name=&quot;viewport&quot; content=&quot;width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=no&quot;/&gt;\r\n&lt;meta name=&quot;apple-mobile-web-app-capable&quot; content=&quot;yes&quot; /&gt;', '', '&lt;script type=&quot;text/javascript&quot; src=&quot;//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-58c4eabb859efec7&quot;&gt;&lt;/script&gt;\r\nShare:&lt;div class=&quot;addthis_inline_share_toolbox&quot;&gt;&lt;/div&gt;', '&lt;i class=&quot;fa fa-facebook-square&quot; aria-hidden=&quot;true&quot;&gt;&lt;/i&gt;\r\n&lt;i class=&quot;fa fa-linkedin-square&quot; aria-hidden=&quot;true&quot;&gt;&lt;/i&gt;\r\n&lt;i class=&quot;fa fa-tumblr-square&quot; aria-hidden=&quot;true&quot;&gt;&lt;/i&gt;\r\n&lt;i class=&quot;fa fa-google-plus-square&quot; aria-hidden=&quot;true&quot;&gt;&lt;/i&gt;', 'service@sem-cms.com', '1234567890', '465', 'smtp.exmail.qq.com', 'service@sem-cms.com', '1181698019@qq.com', 0, 1, 1, 1, 'Default', '2021-03-16 13:08:46', 0, '5', '3# pingshuixijie xihuqu hangzhou,zhejian,china 310000', 'LE0CcJ0S0VCMPZUQeMIAMW2KSFhxkWzNjd044I05jZmdbI0SvHCJcdflhYkEMZ1GfF0S2L-FOZTdfYooOLWOSHUKvYftVcjlyFJJgaFyS7QG4VDFjbD5fYExNX1mUHhm2VDdjME9tZFpSXl6h3VKraSQpPEt2Fl1fW1-d7A6oXi1jQQctVV0r', 'NZoVta21z', 'vdeprgaLuJ7Vjtu6V1ANpIEmO%3Du4vID1SI0YO8cqIOqsk');

-- --------------------------------------------------------

--
-- 表的结构 `sc_country`
--

CREATE TABLE `sc_country` (
  `ID` int(11) NOT NULL COMMENT '自增ID',
  `country_name` char(128) NOT NULL COMMENT '国家名称',
  `country_code_2` char(5) NOT NULL COMMENT '二位国家码',
  `country_code_3` char(5) NOT NULL COMMENT '三位国家码',
  `country_paixu` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `country_cn_name` char(64) DEFAULT NULL COMMENT '中文名称',
  `country_code` char(10) DEFAULT NULL COMMENT '电话区号',
  `country_flag` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态 #0隐藏 #1显示',
  `expressid` varchar(1000) DEFAULT ',' COMMENT '物流ID',
  `deliveryid` varchar(1000) DEFAULT ',' COMMENT '物流方式ID',
  `ant_img` char(100) DEFAULT NULL,
  `exprssyf` char(100) DEFAULT '0' COMMENT '最低消费免运费'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- 转存表中的数据 `sc_country`
--

INSERT INTO `sc_country` (`ID`, `country_name`, `country_code_2`, `country_code_3`, `country_paixu`, `country_cn_name`, `country_code`, `country_flag`, `expressid`, `deliveryid`, `ant_img`, `exprssyf`) VALUES
(1, 'Afghanistan', 'AF', 'AFG', 602, '阿富汗', '93', 1, ',2,4,', '', '../Images/country/AF.gif', '100'),
(2, 'Aland Islands', 'AX', 'ALA', 601, '奥兰群岛', '358', 1, ',2,4,', '', '../Images/country/AX.gif', '0'),
(3, 'Albania', 'AL', 'ALB', 397, '阿尔巴尼亚', '355', 1, ',2,4,', '', '../Images/country/AL.gif', '0'),
(4, 'Algeria', 'DZ', 'DZA', 396, '阿尔及利亚', '213', 1, ',2,4,', '', '../Images/country/DZ.gif', '0'),
(5, 'American Samoa', 'AS', 'ASM', 395, '美属萨摩亚', '1684', 1, ',2,4,', '', '../Images/country/AS.gif', '0'),
(6, 'Andorra', 'AD', 'AND', 394, '安道尔', '376', 1, ',2,4,', '', '../Images/country/AD.gif', '0'),
(7, 'Angola', 'AO', 'AGO', 393, '安哥拉', '244', 1, ',2,4,', '', '../Images/country/AO.gif', '0'),
(8, 'Anguilla', 'AI', 'AIA', 392, '安圭拉', '1264', 1, ',2,4,', '', '../Images/country/AI.gif', '0'),
(9, 'Antarctica', 'AQ', 'ATA', 391, '南极洲', '672', 1, ',2,4,', '', '../Images/country/AQ.gif', '0'),
(10, 'Antigua And Barbuda', 'AG', 'ATG', 390, '安提瓜和巴布达', '1268', 1, ',2,4,', '', '../Images/country/AG.gif', '0'),
(11, 'Argentina', 'AR', 'ARG', 389, '阿根廷', '54', 1, ',2,4,', '', '../Images/country/AR.gif', '0'),
(12, 'Armenia', 'AM', 'ARM', 388, '亚美尼亚', '374', 1, ',2,4,', '', '../Images/country/AM.gif', '0'),
(13, 'Aruba', 'AW', 'ABW', 387, '阿鲁巴', '297', 1, ',2,4,', '', '../Images/country/AW.gif', '0'),
(14, 'Australia', 'AU', 'AUS', 386, '澳大利亚', '61', 1, ',2,4,', '', '../Images/country/AU.gif', '0'),
(15, 'Austria', 'AT', 'AUT', 385, '奥地利', '43', 1, ',2,4,', '', '../Images/country/AT.gif', '0'),
(16, 'Azerbaijan', 'AZ', 'AZE', 384, '阿塞拜疆', '994', 1, ',2,4,', '', '../Images/country/AZ.gif', '0'),
(17, 'Bahamas', 'BS', 'BHS', 383, '巴哈马', '1242', 1, ',2,4,', '', '../Images/country/BS.gif', '0'),
(18, 'Bahrain', 'BH', 'BHR', 382, '巴林', '973', 1, ',2,4,', '', '../Images/country/BH.gif', '0'),
(19, 'Bangladesh', 'BD', 'BGD', 381, '孟加拉国', '880', 1, ',2,4,', '', '../Images/country/BD.gif', '0'),
(20, 'Barbados', 'BB', 'BRB', 380, '巴巴多斯', '1246', 1, ',2,4,', '', '../Images/country/BB.gif', '0'),
(21, 'Belarus', 'BY', 'BLR', 379, '白俄罗斯', '375', 1, ',2,4,', '', '../Images/country/BY.gif', '0'),
(22, 'Belgium', 'BE', 'BEL', 378, '比利时', '32', 1, ',2,4,', '', '../Images/country/BE.gif', '0'),
(23, 'Belize', 'BZ', 'BLZ', 377, '伯利兹', '501', 1, ',2,4,', '', '../Images/country/BZ.gif', '0'),
(24, 'Benin', 'BJ', 'BEN', 376, '贝宁', '229', 1, ',2,4,', '', '../Images/country/BJ.gif', '0'),
(25, 'Bermuda', 'BM', 'BMU', 375, '百慕大', '1441', 1, ',2,4,', '', '../Images/country/BM.gif', '0'),
(26, 'Bhutan', 'BT', 'BTN', 374, '不丹', '975', 1, ',2,4,', '', '../Images/country/BT.gif', '0'),
(27, 'Bolivia', 'BO', 'BOL', 373, '玻利维亚', '591', 1, ',2,4,', '', '../Images/country/BO.gif', '0'),
(28, 'Bosnia And Herzegovina', 'BA', 'BIH', 372, '波斯尼亚和黑塞哥维那', '387', 1, ',2,4,', '', '../Images/country/BA.gif', '0'),
(29, 'Botswana', 'BW', 'BWA', 371, '博茨瓦纳', '267', 1, ',2,4,', '', '../Images/country/BW.gif', '0'),
(30, 'Bouvet Island', 'BV', 'BVT', 370, '布韦岛', NULL, 1, ',2,4,', '', '../Images/country/BV.gif', '0'),
(31, 'Brazil', 'BR', 'BRA', 369, '巴西', '55', 1, ',2,4,', '', '../Images/country/BR.gif', '0'),
(32, 'British Indian Ocean Territory', 'IO', 'IOT', 368, '英属印度洋领地', '246', 1, ',2,4,', '', '../Images/country/IO.gif', '0'),
(33, 'Brunei Darussalam', 'BN', 'BRN', 367, '汶莱', '673', 1, ',2,4,', '', '../Images/country/BN.gif', '0'),
(34, 'Bulgaria', 'BG', 'BGR', 366, '保加利亚', '359', 1, ',2,4,', '', '../Images/country/BG.gif', '0'),
(35, 'Burkina Faso', 'BF', 'BFA', 365, '布基纳法索', '226', 1, ',2,4,', '', '../Images/country/BF.gif', '0'),
(36, 'Burundi', 'BI', 'BDI', 364, '布隆迪', '257', 1, ',2,4,', '', '../Images/country/BI.gif', '0'),
(37, 'Cambodia', 'KH', 'KHM', 363, '柬埔寨', '855', 1, ',2,4,', '', '../Images/country/KH.gif', '0'),
(38, 'Cameroon', 'CM', 'CMR', 362, '喀麦隆', '237', 1, ',2,4,', '', '../Images/country/CM.gif', '0'),
(39, 'Canada', 'CA', 'CAN', 361, '加拿大', '1', 1, ',2,4,', '', '../Images/country/CA.gif', '0'),
(40, 'Cape Verde', 'CV', 'CPV', 360, '佛得角', '238', 1, ',2,4,', '', '../Images/country/CV.gif', '0'),
(41, 'Cayman Islands', 'KY', 'CYM', 359, '开曼群岛', '1345', 1, ',2,4,', '', '../Images/country/KY.gif', '0'),
(42, 'Central African Republic', 'CF', 'CAF', 358, '中非共和国', '236', 1, ',2,4,', '', '../Images/country/CF.gif', '0'),
(43, 'Chad', 'TD', 'TCD', 357, '乍得', '235', 1, ',2,4,', '', '../Images/country/TD.gif', '0'),
(44, 'Chile', 'CL', 'CHL', 356, '智利', '56', 1, ',2,4,', '', '../Images/country/CL.gif', '0'),
(45, 'China', 'CN', 'CHN', 355, '中国', '86', 1, ',2,4,', '', '../Images/country/CN.gif', '0'),
(46, 'Christmas Island', 'CX', 'CXR', 354, '圣诞岛', '61', 1, ',2,4,', '', '../Images/country/CX.gif', '0'),
(47, 'Cocos (Keeling) Islands', 'CC', 'CCK', 353, '科科斯(基林)群岛', '61', 1, ',2,4,', '', '../Images/country/CC.gif', '0'),
(48, 'Colombia', 'CO', 'COL', 352, '哥伦比亚', '57', 1, ',2,4,', '', '../Images/country/CO.gif', '0'),
(49, 'Comoros', 'KM', 'COM', 351, '科摩罗', '269', 1, ',2,4,', '', '../Images/country/KM.gif', '0'),
(50, 'Cook Islands', 'CK', 'COK', 350, '库克群岛', '682', 1, ',2,4,', '', '../Images/country/CK.gif', '0'),
(51, 'Costa Rica', 'CR', 'CRI', 349, '哥斯达黎加', '506', 1, ',2,4,', '', '../Images/country/CR.gif', '0'),
(52, 'Cote D\'ivoire', 'CI', 'CIV', 348, '科特迪瓦', '225', 1, ',2,4,', '', '../Images/country/CI.gif', '0'),
(53, 'Croatia', 'HR', 'HRV', 347, '克罗地亚', '385', 1, ',2,4,', '', '../Images/country/HR.gif', '0'),
(54, 'Cuba', 'CU', 'CUB', 346, '古巴', '53', 1, ',2,4,', '', '../Images/country/CU.gif', '0'),
(55, 'Cyprus', 'CY', 'CYP', 345, '塞浦路斯', '357', 1, ',2,4,', '', '../Images/country/CY.gif', '0'),
(56, 'Czech Republic', 'CZ', 'CZE', 344, '捷克共和国', '420', 1, ',2,4,', '', '../Images/country/CZ.gif', '0'),
(57, 'Democratic Republic of the Congo', 'CD', 'COD', 343, '刚果(金)', '243', 1, ',2,4,', '', '../Images/country/CD.gif', '0'),
(58, 'Denmark', 'DK', 'DNK', 342, '丹麦', '45', 1, ',2,4,', '', '../Images/country/DK.gif', '0'),
(59, 'Djibouti', 'DJ', 'DJI', 341, '吉布提', '253', 1, ',2,4,', '', '../Images/country/DJ.gif', '0'),
(60, 'Dominica', 'DM', 'DMA', 340, '多米尼克', '1767', 1, ',2,4,', '', '../Images/country/DM.gif', '0'),
(61, 'Dominican Republic', 'DO', 'DOM', 339, '多米尼加共和国', '1809', 1, ',2,4,', '', '../Images/country/DO.gif', '0'),
(62, 'Ecuador', 'EC', 'ECU', 338, '厄瓜多尔', '593', 1, ',2,4,', '', '../Images/country/EC.gif', '0'),
(63, 'Egypt', 'EG', 'EGY', 337, '埃及', '20', 1, ',2,4,', '', '../Images/country/EG.gif', '0'),
(64, 'El Salvador', 'SV', 'SLV', 336, '萨尔瓦多', '503', 1, ',2,4,', '', '../Images/country/SV.gif', '0'),
(65, 'Equatorial Guinea', 'GQ', 'GNQ', 335, '赤道几内亚', '240', 1, ',2,4,', '', '../Images/country/GQ.gif', '0'),
(66, 'Eritrea', 'ER', 'ERI', 334, '厄立特里亚', '291', 1, ',2,4,', '', '../Images/country/ER.gif', '0'),
(67, 'Estonia', 'EE', 'EST', 333, '爱沙尼亚', '372', 1, ',2,4,', '', '../Images/country/EE.gif', '0'),
(68, 'Ethiopia', 'ET', 'ETH', 332, '埃塞俄比亚', '251', 1, ',2,4,', '', '../Images/country/ET.gif', '0'),
(69, 'Falkland Islands (malvinas)', 'FK', 'FLK', 331, '福克兰群岛(马尔维纳斯)', '500', 1, ',2,4,', '', '../Images/country/FK.gif', '0'),
(70, 'Faroe Islands', 'FO', 'FRO', 330, '法罗群岛', '298', 1, ',2,4,', '', '../Images/country/FO.gif', '0'),
(71, 'Fiji', 'FJ', 'FJI', 329, '斐济', '679', 1, ',2,4,', '', '../Images/country/FJ.gif', '0'),
(72, 'Finland', 'FI', 'FIN', 328, '芬兰', '358', 1, ',2,4,', '', '../Images/country/FI.gif', '0'),
(73, 'France', 'FR', 'FRA', 327, '法国', '33', 1, ',2,4,', '', '../Images/country/FR.gif', '0'),
(74, 'French Guiana', 'GF', 'GUF', 326, '法属圭亚那', '594', 1, ',2,4,', '', '../Images/country/GF.gif', '0'),
(75, 'French Polynesia', 'PF', 'PYF', 325, '法属波利尼西亚', '689', 1, ',2,4,', '', '../Images/country/PF.gif', '0'),
(76, 'French Southern Territories', 'TF', 'ATF', 324, '法国南部领土', '596', 1, ',2,4,', '', '../Images/country/TF.gif', '0'),
(77, 'Gabon', 'GA', 'GAB', 323, '加蓬', '241', 1, ',2,4,', '', '../Images/country/GA.gif', '0'),
(78, 'Gambia', 'GM', 'GMB', 322, '冈比亚', '220', 1, ',2,4,', '', '../Images/country/GM.gif', '0'),
(79, 'Georgia', 'GE', 'GEO', 321, '格鲁吉亚', '995', 1, ',2,4,', '', '../Images/country/GE.gif', '0'),
(80, 'Germany', 'DE', 'DEU', 320, '德国', '49', 1, ',2,4,', '', '../Images/country/DE.gif', '0'),
(81, 'Ghana', 'GH', 'GHA', 319, '加纳', '233', 1, ',2,4,', '', '../Images/country/GH.gif', '0'),
(82, 'Gibraltar', 'GI', 'GIB', 318, '直布罗陀', '350', 1, ',2,4,', '', '../Images/country/GI.gif', '0'),
(83, 'Greece', 'GR', 'GRC', 317, '希腊', '30', 1, ',2,4,', '', '../Images/country/GR.gif', '0'),
(84, 'Greenland', 'GL', 'GRL', 316, '格陵兰', '299', 1, ',2,4,', '', '../Images/country/GL.gif', '0'),
(85, 'Grenada', 'GD', 'GRD', 315, '格林纳达', '1473', 1, ',2,4,', '', '../Images/country/GD.gif', '0'),
(86, 'Guadeloupe', 'GP', 'GLP', 314, '瓜德罗普岛', '590', 1, ',2,4,', '', '../Images/country/GP.gif', '0'),
(87, 'Guam', 'GU', 'GUM', 313, '关岛', '1671', 1, ',2,4,', '', '../Images/country/GU.gif', '0'),
(88, 'Guatemala', 'GT', 'GTM', 312, '危地马拉', '502', 1, ',2,4,', '', '../Images/country/GT.gif', '0'),
(89, 'Guinea', 'GN', 'GIN', 311, '几内亚', '224', 1, ',2,4,', '', '../Images/country/GN.gif', '0'),
(90, 'Guinea-bissau', 'GW', 'GNB', 310, '几内亚 - 比绍', '245', 1, ',2,4,', '', '../Images/country/GW.gif', '0'),
(91, 'Guyana', 'GY', 'GUY', 309, '圭亚那', '592', 1, ',2,4,', '', '../Images/country/GY.gif', '0'),
(92, 'Haiti', 'HT', 'HTI', 308, '海地', '509', 1, ',2,4,', '', '../Images/country/HT.gif', '0'),
(93, 'Heard Island and McDonald Islands', 'HM', 'HMD', 307, '赫德岛和麦克唐纳群岛', NULL, 1, ',2,4,', '', '../Images/country/HM.gif', '0'),
(94, 'Holy See (vatican City State)', 'VA', 'VAT', 306, '罗马教廷(梵蒂冈城国)', '379', 1, ',2,4,', '', '../Images/country/VA.gif', '0'),
(95, 'Honduras', 'HN', 'HND', 305, '洪都拉斯', '504', 1, ',2,4,', '', '../Images/country/HN.gif', '0'),
(96, 'Hong Kong', 'HK', 'HKG', 304, '香港', '852', 1, ',2,4,', '', '../Images/country/HK.gif', '0'),
(97, 'Hungary', 'HU', 'HUN', 303, '匈牙利', '36', 1, ',2,4,', '', '../Images/country/HU.gif', '0'),
(98, 'Iceland', 'IS', 'ISL', 302, '冰岛', '354', 1, ',2,4,', '', '../Images/country/IS.gif', '0'),
(99, 'India', 'IN', 'IND', 301, '印度', '91', 1, ',2,4,', '', '../Images/country/IN.gif', '0'),
(100, 'Indonesia', 'ID', 'IDN', 300, '印尼', '62', 1, ',2,4,', '', '../Images/country/ID.gif', '0'),
(101, 'Iran', 'IR', 'IRN', 299, '伊朗', '98', 1, ',2,4,', '', '../Images/country/IR.gif', '0'),
(102, 'Iraq', 'IQ', 'IRQ', 298, '伊拉克', '964', 1, ',2,4,', '', '../Images/country/IQ.gif', '0'),
(103, 'Ireland', 'IE', 'IRL', 297, '爱尔兰', '353', 1, ',2,4,', '', '../Images/country/IE.gif', '0'),
(104, 'Isle Of Man', 'IM', 'IMN', 296, '马恩岛', '44', 1, ',2,4,', '', '../Images/country/IM.gif', '0'),
(105, 'Israel', 'IL', 'ISR', 295, '以色列', '972', 1, ',2,4,', '', '../Images/country/IL.gif', '0'),
(106, 'Italy', 'IT', 'ITA', 294, '意大利', '39', 1, ',2,4,', '', '../Images/country/IT.gif', '0'),
(107, 'Jamaica', 'JM', 'JAM', 293, '牙买加', '1876', 1, ',2,4,', '', '../Images/country/JM.gif', '0'),
(108, 'Japan', 'JP', 'JPN', 292, '日本', '81', 1, ',2,4,', '', '../Images/country/JP.gif', '0'),
(109, 'Jordan', 'JO', 'JOR', 291, '约旦', '962', 1, ',2,4,', '', '../Images/country/JO.gif', '0'),
(110, 'Kazakhstan', 'KZ', 'KAZ', 290, '哈萨克斯坦', '7', 1, ',2,4,', '', '../Images/country/KZ.gif', '0'),
(111, 'Kenya', 'KE', 'KEN', 289, '肯尼亚', '254', 1, ',2,4,', '', '../Images/country/KE.gif', '0'),
(112, 'Kiribati', 'KI', 'KIR', 288, '基里巴斯', '686', 1, ',2,4,', '', '../Images/country/KI.gif', '0'),
(113, 'Korea', 'KR', 'KOR', 287, '韩国', '82', 1, ',2,4,', '', '../Images/country/KR.gif', '0'),
(114, 'Kuwait', 'KW', 'KWT', 286, '科威特', '965', 1, ',2,4,', '', '../Images/country/KW.gif', '0'),
(115, 'Kyrgyzstan', 'KG', 'KGZ', 285, '吉尔吉斯斯坦', '996', 1, ',2,4,', '', '../Images/country/KG.gif', '0'),
(116, 'Lao People\'s Democratic Republic', 'LA', 'LAO', 284, '老挝人民民主共和国', '856', 1, ',2,4,', '', '../Images/country/LA.gif', '0'),
(117, 'Latvia', 'LV', 'LVA', 283, '拉脱维亚', '371', 1, ',2,4,', '', '../Images/country/LV.gif', '0'),
(118, 'Lebanon', 'LB', 'LBN', 282, '黎巴嫩', '961', 1, ',2,4,', '', '../Images/country/LB.gif', '0'),
(119, 'Lesotho', 'LS', 'LSO', 281, '莱索托', '266', 1, ',2,4,', '', '../Images/country/LS.gif', '0'),
(120, 'Liberia', 'LR', 'LBR', 280, '利比里亚', '231', 1, ',2,4,', '', '../Images/country/LR.gif', '0'),
(121, 'Libyan Arab Jamahiriya', 'LY', 'LBY', 279, '阿拉伯利比亚民众国', '218', 1, ',2,4,', '', '../Images/country/LY.gif', '0'),
(122, 'Liechtenstein', 'LI', 'LIE', 278, '列支敦士登', '423', 1, ',2,4,', '', '../Images/country/LI.gif', '0'),
(123, 'Lithuania', 'LT', 'LTU', 277, '立陶宛', '370', 1, ',2,4,', '', '../Images/country/LT.gif', '0'),
(124, 'Luxembourg', 'LU', 'LUX', 276, '卢森堡', '352', 1, ',2,4,', '', '../Images/country/LU.gif', '0'),
(125, 'Macao', 'MO', 'MAC', 275, '澳门', '853', 1, ',2,4,', '', '../Images/country/MO.gif', '0'),
(126, 'Macedonia', 'MK', 'MKD', 274, '马其顿', '389', 1, ',2,4,', '', '../Images/country/MK.gif', '0'),
(127, 'Madagascar', 'MG', 'MDG', 273, '马达加斯加', '261', 1, ',2,4,', '', '../Images/country/MG.gif', '0'),
(128, 'Malawi', 'MW', 'MWI', 272, '马拉维', '265', 1, ',2,4,', '', '../Images/country/MW.gif', '0'),
(129, 'Malaysia', 'MY', 'MYS', 271, '马来西亚', '60', 1, ',2,4,', '', '../Images/country/MY.gif', '0'),
(130, 'Maldives', 'MV', 'MDV', 270, '马尔代夫', '960', 1, ',2,4,', '', '../Images/country/MV.gif', '0'),
(131, 'Mali', 'ML', 'MLI', 269, '马里', '223', 1, ',2,4,', '', '../Images/country/ML.gif', '0'),
(132, 'Malta', 'MT', 'MLT', 268, '马耳他', '356', 1, ',2,4,', '', '../Images/country/MT.gif', '0'),
(133, 'Marshall Islands', 'MH', 'MHL', 267, '马绍尔群岛', '692', 1, ',2,4,', '', '../Images/country/MH.gif', '0'),
(134, 'Martinique', 'MQ', 'MTQ', 266, '马提尼克岛', '596', 1, ',2,4,', '', '../Images/country/MQ.gif', '0'),
(135, 'Mauritania', 'MR', 'MRT', 265, '毛里塔尼亚', '222', 1, ',2,4,', '', '../Images/country/MR.gif', '0'),
(136, 'Mauritius', 'MU', 'MUS', 264, '毛里求斯', '230', 1, ',2,4,', '', '../Images/country/MU.gif', '0'),
(137, 'Mayotte', 'YT', 'MYT', 263, '马约特岛', '269', 1, ',2,4,', '', '../Images/country/YT.gif', '0'),
(138, 'Mexico', 'MX', 'MEX', 262, '墨西哥', '52', 1, ',2,4,', '', '../Images/country/MX.gif', '0'),
(139, 'Micronesia', 'FM', 'FSM', 261, '密克罗尼西亚', '691', 1, ',2,4,', '', '../Images/country/FM.gif', '0'),
(140, 'Moldova', 'MD', 'MDA', 260, '摩尔多瓦', '373', 1, ',2,4,', '', '../Images/country/MD.gif', '0'),
(141, 'Monaco', 'MC', 'MCO', 259, '摩纳哥', '377', 1, ',2,4,', '', '../Images/country/MC.gif', '0'),
(142, 'Mongolia', 'MN', 'MNG', 258, '蒙古', '976', 1, ',2,4,', '', '../Images/country/MN.gif', '0'),
(143, 'Montenegro', 'ME', 'MNE', 257, '黑山', '382', 1, ',2,4,', '', '../Images/country/ME.gif', '0'),
(144, 'Montserrat', 'MS', 'MSR', 256, '蒙特塞拉特', '1664', 1, ',2,4,', '', '../Images/country/MS.gif', '0'),
(145, 'Morocco', 'MA', 'MAR', 255, '摩洛哥', '212', 1, ',2,4,', '', '../Images/country/MA.gif', '0'),
(146, 'Mozambique', 'MZ', 'MOZ', 254, '莫桑比克', '258', 1, ',2,4,', '', '../Images/country/MZ.gif', '0'),
(147, 'Myanmar', 'MM', 'MMR', 253, '缅甸', '95', 1, ',2,4,', '', '../Images/country/MM.gif', '0'),
(148, 'Namibia', 'NA', 'NAM', 252, '纳米比亚', '264', 1, ',2,4,', '', '../Images/country/NA.gif', '0'),
(149, 'Nauru', 'NR', 'NRU', 251, '瑙鲁', '674', 1, ',2,4,', '', '../Images/country/NR.gif', '0'),
(150, 'Nepal', 'NP', 'NPL', 250, '尼泊尔', '977', 1, ',2,4,', '', '../Images/country/NP.gif', '0'),
(151, 'Netherlands', 'NL', 'NLD', 249, '荷兰', '31', 1, ',2,4,', '', '../Images/country/NL.gif', '0'),
(152, 'Netherlands Antilles', 'AN', 'ANT', 248, '荷属安的列斯', '599', 1, ',2,4,', '', '../Images/country/AN.gif', '0'),
(153, 'New Caledonia', 'NC', 'NCL', 247, '新喀里多尼亚', '687', 1, ',2,4,', '', '../Images/country/NC.gif', '0'),
(154, 'New Zealand', 'NZ', 'NZL', 246, '新西兰', '64', 1, ',2,4,', '', '../Images/country/NZ.gif', '0'),
(155, 'Nicaragua', 'NI', 'NIC', 245, '尼加拉瓜', '505', 1, ',2,4,', '', '../Images/country/NI.gif', '0'),
(156, 'Niger', 'NE', 'NER', 244, '尼日尔', '227', 1, ',2,4,', '', '../Images/country/NE.gif', '0'),
(157, 'Nigeria', 'NG', 'NGA', 243, '尼日利亚', '234', 1, ',2,4,', '', '../Images/country/NG.gif', '0'),
(158, 'Niue', 'NU', 'NIU', 242, '纽埃', '683', 1, ',2,4,', '', '../Images/country/NU.gif', '0'),
(159, 'Norfolk Island', 'NF', 'NFK', 241, '诺福克岛', '6723', 1, ',2,4,', '', '../Images/country/NF.gif', '0'),
(160, 'North Korea', 'KP', 'PRK', 240, '朝鲜', '850', 1, ',2,4,', '', '../Images/country/KP.gif', '0'),
(161, 'Northern Mariana Islands', 'MP', 'MNP', 239, '北马里亚纳群岛', '1', 1, ',2,4,', '', '../Images/country/MP.gif', '0'),
(162, 'Norway', 'NO', 'NOR', 238, '挪威', '47', 1, ',2,4,', '', '../Images/country/NO.gif', '0'),
(163, 'Oman', 'OM', 'OMN', 237, '阿曼', '968', 1, ',2,4,', '', '../Images/country/OM.gif', '0'),
(164, 'Pakistan', 'PK', 'PAK', 236, '巴基斯坦', '92', 1, ',2,4,', '', '../Images/country/PK.gif', '0'),
(165, 'Palau', 'PW', 'PLW', 235, '帕劳', '680', 1, ',2,4,', '', '../Images/country/PW.gif', '0'),
(166, 'Palestinian Territory', 'PS', 'PLE', 234, '巴勒斯坦领土', '970', 1, ',2,4,', '', '../Images/country/PS.gif', '0'),
(167, 'Panama', 'PA', 'PAN', 233, '巴拿马', '507', 1, ',2,4,', '', '../Images/country/PA.gif', '0'),
(168, 'Papua New Guinea', 'PG', 'PNG', 232, '巴布亚新几内亚', '63', 1, ',2,4,', '', '../Images/country/PG.gif', '0'),
(169, 'Paraguay', 'PY', 'PRY', 231, '巴拉圭', '595', 1, ',2,4,', '', '../Images/country/PY.gif', '0'),
(170, 'Peru', 'PE', 'PER', 230, '秘鲁', '51', 1, ',2,4,', '', '../Images/country/PE.gif', '0'),
(171, 'Philippines', 'PH', 'PHL', 229, '菲律宾', '63', 1, ',2,4,', '', '../Images/country/PH.gif', '0'),
(172, 'Pitcairn Islands', 'PN', 'PCN', 228, '皮特凯恩群岛', '64', 1, ',2,4,', '', '../Images/country/PN.gif', '0'),
(173, 'Poland', 'PL', 'POL', 227, '波兰', '48', 1, ',2,4,', '', '../Images/country/PL.gif', '0'),
(174, 'Portugal', 'PT', 'PRT', 226, '葡萄牙', '351', 1, ',2,4,', '', '../Images/country/PT.gif', '0'),
(175, 'Puerto Rico', 'PR', 'PRI', 225, '波多黎各', '1787', 1, ',2,4,', '', '../Images/country/PR.gif', '0'),
(176, 'Qatar', 'QA', 'QAT', 224, '卡塔尔', '974', 1, ',2,4,', '', '../Images/country/QA.gif', '0'),
(177, 'Republic of the Congo', 'CG', 'COG', 223, '刚果(布)', '242', 1, ',2,4,', '', '../Images/country/CG.gif', '0'),
(178, 'Reunion', 'RE', 'REU', 222, '团圆', '262', 1, ',2,4,', '', '../Images/country/RE.gif', '0'),
(179, 'Romania', 'RO', 'ROM', 221, '罗马尼亚', '40', 1, ',2,4,', '', '../Images/country/RO.gif', '0'),
(180, 'Russian Federation', 'RU', 'RUS', 220, '俄罗斯联邦', '7', 1, ',2,4,', '', '../Images/country/RU.gif', '0'),
(181, 'Rwanda', 'RW', 'RWA', 219, '卢旺达', '250', 1, ',2,4,', '', '../Images/country/RW.gif', '0'),
(182, 'Saint Kitts And Nevis', 'KN', 'KNA', 218, '圣基茨和尼维斯', '1869', 1, ',2,4,', '', '../Images/country/KN.gif', '0'),
(183, 'Saint Lucia', 'LC', 'LCA', 217, '圣卢西亚', '1758', 1, ',2,4,', '', '../Images/country/LC.gif', '0'),
(184, 'Saint Vincent And The Grenadines', 'VC', 'VCT', 216, '圣文森特和格林纳丁斯', '1784', 1, ',2,4,', '', '../Images/country/VC.gif', '0'),
(185, 'Saint-Pierre and Miquelon', 'PM', 'SPM', 215, '圣皮埃尔和密克隆', '508', 1, ',2,4,', '', '../Images/country/PM.gif', '0'),
(186, 'Samoa', 'WS', 'WSM', 214, '萨摩亚', '685', 1, ',2,4,', '', '../Images/country/WS.gif', '0'),
(187, 'San Marino', 'SM', 'SMR', 213, '圣马力诺', '378', 1, ',2,4,', '', '../Images/country/SM.gif', '0'),
(188, 'Sao Tome And Principe', 'ST', 'STP', 212, '圣多美与普林西比', '239', 1, ',2,4,', '', '../Images/country/ST.gif', '0'),
(189, 'Saudi Arabia', 'SA', 'SAU', 211, '沙特阿拉伯', '966', 1, ',2,4,', '', '../Images/country/SA.gif', '0'),
(190, 'Senegal', 'SN', 'SEN', 210, '塞内加尔', '221', 1, ',2,4,', '', '../Images/country/SN.gif', '0'),
(191, 'Serbia', 'RS', 'SRB', 209, '塞尔维亚', '381', 1, ',2,4,', '', '../Images/country/RS.gif', '0'),
(192, 'Seychelles', 'SC', 'SYC', 208, '塞舌尔', '248', 1, ',2,4,', '', '../Images/country/SC.gif', '0'),
(193, 'Sierra Leone', 'SL', 'SLE', 207, '塞拉利昂', '232', 1, ',2,4,', '', '../Images/country/SL.gif', '0'),
(194, 'Singapore', 'SG', 'SGP', 206, '新加坡', '65', 1, ',2,4,', '', '../Images/country/SG.gif', '0'),
(195, 'Slovakia', 'SK', 'SVK', 205, '斯洛伐克', '421', 1, ',2,4,', '', '../Images/country/SK.gif', '0'),
(196, 'Slovenia', 'SI', 'SVN', 204, '斯洛文尼亚', '386', 1, ',2,4,', '', '../Images/country/SI.gif', '0'),
(197, 'Solomon Islands', 'SB', 'SLB', 203, '所罗门群岛', '677', 1, ',2,4,', '', '../Images/country/SB.gif', '0'),
(198, 'Somalia', 'SO', 'SOM', 202, '索马里', '252', 1, ',2,4,', '', '../Images/country/SO.gif', '0'),
(199, 'South Africa', 'ZA', 'ZAF', 201, '南非', '27', 1, ',2,4,', '', '../Images/country/ZA.gif', '0'),
(200, 'South Georgia And The South Sandwich Islands', 'GS', 'SGS', 200, '南乔治亚岛和南桑威奇群岛', '995', 1, ',2,4,', '', '../Images/country/GS.gif', '0'),
(201, 'Spain', 'ES', 'ESP', 199, '西班牙', '34', 1, ',2,4,', '', '../Images/country/ES.gif', '0'),
(202, 'Sri Lanka', 'LK', 'LKA', 198, '斯里兰卡', '94', 1, ',2,4,', '', '../Images/country/LK.gif', '0'),
(203, 'St. Helena & Dependencies', 'SH', 'SHN', 197, '圣赫勒拿', '290', 1, ',2,4,', '', '../Images/country/SH.gif', '0'),
(204, 'Sudan', 'SD', 'SDN', 196, '苏丹', '249', 1, ',2,4,', '', '../Images/country/SD.gif', '0'),
(205, 'Suriname', 'SR', 'SUR', 195, '苏里南', '597', 1, ',2,4,', '', '../Images/country/SR.gif', '0'),
(206, 'Svalbard and Jan Mayen Islands', 'SJ', 'SJM', 194, '斯瓦尔巴群岛和扬马延岛', '47', 1, ',2,4,', '', '../Images/country/SJ.gif', '0'),
(207, 'Swaziland', 'SZ', 'SWZ', 193, '斯威士兰', '268', 1, ',2,4,', '', '../Images/country/SZ.gif', '0'),
(208, 'Sweden', 'SE', 'SWE', 192, '瑞典', '46', 1, ',2,4,', '', '../Images/country/SE.gif', '0'),
(209, 'Switzerland', 'CH', 'CHE', 191, '瑞士', '41', 1, ',2,4,', '', '../Images/country/CH.gif', '0'),
(210, 'Syrian Arab Republic', 'SY', 'SYR', 190, '阿拉伯叙利亚共和国', '963', 1, ',2,4,', '', '../Images/country/SY.gif', '0'),
(211, 'Taiwan', 'TW', 'TWN', 189, '台湾', '886', 1, ',2,4,', '', '../Images/country/TW.gif', '0'),
(212, 'Tajikistan', 'TJ', 'TJK', 188, '塔吉克斯坦', '992', 1, ',2,4,', '', '../Images/country/TJ.gif', '0'),
(213, 'Tanzania', 'TZ', 'TZA', 187, '坦桑尼亚', '255', 1, ',2,4,', '', '../Images/country/TZ.gif', '0'),
(214, 'Thailand', 'TH', 'THA', 186, '泰国', '66', 1, ',2,4,', '', '../Images/country/TH.gif', '0'),
(215, 'Timor-Leste (East Timor)', 'TL', 'TLS', 185, '东帝汶', '670', 1, ',2,4,', '', '../Images/country/TL.gif', '0'),
(216, 'Togo', 'TG', 'TGO', 184, '多哥', '228', 1, ',2,4,', '', '../Images/country/TG.gif', '0'),
(217, 'Tokelau', 'TK', 'TKL', 183, '托克劳', '690', 1, ',2,4,', '', '../Images/country/TK.gif', '0'),
(218, 'Tonga', 'TO', 'TON', 182, '汤加', '676', 1, ',2,4,', '', '../Images/country/TO.gif', '0'),
(219, 'Trinidad And Tobago', 'TT', 'TTO', 181, '特里尼达和多巴哥', '1868', 1, ',2,4,', '', '../Images/country/TT.gif', '0'),
(220, 'Tunisia', 'TN', 'TUN', 180, '突尼斯', '216', 1, ',2,4,', '', '../Images/country/TN.gif', '0'),
(221, 'Turkey', 'TR', 'TUR', 179, '土耳其', '90', 1, ',2,4,', '', '../Images/country/TR.gif', '0'),
(222, 'Turkmenistan', 'TM', 'TKM', 178, '土库曼斯坦', '993', 1, ',2,4,', '', '../Images/country/TM.gif', '0'),
(223, 'Turks And Caicos Islands', 'TC', 'TCA', 177, '特克斯和凯科斯群岛', '1649', 1, ',2,4,', '', '../Images/country/TC.gif', '0'),
(224, 'Tuvalu', 'TV', 'TUV', 176, '图瓦卢', '688', 1, ',2,4,', '', '../Images/country/TV.gif', '0'),
(225, 'Uganda', 'UG', 'UGA', 175, '乌干达', '256', 1, ',2,4,', '', '../Images/country/UG.gif', '0'),
(226, 'Ukraine', 'UA', 'UKR', 174, '乌克兰', '380', 1, ',2,4,', '', '../Images/country/UA.gif', '0'),
(227, 'United Arab Emirates', 'AE', 'ARE', 173, '阿拉伯联合酋长国', '971', 1, ',2,4,', '', '../Images/country/AE.gif', '0'),
(228, 'United Kingdom', 'GB', 'GBR', 172, '英国', '44', 1, ',2,4,', '', '../Images/country/GB.gif', '0'),
(229, 'United States', 'US', 'USA', 600, '美国', '1', 1, ',2,4,', '', '../Images/country/US.gif', '0'),
(230, 'United States Minor Outlying Islands', 'UM', 'UMI', 170, '美国本土外小岛屿', NULL, 1, ',2,4,', '', '../Images/country/UM.gif', '0'),
(231, 'Uruguay', 'UY', 'URY', 169, '乌拉圭', '598', 1, ',2,4,', '', '../Images/country/UY.gif', '0'),
(232, 'Uzbekistan', 'UZ', 'UZB', 168, '乌兹别克斯坦', '998', 1, ',2,4,', '', '../Images/country/UZ.gif', '0'),
(233, 'Vanuatu', 'VU', 'VUT', 167, '瓦努阿图', '678', 1, ',2,4,', '', '../Images/country/VU.gif', '0'),
(234, 'Venezuela', 'VE', 'VEN', 166, '委内瑞拉', '58', 1, ',2,4,', '', '../Images/country/VE.gif', '0'),
(235, 'Viet Nam', 'VN', 'VNM', 165, '越南', '84', 1, ',2,4,', '', '../Images/country/VN.gif', '0'),
(236, 'Virgin Islands', 'VI', 'VIR', 164, '维尔京群岛', '1340', 1, ',2,4,', '', '../Images/country/VI.gif', '0'),
(237, 'Wallis and Futuna', 'WF', 'WLF', 163, '瓦利斯和富图纳', '681', 1, ',2,4,', '', '../Images/country/WF.gif', '0'),
(238, 'Western Sahara', 'EH', 'ESH', 162, '西撒哈拉', '212/213', 1, ',2,4,', '', '../Images/country/EH.gif', '0'),
(239, 'Yemen', 'YE', 'YEM', 161, '也门', '967', 1, ',2,4,', '', '../Images/country/YE.gif', '0'),
(240, 'Yugoslavia', 'YU', 'YUG', 160, '南斯拉夫', '338', 1, ',2,4,', '', '../Images/country/YU.gif', '0'),
(241, 'Zambia', 'ZM', 'ZMB', 159, '赞比亚', '260', 1, ',2,4,', '', '../Images/country/ZM.gif', '20'),
(242, 'Zimbabwe', 'ZW', 'ZWE', 158, '津巴布韦', '263', 1, ',2,4,', '', '../Images/country/ZW_1001.gif,', '100');

-- --------------------------------------------------------

--
-- 表的结构 `sc_coupon`
--

CREATE TABLE `sc_coupon` (
  `ID` int(11) NOT NULL,
  `cou_title` varchar(200) NOT NULL,
  `cou_tent` varchar(1000) NOT NULL,
  `cou_price` char(20) NOT NULL,
  `cou_overprice` char(20) DEFAULT NULL,
  `cou_code` char(50) NOT NULL,
  `cou_startime` datetime NOT NULL,
  `cou_overtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ant_img` char(200) NOT NULL,
  `cou_flag` int(11) DEFAULT '0',
  `cou_language` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sc_coupon`
--

INSERT INTO `sc_coupon` (`ID`, `cou_title`, `cou_tent`, `cou_price`, `cou_overprice`, `cou_code`, `cou_startime`, `cou_overtime`, `ant_img`, `cou_flag`, `cou_language`) VALUES
(5, 'first order over $50', 'f32', '12', '20', '2021semcms', '2021-03-14 00:00:00', '2021-02-27 16:00:00', '', 1, 1),
(6, '$10 off your first order', '$10 off your first order', '10', '99', 'SEMCMS', '2021-03-14 00:00:00', '2021-11-28 16:00:00', '', 1, 1);

-- --------------------------------------------------------

--
-- 表的结构 `sc_currency`
--

CREATE TABLE `sc_currency` (
  `ID` int(11) NOT NULL,
  `currency_name` char(50) DEFAULT NULL,
  `currency_left_fh` char(50) DEFAULT NULL,
  `currency_hl` char(20) DEFAULT NULL,
  `currency_bz_fh` char(50) DEFAULT NULL,
  `ant_img` char(100) DEFAULT NULL,
  `currency_default` int(11) DEFAULT '0',
  `currency_flag` int(11) DEFAULT '1',
  `currency_paixu` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sc_currency`
--

INSERT INTO `sc_currency` (`ID`, `currency_name`, `currency_left_fh`, `currency_hl`, `currency_bz_fh`, `ant_img`, `currency_default`, `currency_flag`, `currency_paixu`) VALUES
(1, 'USD Dollor', '$', '1.0000', 'USD', '../Images/other/201216041649_2217.gif,', 1, 1, 1),
(3, 'Euro', '€', '0.8656', 'EUR', '../Images/other/201216041758_2674.gif,', 0, 1, 1000),
(4, 'GB Pound', '￡', '0.7592', 'GBP', '../Images/other/201216041815_1025.gif,', 0, 1, 1000),
(5, '加元', 'CAD', '1.2953', 'CAD', '../Images/other/201216041719_7625.gif,', 0, 1, 1000),
(6, '澳元', 'AUD', '1.4011', 'AUD', '../Images/other/201216041706_7658.gif,', 0, 1, 1000);

-- --------------------------------------------------------

--
-- 表的结构 `sc_delivery`
--

CREATE TABLE `sc_delivery` (
  `ID` int(11) NOT NULL,
  `ex_id` int(11) DEFAULT NULL,
  `de_name` char(100) DEFAULT NULL,
  `de_jsfs` char(50) DEFAULT NULL,
  `de_paixu` int(11) DEFAULT NULL,
  `de_area` varchar(2000) DEFAULT '',
  `de_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sc_delivery`
--

INSERT INTO `sc_delivery` (`ID`, `ex_id`, `de_name`, `de_jsfs`, `de_paixu`, `de_area`, `de_time`) VALUES
(6, 2, '区域-1', '10+(R(W*2-1))*9', NULL, ',242,241,240,239,238,237,236,235,234,233,232,231,230,228,227,226,225,224,223,222,221,220,219,218,217,216,215,214,213,212,211,210,209,208,207,206,205,204,203,202,201,200,199,198,197,196,195,194,193,192,191,190,189,188,187,186,185,184,183,182,181,180,179,178,177,176,175,174,173,172,171,170,169,168,167,166,165,164,163,162,161,160,159,158,157,156,155,154,153,152,151,150,149,148,147,146,145,144,143,142,141,140,139,138,137,136,135,134,133,132,131,130,129,128,127,126,125,124,123,122,121,120,119,118,117,116,115,114,113,112,111,110,109,108,107,106,105,104,103,102,101,100,99,98,97,96,95,94,93,92,91,90,89,88,87,86,85,84,83,82,81,80,79,78,77,76,75,74,73,72,71,70,69,68,67,66,65,64,63,62,61,60,59,58,57,56,55,54,53,52,51,50,49,48,47,46,45,44,43,42,41,40,39,38,37,36,35,34,33,32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,4,3,229,2,1,', '2021-03-11 01:01:08'),
(13, 4, '区域1', '9+(R(W*2-1))*9', NULL, ',242,241,240,239,238,237,236,235,234,233,232,231,230,228,227,226,225,224,223,222,221,220,219,218,217,216,215,214,213,212,211,210,209,208,207,206,205,204,203,202,201,200,199,198,197,196,195,194,193,192,191,190,189,188,187,186,185,184,183,182,181,180,179,178,177,176,175,174,173,172,171,170,169,168,167,166,165,164,163,162,161,160,159,158,157,156,155,154,153,152,151,150,149,148,147,146,145,144,143,142,141,140,139,138,137,136,135,134,133,132,131,130,129,128,127,126,125,124,123,122,121,120,119,118,117,116,115,114,113,112,111,110,109,108,107,106,105,104,103,102,101,100,99,98,97,96,95,94,93,92,91,90,89,88,87,86,85,84,83,82,81,80,79,78,77,76,75,74,73,72,71,70,69,68,67,66,65,64,63,62,61,60,59,58,57,56,55,54,53,52,51,50,49,48,47,46,45,44,43,42,41,40,39,38,37,36,35,34,33,32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,4,3,229,2,1,', '2021-03-11 01:01:39');

-- --------------------------------------------------------

--
-- 表的结构 `sc_discount`
--

CREATE TABLE `sc_discount` (
  `ID` int(11) NOT NULL,
  `di_name` char(50) DEFAULT '',
  `di_qty` varchar(1000) DEFAULT '',
  `di_price` varchar(1000) DEFAULT '',
  `di_paixu` int(11) DEFAULT '1000',
  `di_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sc_discount`
--

INSERT INTO `sc_discount` (`ID`, `di_name`, `di_qty`, `di_price`, `di_paixu`, `di_time`) VALUES
(2, '折扣1', '1,2-3,4-5,6+', '1,0.9,0.85,0.7', 1000, '2021-01-05 07:02:41'),
(3, '折扣2', '2,3-10,11+', '1,0.95,0.9', 1000, '2021-03-10 06:47:34');

-- --------------------------------------------------------

--
-- 表的结构 `sc_download`
--

CREATE TABLE `sc_download` (
  `ID` int(11) NOT NULL,
  `down_name` varchar(500) DEFAULT NULL,
  `ant_img` char(200) DEFAULT NULL,
  `languageID` int(11) DEFAULT NULL,
  `down_paixu` varchar(100) DEFAULT NULL,
  `down_open` int(11) NOT NULL DEFAULT '1',
  `down_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sc_download`
--

INSERT INTO `sc_download` (`ID`, `down_name`, `ant_img`, `languageID`, `down_paixu`, `down_open`, `down_time`) VALUES
(4, 'Car Used Heat Dissipation Cable Tray Roll Forming Machine Patent', '../Images/down/210314054612_6471.png,', 1, '10000', 1, '2021-03-14 09:46:16');

-- --------------------------------------------------------

--
-- 表的结构 `sc_email`
--

CREATE TABLE `sc_email` (
  `ID` int(11) NOT NULL,
  `e_ml` char(50) DEFAULT NULL,
  `e_ip` char(50) DEFAULT NULL,
  `e_tm` timestamp NULL DEFAULT NULL,
  `e_couid` char(10) DEFAULT NULL,
  `e_coucode` char(50) DEFAULT '',
  `e_flag` int(11) NOT NULL DEFAULT '0' COMMENT '控制是否使用'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sc_email`
--

INSERT INTO `sc_email` (`ID`, `e_ml`, `e_ip`, `e_tm`, `e_couid`, `e_coucode`, `e_flag`) VALUES
(25, '88@gmail.com', '127.0.0.1', '2021-02-27 09:10:43', '6', 'SEMCMS', 0),
(26, '1181698019@qq.com', '127.0.0.1', '2021-03-14 13:17:12', '6', 'SEMCMS', 0);

-- --------------------------------------------------------

--
-- 表的结构 `sc_express`
--

CREATE TABLE `sc_express` (
  `ID` int(11) NOT NULL,
  `ex_name` char(50) DEFAULT NULL,
  `ex_http` char(200) DEFAULT NULL,
  `ex_des` varchar(500) DEFAULT NULL,
  `ant_img` char(150) DEFAULT NULL,
  `ex_paixu` int(11) DEFAULT '1000',
  `ex_flag` int(11) DEFAULT '1',
  `ex_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sc_express`
--

INSERT INTO `sc_express` (`ID`, `ex_name`, `ex_http`, `ex_des`, `ant_img`, `ex_paixu`, `ex_flag`, `ex_time`) VALUES
(2, 'DHL', 'http://www.dhl.com', 'DHL (3-5 working days only)', '../Images/other/210314050253_6888.gif,', 1, 1, '2021-03-14 09:02:55'),
(4, 'Fedex', 'https://www.fedex.com', 'fedex (7-10 working days only)', '../Images/other/210310032014_396.png,', 10000, 1, '2021-03-10 07:20:45');

-- --------------------------------------------------------

--
-- 表的结构 `sc_freeship`
--

CREATE TABLE `sc_freeship` (
  `ID` int(11) NOT NULL,
  `free_price` char(10) DEFAULT NULL,
  `free_flag` char(10) DEFAULT NULL,
  `free_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sc_freeship`
--

INSERT INTO `sc_freeship` (`ID`, `free_price`, `free_flag`, `free_time`) VALUES
(1, '50', '1', '2021-03-14 09:48:19');

-- --------------------------------------------------------

--
-- 表的结构 `sc_images`
--

CREATE TABLE `sc_images` (
  `ID` int(11) NOT NULL,
  `images_url` varchar(300) DEFAULT NULL,
  `images_name` varchar(250) DEFAULT NULL,
  `images_category` varchar(200) DEFAULT NULL,
  `images_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `sc_info`
--

CREATE TABLE `sc_info` (
  `ID` int(11) NOT NULL,
  `info_title` varchar(300) DEFAULT NULL,
  `info_key` varchar(500) DEFAULT NULL,
  `info_des` varchar(1000) DEFAULT NULL,
  `info_url` char(100) DEFAULT NULL,
  `contents` longtext,
  `ant_img` char(200) DEFAULT NULL,
  `info_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `info_cat` int(11) DEFAULT NULL,
  `info_tj` int(11) NOT NULL DEFAULT '0',
  `info_autu` char(100) DEFAULT NULL,
  `info_flag` char(100) DEFAULT NULL,
  `info_paixu` int(11) DEFAULT NULL,
  `info_open` int(11) DEFAULT '1',
  `languageID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sc_info`
--

INSERT INTO `sc_info` (`ID`, `info_title`, `info_key`, `info_des`, `info_url`, `contents`, `ant_img`, `info_time`, `info_cat`, `info_tj`, `info_autu`, `info_flag`, `info_paixu`, `info_open`, `languageID`) VALUES
(10, 'About us', '', '', 'Abou-us', '&lt;p&gt;\r\n	summary&lt;br /&gt;\r\n&lt;br /&gt;\r\n	&lt;p&gt;\r\n		Semcms is very suitable for foreign trade enterprises and E-commerce Internet applications. Since its first release in December 2009, semcms has continuously expanded its share of foreign trade market by relying on excellent user experience and leading technology.&amp;nbsp;\r\n	&lt;/p&gt;\r\n	&lt;p&gt;\r\n		At present, it has become one of the most popular English foreign trade websites in China. In the accumulation of the original enterprise website system, has developed foreign trade retail and wholesale system: semcms foreign trade mall system.\r\n	&lt;/p&gt;\r\nSemcms foreign trade mall system (hereinafter referred to as scshop) is a set of self-developed open source online store (BTC) system, which is mainly applied to retail and wholesale online sales products. It is compatible with ie, Firefox, Google, 360 and other mainstream browsers. At present, it has access to PayPal, western Union and other payment systems, and can be customized to develop access to credit card collection channel according to demand.&lt;br /&gt;\r\nScshop architecture: front end HTML5 + div + CSS, back end: PHP + MySQL with Apache can run under windows, Linux system.&lt;br /&gt;\r\nScshop is written with UTF-8 code.&lt;br /&gt;\r\n&lt;br /&gt;\r\nMain features:&lt;br /&gt;\r\n&lt;br /&gt;\r\nFast: small volume, fast loading speed.&lt;br /&gt;\r\nOpen source: open source, high level, high quality.&lt;br /&gt;\r\nExpansion: the function can be increased or decreased according to the demand, and the secondary development can be carried out.&lt;br /&gt;\r\nStyle: it&#039;s easy to modify the editing style, just need to modify a CSS file, compatible with computer, mobile and pad.&lt;br /&gt;\r\nCompatible: support most mainstream browsers, such as ie, Firefox, Google, 360, etc.&lt;br /&gt;\r\nSEO: user defined URL, keyword, brief description, title tag, image file name, static whole site.&lt;br /&gt;\r\nThumbnail: the uploaded product image can automatically generate size map, so that the front loading speed.&lt;br /&gt;\r\nTemplate: back end one click switch application.&lt;br /&gt;\r\n&lt;br /&gt;\r\nFunction module:&lt;br /&gt;\r\n&lt;br /&gt;\r\nAccording to the system requirements, there are mainly the following sections.&lt;br /&gt;\r\nSystem back end&lt;br /&gt;\r\nIntegrated management:&lt;br /&gt;\r\nGlobal parameters, navigation management, gallery management, message management, comment management&lt;br /&gt;\r\nDownload management, friend chain management, carousel management, template management, account management&lt;br /&gt;\r\nPermission assignment, email template, subscription management, etc&lt;br /&gt;\r\nMall management&lt;br /&gt;\r\nCommodity catalog, commodity management, attribute management, discount management, payment management&lt;br /&gt;\r\nLogistics management, regional management&lt;br /&gt;\r\n&lt;br /&gt;\r\ninformation management&lt;br /&gt;\r\nBlog directory, blog management, about us, service management&lt;br /&gt;\r\nSales management&lt;br /&gt;\r\nOrder management, member management&lt;br /&gt;\r\nSystem front end&lt;br /&gt;\r\nHome page, product center, blog, about us, help center, contact me&lt;br /&gt;\r\nWe are a member center, shopping cart, settlement center.&lt;br /&gt;\r\n&lt;br /&gt;\r\nSystem expansion&lt;br /&gt;\r\nMulti language function, credit card collection channel, single page system, template customization&lt;br /&gt;\r\nFunction customization, etc.&lt;br /&gt;\r\n&lt;br /&gt;\r\nOperating environment&lt;br /&gt;\r\nPHP 5.6+&lt;br /&gt;\r\nMySQL 5.6&lt;br /&gt;\r\nApache&lt;br /&gt;\r\nLinux or windows&lt;br /&gt;\r\n&lt;/p&gt;', NULL, '2020-12-13 07:54:34', NULL, 0, NULL, 'A', 10000, 1, 1),
(11, 'Payment Information', 'Payment Information', 'Payment Information', 'Payment-Information', 'Exchange Rates&lt;br /&gt;\r\nAll transactions are made in Canadian dollars. All currency conversion information provided on this site is for informational purposes only. The exchange rate that is used when making a purchase is determined by your credit card provider at the time of purchase.&lt;br /&gt;\r\n&lt;br /&gt;\r\nRefunds are processed in Canadian dollars. Because exchange rates vary from day to day, refunds made to international customers may differ slightly from the purchase amount. Any such variances may also be due to fees charged by credit card issuers and payment institutions. These factors are outside our control and we cannot be held responsible for such variances.&lt;br /&gt;\r\n&lt;br /&gt;\r\nPayment Methods&lt;br /&gt;\r\nWe accept payment by Visa, Mastercard, American Express, PayPal, Sezzle, WeChat Pay, AliPay, and UnionPay.&lt;br /&gt;\r\n&lt;br /&gt;\r\nOccasionally, we may require additional information to verify your identity. In this case we will contact you by email or by telephone. We reserve the right to cancel an order for any reason.&lt;br /&gt;\r\n&lt;br /&gt;\r\nPre-Orders&lt;br /&gt;\r\nPurchase of items marked &quot;Pre-order&quot; is not a guarantee of delivery and may be cancelled due to factors outside of our control, such as production, logistical, or quality control issues. Delivery dates provided in pre-order item descriptions are estimates and subject to change. Pre-order items are non-refundable and may be returned for exchange or store credit only.&lt;br /&gt;', NULL, '2020-12-13 07:56:23', NULL, 0, NULL, 'S', 10000, 1, 1),
(13, 'Shopping Guide', 'Shopping Guide', 'Shopping Guide', 'Shopping-Guide', 'We deliver your package through international couriers like Air Mail, Registered Air Mail, EMS, Fedex, UPS and DHL. Customers can choose the shipping method they like. Friendly reminder: if your package contained too many branded products, we may deliver it via different couriers in order to avoid the customs problem.&lt;br /&gt;\r\n&lt;br /&gt;\r\nWe deliver your package through 3 ways.&lt;br /&gt;\r\n&lt;br /&gt;\r\n&amp;nbsp; &amp;nbsp; Express Shipping: takes about 3-5 business days, the fastest way to ship your product globally, is carried by one of the following global express shipping companies: DHL, UPS, FedEx, EMS.&lt;br /&gt;\r\n&amp;nbsp; &amp;nbsp; Economic Shipping/Direct Line: It typically takes 5 - 10 business days to arrive to your major destination. This shipping method works in most countries except some remote regions, such as USA, UK, Canada, France, Germany, Australia, and Spain. The package is flied direct to your country and then deliver by your local postal courier service like USPS, Yodel,etc.&lt;br /&gt;\r\n&amp;nbsp; &amp;nbsp; Global Postal Service: Registered Air Mail (with Tracking number) takes 10 – 20 business days.&lt;br /&gt;\r\n&lt;br /&gt;\r\nDelivery Time&lt;br /&gt;\r\n&lt;br /&gt;\r\nDelivery Time= Processing Time + Packaging Time + Shipping Time&lt;br /&gt;\r\n&lt;br /&gt;\r\nProcessing time:&lt;br /&gt;\r\n&lt;br /&gt;\r\nWe offers 1-2 days process time on most online orderes meaning that your order will ship within a 48-hour period from the time it was received,excluding weekends and holidays.&lt;br /&gt;\r\n&lt;br /&gt;\r\nIf you place an order early, we will process your order earlier, and you items are probably shipped at the same day. For expedited order, it will be processed priorly. And if we have no stocks in our warehouse, the ship will be short delayed, usually, your items will be delivered within 1-2 days.For some customized items, it may take one week or more from dispatch.If this happens, we will let you know ASAP.&lt;br /&gt;\r\n&lt;br /&gt;\r\nPackaging time:&lt;br /&gt;\r\n&lt;br /&gt;\r\nAfter processing your order, we will send a confirmation to the warehouse. Then your order will be shipped out within 1-2 business days if it is still in stock. You will be informed if the products are out of stock.&lt;br /&gt;\r\n&lt;br /&gt;\r\n&amp;nbsp;Over 94.6% orders will be shipped in 1-2 days, and just 3.2% orders will be shipped in 3-4 days. For the 2.2% custom orders will be shipped in 1 week.&lt;br /&gt;\r\n&lt;br /&gt;\r\nShipping time:&lt;br /&gt;\r\n&lt;br /&gt;\r\nThe time it takes for the shipping companies to deliver your package to you.&lt;br /&gt;\r\n&lt;br /&gt;\r\nIn general, the shipping time of each shipping method is as below:&lt;br /&gt;\r\n&lt;br /&gt;\r\nGlobal Postal Service(Air Mail): Most shipped packages will be delivered to you within 10-25 business days from the day they are shipped.&lt;br /&gt;\r\n&lt;br /&gt;\r\nEconomic Shipping/Direct Line: Most shipped packages will be delivered to you within 5 - 10 business days from the day they are shipped.&lt;br /&gt;\r\n&lt;br /&gt;\r\nExpress Shipping: Most shipped packages will be delivered to you within 3-5 business days from the day they are shipped.&lt;br /&gt;\r\n&lt;br /&gt;', NULL, '2020-12-18 09:12:18', NULL, 0, NULL, 'S', 10000, 1, 1),
(15, 'Delivery Information', 'Delivery Information', 'Delivery Information', 'Delivery-Information', 'Delivery Information', NULL, '2021-02-18 09:25:49', NULL, 0, NULL, 'A', 10000, 1, 1),
(16, 'smartwatch is a wearable computer in the form of a watch', '', 'smartwatch is a wearable computer in the form of a watch; modern smartwatches provide a local touchscreen interface for daily use, while an associated smartphone app provides for management and teleme', '', '&lt;p&gt;\r\n	smartwatch is a wearable computer in the form of a watch; modern smartwatches provide a local touchscreen interface for daily use, while an associated smartphone app provides for management and telemetry (such as long-term biomonitoring).&amp;nbsp;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	While early models could perform basic tasks, such as calculations, digital time telling, translations, and game-playing, 2010s smartwatches have more general functionality closer to smartphones, including mobile apps, a mobile operating system and WiFi/Bluetooth connectivity.&amp;nbsp;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	Some smartwatches function as portable media players, with FM radio and playback of digital audio and video files via a Bluetooth headset.&amp;nbsp;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	Some models, called watch phones (or vice versa), have mobile cellular functionality like making&amp;nbsp;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;p style=&quot;white-space:normal;&quot;&gt;\r\n		smartwatch is a wearable computer in the form of a watch; modern smartwatches provide a local touchscreen interface for daily use, while an associated smartphone app provides for management and telemetry (such as long-term biomonitoring).&amp;nbsp;\r\n	&lt;/p&gt;\r\n	&lt;p style=&quot;white-space:normal;&quot;&gt;\r\n		While early models could perform basic tasks, such as calculations, digital time telling, translations, and game-playing, 2010s smartwatches have more general functionality closer to smartphones, including mobile apps, a mobile operating system and WiFi/Bluetooth connectivity.&amp;nbsp;\r\n	&lt;/p&gt;\r\n	&lt;p style=&quot;white-space:normal;&quot;&gt;\r\n		Some smartwatches function as portable media players, with FM radio and playback of digital audio and video files via a Bluetooth headset.&amp;nbsp;\r\n	&lt;/p&gt;\r\n	&lt;p style=&quot;white-space:normal;&quot;&gt;\r\n		Some models, called watch phones (or vice versa), have mobile cellular functionality like making&amp;nbsp;\r\n	&lt;/p&gt;\r\n	&lt;p style=&quot;white-space:normal;&quot;&gt;\r\n		smartwatch is a wearable computer in the form of a watch; modern smartwatches provide a local touchscreen interface for daily use, while an associated smartphone app provides for management and telemetry (such as long-term biomonitoring).&amp;nbsp;\r\n	&lt;/p&gt;\r\n	&lt;p style=&quot;white-space:normal;&quot;&gt;\r\n		While early models could perform basic tasks, such as calculations, digital time telling, translations, and game-playing, 2010s smartwatches have more general functionality closer to smartphones, including mobile apps, a mobile operating system and WiFi/Bluetooth connectivity.&amp;nbsp;\r\n	&lt;/p&gt;\r\n	&lt;p style=&quot;white-space:normal;&quot;&gt;\r\n		Some smartwatches function as portable media players, with FM radio and playback of digital audio and video files via a Bluetooth headset.&amp;nbsp;\r\n	&lt;/p&gt;\r\n	&lt;p style=&quot;white-space:normal;&quot;&gt;\r\n		Some models, called watch phones (or vice versa), have mobile cellular functionality like making&amp;nbsp;\r\n	&lt;/p&gt;\r\n&lt;/p&gt;', '../Images/blog/210309035124_2357.jpg,', '2021-03-09 07:49:36', 3, 1, 'Admin', 'B', 10000, 1, 1),
(17, 'modern smartwatches provide a local touchscreen interface for daily use', '', 'smartwatch is a wearable computer in the form of a watch; modern smartwatches provide a local touchscreen interface for daily use, while an associated smartphone app provides for management and teleme', '', '&lt;p style=&quot;white-space:normal;&quot;&gt;\r\n	smartwatch is a wearable computer in the form of a watch; modern smartwatches provide a local touchscreen interface for daily use, while an associated smartphone app provides for management and telemetry (such as long-term biomonitoring).&amp;nbsp;\r\n&lt;/p&gt;\r\n&lt;p style=&quot;white-space:normal;&quot;&gt;\r\n	While early models could perform basic tasks, such as calculations, digital time telling, translations, and game-playing, 2010s smartwatches have more general functionality closer to smartphones, including mobile apps, a mobile operating system and WiFi/Bluetooth connectivity.&amp;nbsp;\r\n&lt;/p&gt;\r\n&lt;p style=&quot;white-space:normal;&quot;&gt;\r\n	Some smartwatches function as portable media players, with FM radio and playback of digital audio and video files via a Bluetooth headset.&amp;nbsp;\r\n&lt;/p&gt;\r\n&lt;p style=&quot;white-space:normal;&quot;&gt;\r\n	Some models, called watch phones (or vice versa), have mobile cellular functionality like making&amp;nbsp;\r\n&lt;/p&gt;\r\n&lt;p style=&quot;white-space:normal;&quot;&gt;\r\n	smartwatch is a wearable computer in the form of a watch; modern smartwatches provide a local touchscreen interface for daily use, while an associated smartphone app provides for management and telemetry (such as long-term biomonitoring).&amp;nbsp;\r\n&lt;/p&gt;\r\n&lt;p style=&quot;white-space:normal;&quot;&gt;\r\n	While early models could perform basic tasks, such as calculations, digital time telling, translations, and game-playing, 2010s smartwatches have more general functionality closer to smartphones, including mobile apps, a mobile operating system and WiFi/Bluetooth connectivity.&amp;nbsp;\r\n&lt;/p&gt;\r\n&lt;p style=&quot;white-space:normal;&quot;&gt;\r\n	Some smartwatches function as portable media players, with FM radio and playback of digital audio and video files via a Bluetooth headset.&amp;nbsp;\r\n&lt;/p&gt;\r\n&lt;p style=&quot;white-space:normal;&quot;&gt;\r\n	Some models, called watch phones (or vice versa), have mobile cellular functionality like making&amp;nbsp;\r\n&lt;/p&gt;\r\n&lt;p style=&quot;white-space:normal;&quot;&gt;\r\n	smartwatch is a wearable computer in the form of a watch; modern smartwatches provide a local touchscreen interface for daily use, while an associated smartphone app provides for management and telemetry (such as long-term biomonitoring).&amp;nbsp;\r\n&lt;/p&gt;\r\n&lt;p style=&quot;white-space:normal;&quot;&gt;\r\n	While early models could perform basic tasks, such as calculations, digital time telling, translations, and game-playing, 2010s smartwatches have more general functionality closer to smartphones, including mobile apps, a mobile operating system and WiFi/Bluetooth connectivity.&amp;nbsp;\r\n&lt;/p&gt;\r\n&lt;p style=&quot;white-space:normal;&quot;&gt;\r\n	Some smartwatches function as portable media players, with FM radio and playback of digital audio and video files via a Bluetooth headset.&amp;nbsp;\r\n&lt;/p&gt;\r\n&lt;p style=&quot;white-space:normal;&quot;&gt;\r\n	Some models, called watch phones (or vice versa), have mobile cellular functionality like making&amp;nbsp;\r\n&lt;/p&gt;', '../Images/blog/210309035154_7880.jpg,', '2021-03-09 07:51:56', 4, 1, 'Admin', 'B', 10000, 1, 1),
(18, 'while an associated smartphone app provides for management and telemetry', '', 'smartwatch is a wearable computer in the form of a watch; modern smartwatches provide a local touchscreen interface for daily use, while an associated smartphone app provides for management and teleme', '', '&lt;p style=&quot;white-space:normal;&quot;&gt;\r\n	smartwatch is a wearable computer in the form of a watch; modern smartwatches provide a local touchscreen interface for daily use, while an associated smartphone app provides for management and telemetry (such as long-term biomonitoring).&amp;nbsp;\r\n&lt;/p&gt;\r\n&lt;p style=&quot;white-space:normal;&quot;&gt;\r\n	While early models could perform basic tasks, such as calculations, digital time telling, translations, and game-playing, 2010s smartwatches have more general functionality closer to smartphones, including mobile apps, a mobile operating system and WiFi/Bluetooth connectivity.&amp;nbsp;\r\n&lt;/p&gt;\r\n&lt;p style=&quot;white-space:normal;&quot;&gt;\r\n	Some smartwatches function as portable media players, with FM radio and playback of digital audio and video files via a Bluetooth headset.&amp;nbsp;\r\n&lt;/p&gt;\r\n&lt;p style=&quot;white-space:normal;&quot;&gt;\r\n	Some models, called watch phones (or vice versa), have mobile cellular functionality like making&amp;nbsp;\r\n&lt;/p&gt;\r\n&lt;p style=&quot;white-space:normal;&quot;&gt;\r\n	smartwatch is a wearable computer in the form of a watch; modern smartwatches provide a local touchscreen interface for daily use, while an associated smartphone app provides for management and telemetry (such as long-term biomonitoring).&amp;nbsp;\r\n&lt;/p&gt;\r\n&lt;p style=&quot;white-space:normal;&quot;&gt;\r\n	While early models could perform basic tasks, such as calculations, digital time telling, translations, and game-playing, 2010s smartwatches have more general functionality closer to smartphones, including mobile apps, a mobile operating system and WiFi/Bluetooth connectivity.&amp;nbsp;\r\n&lt;/p&gt;\r\n&lt;p style=&quot;white-space:normal;&quot;&gt;\r\n	Some smartwatches function as portable media players, with FM radio and playback of digital audio and video files via a Bluetooth headset.&amp;nbsp;\r\n&lt;/p&gt;\r\n&lt;p style=&quot;white-space:normal;&quot;&gt;\r\n	Some models, called watch phones (or vice versa), have mobile cellular functionality like making&amp;nbsp;\r\n&lt;/p&gt;\r\n&lt;p style=&quot;white-space:normal;&quot;&gt;\r\n	smartwatch is a wearable computer in the form of a watch; modern smartwatches provide a local touchscreen interface for daily use, while an associated smartphone app provides for management and telemetry (such as long-term biomonitoring).&amp;nbsp;\r\n&lt;/p&gt;\r\n&lt;p style=&quot;white-space:normal;&quot;&gt;\r\n	While early models could perform basic tasks, such as calculations, digital time telling, translations, and game-playing, 2010s smartwatches have more general functionality closer to smartphones, including mobile apps, a mobile operating system and WiFi/Bluetooth connectivity.&amp;nbsp;\r\n&lt;/p&gt;\r\n&lt;p style=&quot;white-space:normal;&quot;&gt;\r\n	Some smartwatches function as portable media players, with FM radio and playback of digital audio and video files via a Bluetooth headset.&amp;nbsp;\r\n&lt;/p&gt;\r\n&lt;p style=&quot;white-space:normal;&quot;&gt;\r\n	Some models, called watch phones (or vice versa), have mobile cellular functionality like making&amp;nbsp;\r\n&lt;/p&gt;', '../Images/blog/210309035222_7548.jpg,', '2021-03-09 07:52:27', 3, 1, 'Admin', 'B', 10000, 1, 1),
(19, 'Privacy Policy', 'Privacy Policy', 'Privacy Policy', 'Privacy-Policy', 'Privacy Policy', NULL, '2021-03-10 00:50:13', NULL, 0, NULL, 'A', 10000, 1, 1),
(20, 'Terms &amp; Conditions', 'Terms &amp; Conditions', 'Terms &amp; Conditions', 'Terms-Conditions', 'Terms &amp;amp; Conditions', NULL, '2021-03-10 00:50:36', NULL, 0, NULL, 'A', 10000, 1, 1),
(21, 'Return Policy', 'Return Policy', 'Return Policy', 'Return-Policy', 'Return Policy', NULL, '2021-03-10 00:53:01', NULL, 0, NULL, 'S', 10000, 1, 1),
(22, 'FAQs', 'FAQs', 'FAQs', 'FAQs', 'FAQs', NULL, '2021-03-10 00:53:34', NULL, 0, NULL, 'S', 10000, 1, 1);

-- --------------------------------------------------------

--
-- 表的结构 `sc_lable`
--

CREATE TABLE `sc_lable` (
  `ID` int(11) NOT NULL,
  `tag_content` text COMMENT '标签内容',
  `tag_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `languageID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sc_lable`
--

INSERT INTO `sc_lable` (`ID`, `tag_content`, `tag_time`, `languageID`) VALUES
(5, '{&quot;home&quot;:&quot;Home&quot;,&quot;product&quot;:&quot;Products&quot;,&quot;productcat&quot;:&quot;All Categories&quot;,&quot;blog&quot;:&quot;Blog&quot;,&quot;lastblog&quot;:&quot;Last Blog&quot;,&quot;about&quot;:&quot;About us&quot;,&quot;contact&quot;:&quot;Contact Us&quot;,&quot;featurecat&quot;:&quot;Feature Categories&quot;,&quot;featureproduct&quot;:&quot;Feature Products&quot;,&quot;newproduct&quot;:&quot;New Products&quot;,&quot;rqproduct&quot;:&quot;Hot Products&quot;,&quot;zkproduct&quot;:&quot;Promotional Products&quot;,&quot;reproduct&quot;:&quot;related products&quot;,&quot;currency&quot;:&quot;Currency&quot;,&quot;infomation&quot;:&quot;Information&quot;,&quot;customerservicce&quot;:&quot;Customer Service&quot;,&quot;subscribe&quot;:&quot;Subscribe&quot;,&quot;subscribetitle&quot;:&quot;Subscribe for Join Us!&quot;,&quot;subscribedes&quot;:&quot;Subcribe to get information coupons.&quot;,&quot;search&quot;:&quot;Search&quot;,&quot;readmore&quot;:&quot;Read more&quot;,&quot;showre&quot;:&quot;Showing all {TS} results&quot;,&quot;sortby&quot;:&quot;Sort by&quot;,&quot;idl&quot;:&quot;Date,old to new&quot;,&quot;idh&quot;:&quot;Date,new to old&quot;,&quot;pricel&quot;:&quot;price,low to high&quot;,&quot;priceh&quot;:&quot;price,high to low&quot;,&quot;namea&quot;:&quot;name,A to Z&quot;,&quot;namez&quot;:&quot;name,Z to A&quot;,&quot;addtocart&quot;:&quot;Add To Cart&quot;,&quot;addqty&quot;:&quot;Quantity&quot;,&quot;addzk&quot;:&quot;Discount&quot;,&quot;wholeprie&quot;:&quot;Wholesale Price&quot;,&quot;adescription&quot;:&quot;Description&quot;,&quot;areviews&quot;:&quot;Reviews&quot;,&quot;wirteareviews&quot;:&quot;Write a views&quot;,&quot;addadress&quot;:&quot;Add an address&quot;,&quot;acomments&quot;:&quot;Message&quot;,&quot;seatext&quot;:&quot;Enter your keywords !&quot;,&quot;subscribetxt&quot;:&quot;Enter your E-mail !&quot;,&quot;optional&quot;:&quot;Optional&quot;,&quot;oldpassword&quot;:&quot;Original password&quot;,&quot;newpassword&quot;:&quot;New password&quot;,&quot;passwordleght&quot;:&quot;The password length is at least 8 digits&quot;,&quot;login&quot;:&quot;Login&quot;,&quot;regedit&quot;:&quot;Register&quot;,&quot;firstname&quot;:&quot;First Name&quot;,&quot;lastname&quot;:&quot;Last Name &quot;,&quot;emailadd&quot;:&quot;E-mail Address&quot;,&quot;userpass&quot;:&quot;Password&quot;,&quot;uname&quot;:&quot;Name&quot;,&quot;ucompany&quot;:&quot;Company (optional)&quot;,&quot;fulladdress&quot;:&quot;Full Address&quot;,&quot;city&quot;:&quot;City&quot;,&quot;state&quot;:&quot;State&quot;,&quot;zip&quot;:&quot;Zip/Postal Code&quot;,&quot;region&quot;:&quot;Country/Region&quot;,&quot;phone&quot;:&quot;Phone&quot;,&quot;save&quot;:&quot;SAVE&quot;,&quot;mymember&quot;:&quot;Member center&quot;,&quot;myorder&quot;:&quot;My order&quot;,&quot;myaddress&quot;:&quot;My address&quot;,&quot;myaccount&quot;:&quot;My account&quot;,&quot;mycoupon&quot;:&quot; My coupon&quot;,&quot;mycomment&quot;:&quot;My comments&quot;,&quot;mywish&quot;:&quot;My wish list&quot;,&quot;orderno&quot;:&quot;Order No.&quot;,&quot;orderdate&quot;:&quot;Date&quot;,&quot;orderpaymethod&quot;:&quot;Payment&quot;,&quot;orderpaid&quot;:&quot;Paid&quot;,&quot;orderunpaid&quot;:&quot;unPaid&quot;,&quot;ordeshipped&quot;:&quot;Shipping&quot;,&quot;ordesdelivered&quot;:&quot;Shipped&quot;,&quot;ordesundelivered&quot;:&quot;Not shipped&quot;,&quot;ordeoperation&quot;:&quot;Operation&quot;,&quot;shoppingcart&quot;:&quot;Shopping Cart&quot;,&quot;Completed&quot;:&quot;Completed&quot;,&quot;mycart&quot;:&quot;My Cart&quot;,&quot;addproduct&quot;:&quot;Product&quot;,&quot;addprice&quot;:&quot;Price&quot;,&quot;addtotal&quot;:&quot;Total&quot;,&quot;addsutotal&quot;:&quot;Subtotal&quot;,&quot;addconfirm&quot;:&quot;Confirm&quot;,&quot;addcancel&quot;:&quot;Cancel&quot;,&quot;addempty&quot;:&quot;Your cart is currently empty.&quot;,&quot;addcontinue&quot;:&quot;continue shopping&quot;,&quot;addplaceorder&quot;:&quot;Place Order&quot;,&quot;checkout&quot;:&quot;Check Out&quot;,&quot;contactinfo&quot;:&quot;CONTACT INFOMATION&quot;,&quot;shippingadress&quot;:&quot;SHIPPING ADDRESS&quot;,&quot;shippingmethod&quot;:&quot;SHIPPING METHOD&quot;,&quot;paymethod&quot;:&quot;PAYMENT&quot;,&quot;freight&quot;:&quot;Freight&quot;,&quot;addcartdes&quot;:&quot;Product successfully added to your shopping cart&quot;,&quot;loginsucess&quot;:&quot;Login was successful&quot;,&quot;loginfailed&quot;:&quot;Login failed&quot;,&quot;Required&quot;:&quot;* is Required !&quot;,&quot;correctemail&quot;:&quot;Please enter the correct email address&quot;,&quot;sameemail&quot;:&quot;Email address already exists&quot;,&quot;accounterr&quot;:&quot;Sorry, the account with this keycode was not found. &quot;,&quot;signout&quot;:&quot;Sign Out&quot;,&quot;submitsuf&quot;:&quot;Submitted successfully&quot;,&quot;submitfaile&quot;:&quot;Failed to submit&quot;,&quot;loginoregedit&quot;:&quot;Please login or register&quot;,&quot;selectaddress&quot;:&quot;Please select shipping address&quot;,&quot;selectexpress&quot;:&quot;Please choose express&quot;,&quot;selectpayment&quot;:&quot;Please choose the payment method&quot;,&quot;Apply&quot;:&quot;Apply&quot;,&quot;discountcode&quot;:&quot;gift card or discount code&quot;,&quot;nodiscountcode&quot;:&quot;No coupons available&quot;,&quot;resigin&quot;:&quot;Please log in again after timeout&quot;,&quot;ordersucess&quot;:&quot;Thank you checkout success !!! &quot;,&quot;returnhome&quot;:&quot;Return Home&quot;,&quot;closepage&quot;:&quot;Close window&quot;,&quot;expritime&quot;:&quot;Expiration time&quot;,&quot;rating&quot;:&quot;Rating&quot;,&quot;resultsearh&quot;:&quot;Sorry, there are no results available right now.&quot;}', '2021-02-27 12:11:35', 1);

-- --------------------------------------------------------

--
-- 表的结构 `sc_language`
--

CREATE TABLE `sc_language` (
  `ID` int(11) NOT NULL,
  `language_cname` char(50) DEFAULT NULL,
  `language_ename` char(50) DEFAULT NULL,
  `language_url` char(100) DEFAULT NULL,
  `language_paixu` int(11) DEFAULT '10000',
  `language_mulu` int(11) DEFAULT '0',
  `ant_img` char(100) DEFAULT NULL,
  `language_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `language_open` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sc_language`
--

INSERT INTO `sc_language` (`ID`, `language_cname`, `language_ename`, `language_url`, `language_paixu`, `language_mulu`, `ant_img`, `language_time`, `language_open`) VALUES
(1, '英语', 'English', 'en', 10000, 1, '../Images/other/201222021735_8775.png,', '2020-12-22 06:28:52', 1),
(2, '中文', 'Chinese', 'cn', 1, 0, '../Images/other/201222022227_619.png,', '2020-12-22 12:12:46', 0);

-- --------------------------------------------------------

--
-- 表的结构 `sc_link`
--

CREATE TABLE `sc_link` (
  `ID` int(11) NOT NULL,
  `link_name` char(200) DEFAULT NULL,
  `link_url` char(200) DEFAULT NULL,
  `link_time` timestamp NULL DEFAULT NULL,
  `link_paixu` int(11) DEFAULT '10000',
  `languageID` int(11) DEFAULT NULL,
  `ant_img` char(200) DEFAULT NULL,
  `link_open` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sc_link`
--

INSERT INTO `sc_link` (`ID`, `link_name`, `link_url`, `link_time`, `link_paixu`, `languageID`, `ant_img`, `link_open`) VALUES
(1, 'a', 'http://www.sem-cms.com/', '2021-03-11 01:43:19', 1, 1, ',', 0);

-- --------------------------------------------------------

--
-- 表的结构 `sc_mailtemplate`
--

CREATE TABLE `sc_mailtemplate` (
  `ID` int(11) NOT NULL,
  `mt_fl` int(11) DEFAULT NULL,
  `mt_title` char(200) DEFAULT NULL,
  `contents` longtext,
  `mt_flag` int(11) NOT NULL DEFAULT '0',
  `mt_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sc_mailtemplate`
--

INSERT INTO `sc_mailtemplate` (`ID`, `mt_fl`, `mt_title`, `contents`, `mt_flag`, `mt_time`) VALUES
(2, 2, 'Want $10 off? Of course you do.', '&lt;span style=&quot;white-space:normal;&quot;&gt;编写内容&lt;/span&gt;', 1, '2021-03-11 06:39:01'),
(3, 1, 'Welcome to our  STORE!', '编写内容', 1, '2021-03-11 06:38:16'),
(4, 5, 'Reset Password', 'There was recently a request to change the password for your account.&lt;br /&gt;\r\nIf you requested this password change, please click on the following link to reset your password: {XXXXXX}&lt;br /&gt;\r\nIf clicking the link does not work, please copy and paste the URL into your browser instead. &lt;br /&gt;\r\nIf you did not make this request, you can ignore this message and your password will remain the same. &lt;br /&gt;\r\nThank you, 127.0.0.1:8888', 0, '2021-02-24 12:01:25'),
(5, 3, 'Order from {website}', '&lt;p&gt;\r\n	Order Number：{OrderNub}\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	Total：{Total}\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	Check the order details in the member center,Thank you !\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;', 1, '2021-02-27 07:39:58');

-- --------------------------------------------------------

--
-- 表的结构 `sc_member`
--

CREATE TABLE `sc_member` (
  `ID` int(11) NOT NULL,
  `me_email` char(100) NOT NULL,
  `me_firstname` char(200) DEFAULT NULL,
  `me_lastname` char(200) DEFAULT NULL,
  `me_whtasapp` char(200) DEFAULT NULL,
  `me_mbtype` char(200) DEFAULT NULL,
  `me_contry` char(200) DEFAULT NULL,
  `me_paswd` char(200) NOT NULL,
  `me_ip` char(200) DEFAULT NULL,
  `me_loginip` char(200) DEFAULT NULL,
  `me_flag` int(11) DEFAULT '0',
  `me_dltime` timestamp NULL DEFAULT NULL,
  `me_logintime` timestamp NULL DEFAULT NULL,
  `me_yzm` char(20) DEFAULT NULL,
  `me_yzmtime` char(50) DEFAULT NULL,
  `me_yzmsj` char(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sc_member`
--

INSERT INTO `sc_member` (`ID`, `me_email`, `me_firstname`, `me_lastname`, `me_whtasapp`, `me_mbtype`, `me_contry`, `me_paswd`, `me_ip`, `me_loginip`, `me_flag`, `me_dltime`, `me_logintime`, `me_yzm`, `me_yzmtime`, `me_yzmsj`) VALUES
(2, '1181698019@qq.com', 'Ant', 'SEMCMS', NULL, NULL, NULL, '550e1bafe077ff0b0b67f4e32f29d751', '127.0.0.1', '127.0.0.1', 0, '2021-03-14 13:16:39', '2021-02-16 07:29:56', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `sc_menu`
--

CREATE TABLE `sc_menu` (
  `ID` int(11) NOT NULL,
  `menu_name` varchar(50) DEFAULT NULL,
  `menu_link` varchar(100) DEFAULT NULL,
  `menu_xiala` int(11) DEFAULT '0',
  `languageID` int(11) DEFAULT NULL,
  `menu_paixu` int(11) DEFAULT '10000',
  `ant_img` char(200) DEFAULT NULL,
  `menu_open` int(11) DEFAULT '1',
  `menu_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sc_menu`
--

INSERT INTO `sc_menu` (`ID`, `menu_name`, `menu_link`, `menu_xiala`, `languageID`, `menu_paixu`, `ant_img`, `menu_open`, `menu_time`) VALUES
(3, 'Home', '/', 0, 1, 1, ',', 1, '2021-03-10 09:44:10'),
(4, 'Products', 'product/', 0, 1, 2, NULL, 1, '2020-12-30 03:54:23'),
(5, 'Blog', 'blog/', 0, 1, 3, NULL, 1, '2021-03-11 06:45:11'),
(6, 'Contact us', 'contact.html', 0, 1, 4, NULL, 1, '2021-02-20 07:28:12');

-- --------------------------------------------------------

--
-- 表的结构 `sc_msg`
--

CREATE TABLE `sc_msg` (
  `ID` int(11) NOT NULL,
  `msg_pid` int(11) DEFAULT NULL,
  `msg_email` char(50) DEFAULT NULL,
  `msg_name` char(200) DEFAULT NULL,
  `msg_tel` char(200) DEFAULT NULL,
  `msg_content` varchar(2000) DEFAULT NULL,
  `msg_ip` char(50) DEFAULT NULL,
  `languageID` int(11) DEFAULT NULL,
  `msg_type` int(11) DEFAULT '0',
  `msg_reply` varchar(500) DEFAULT NULL,
  `msg_flag` char(10) DEFAULT NULL COMMENT '区分 评论与留言',
  `msg_rating` char(10) DEFAULT '0' COMMENT '评论等级',
  `msg_time` timestamp NULL DEFAULT NULL,
  `msg_hftime` timestamp NULL DEFAULT NULL COMMENT '回复时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sc_msg`
--

INSERT INTO `sc_msg` (`ID`, `msg_pid`, `msg_email`, `msg_name`, `msg_tel`, `msg_content`, `msg_ip`, `languageID`, `msg_type`, `msg_reply`, `msg_flag`, `msg_rating`, `msg_time`, `msg_hftime`) VALUES
(17, 1, '1181698019@qq.com', 'Ant SEMCMS', NULL, 'Ultra-Thin Soft TPU Luxury Mobile Phone Case for iPhone 6 6S 7 8 Plus X XS Max XR 11 Pro Silicone Frosted Back Cover Slim Cases', '127.0.0.1', 1, 1, NULL, 'p', '4', '2021-02-21 02:06:09', NULL),
(20, NULL, '1181698019@qq.com', 'Mayi', NULL, 'hi,Semcms is very suitable for foreign trade enterprises and E-commerce Internet', '127.0.0.1', 1, 0, NULL, 'm', '0', '2021-03-11 01:49:53', NULL);

-- --------------------------------------------------------

--
-- 表的结构 `sc_mulu`
--

CREATE TABLE `sc_mulu` (
  `ID` int(11) NOT NULL,
  `ml_id` int(11) NOT NULL,
  `ml_name` char(50) DEFAULT NULL,
  `ml_link` char(100) DEFAULT NULL,
  `ml_paixu` int(11) NOT NULL DEFAULT '1000',
  `ml_open` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sc_mulu`
--

INSERT INTO `sc_mulu` (`ID`, `ml_id`, `ml_name`, `ml_link`, `ml_paixu`, `ml_open`) VALUES
(1, 1, '全局设置', 'Ant_Global.php', 10000, 1),
(2, 2, '商品目录', 'Ant_Cat.php', 10000, 1),
(3, 2, '商品管理', 'Ant_Pro.php', 10000, 1),
(4, 2, '属性管理', 'Ant_Suxin.php', 10000, 1),
(5, 2, '折扣管理', 'Ant_Zekou.php', 10000, 1),
(6, 3, '博客目录', 'Ant_BlogCat.php', 10000, 1),
(7, 3, '博客管理', 'Ant_Info.php?type=B', 10000, 1),
(8, 3, '关于我们', 'Ant_Info.php?type=A', 10000, 1),
(9, 3, '会员服务', 'Ant_Info.php?type=S', 10000, 1),
(10, 4, '区域管理', 'Ant_M_Contry.php', 10000, 1),
(11, 4, '物流设置', 'Ant_M_Express.php', 10000, 1),
(12, 4, '运费方式', 'Ant_M_Freeship.php', 10000, 1),
(13, 4, '货币设置', 'Ant_M_Currency.php', 10000, 1),
(14, 4, '支付设置', 'Ant_M_Pay.php', 10000, 1),
(15, 4, '优惠券管理', 'Ant_M_Coup.php', 10000, 1),
(16, 5, '会员管理', 'Ant_M_Member.php', 10000, 1),
(17, 5, '订单管理', 'Ant_M_Order.php', 10000, 1),
(18, 1, '邮件模版', 'Ant_Emtemplate.php', 10000, 1),
(19, 1, '轮播管理', 'Ant_Banner.php', 10000, 1),
(20, 1, '导航管理', 'Ant_Menu.php', 10000, 1),
(21, 1, '友链管理', 'Ant_Link.php', 10000, 1),
(22, 1, '资料下载', 'Ant_Down.php', 10000, 1),
(23, 1, '订阅管理', 'Ant_Email.php', 10000, 1),
(24, 1, '留言管理', 'Ant_Message.php?type=m', 10000, 1),
(25, 1, '用户管理', 'Ant_Users.php', 1, 1),
(26, 1, 'SEO设置', 'Ant_Seo.php', 100001, 1),
(27, 1, '评论管理', 'Ant_Message.php?type=p', 10000, 1),
(28, 1, '模版管理', 'Ant_Template.php', 10000, 1),
(29, 6, '查询分析', 'Ant_S_Check.php', 10000, 1);

-- --------------------------------------------------------

--
-- 表的结构 `sc_order`
--

CREATE TABLE `sc_order` (
  `ID` int(11) NOT NULL,
  `userID` int(11) DEFAULT NULL,
  `order_productID` varchar(500) DEFAULT NULL,
  `order_productsl` varchar(500) DEFAULT NULL,
  `order_productdjg` varchar(500) DEFAULT NULL,
  `order_number` varchar(500) DEFAULT NULL,
  `order_biuldadd` varchar(1000) DEFAULT NULL,
  `order_shipadd` varchar(1000) DEFAULT NULL,
  `order_curry` char(20) DEFAULT NULL,
  `order_ship` char(100) DEFAULT NULL,
  `order_price` varchar(100) DEFAULT NULL,
  `order_prodctzj` char(100) DEFAULT NULL,
  `order_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `order_zt` char(100) DEFAULT '0' COMMENT '回收站',
  `order_payfs` char(100) DEFAULT NULL,
  `order_weight` char(100) DEFAULT NULL,
  `order_shipprice` char(100) DEFAULT NULL,
  `order_flag` char(50) DEFAULT '0' COMMENT '是否付款',
  `order_message` varchar(2000) DEFAULT NULL,
  `order_ip` char(100) DEFAULT NULL,
  `order_fh` char(10) DEFAULT '0',
  `order_express` char(50) DEFAULT NULL,
  `order_exnb` varchar(500) DEFAULT NULL COMMENT '快递号',
  `order_paynote` varchar(1000) DEFAULT NULL COMMENT '付款说明',
  `order_sx` varchar(2000) DEFAULT NULL COMMENT '产品属性',
  `order_dis` char(20) DEFAULT NULL COMMENT '优惠价',
  `order_disnm` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sc_order`
--

INSERT INTO `sc_order` (`ID`, `userID`, `order_productID`, `order_productsl`, `order_productdjg`, `order_number`, `order_biuldadd`, `order_shipadd`, `order_curry`, `order_ship`, `order_price`, `order_prodctzj`, `order_time`, `order_zt`, `order_payfs`, `order_weight`, `order_shipprice`, `order_flag`, `order_message`, `order_ip`, `order_fh`, `order_express`, `order_exnb`, `order_paynote`, `order_sx`, `order_dis`, `order_disnm`) VALUES
(50, 2, '1,6,', '1,2,', '17.99,16.19,', 'G314142647090326', NULL, 'SEM CMS&lt;br&gt;188# JinQing JiaoJiang , TaiZhou , Zhejiang , China , 310000&lt;br&gt;13812345678&lt;br&gt;SEMCMS CO.,LTD', '$', NULL, '17.99,32.38,', '59.37', '2021-03-14 09:31:04', '0', '2_7', '0.2', '9.00', '0', '', '127.0.0.1', '0', '4', NULL, NULL, '&lt;i class=&quot;fa fa-genderless&quot; aria-hidden=&quot;true&quot;&gt;&lt;/i&gt; color : Black&lt;br&gt;||||', '', ''),
(51, 2, '1,1,2,', '2,2,1,', '16.19,16.19,15.99,', 'G314143110373538', NULL, 'SEM CMS&lt;br&gt;188# JinQing JiaoJiang , TaiZhou , Zhejiang , China , 310000&lt;br&gt;13812345678&lt;br&gt;SEMCMS CO.,LTD', '$', NULL, '32.38,32.38,15.99,', '90.75', '2021-03-14 09:31:51', '0', '1_6', '0.3', '10.00', '0', '', '127.0.0.1', '0', '2', NULL, NULL, '&lt;i class=&quot;fa fa-genderless&quot; aria-hidden=&quot;true&quot;&gt;&lt;/i&gt; color : Gray&lt;br&gt;||&lt;i class=&quot;fa fa-genderless&quot; aria-hidden=&quot;true&quot;&gt;&lt;/i&gt; color : Pink&lt;br&gt;||||', '', '');

-- --------------------------------------------------------

--
-- 表的结构 `sc_pay`
--

CREATE TABLE `sc_pay` (
  `ID` int(11) NOT NULL,
  `pay_fenlei` char(50) DEFAULT NULL,
  `pay_name` char(100) DEFAULT NULL,
  `ant_img` char(200) DEFAULT NULL,
  `pay_acount` char(110) DEFAULT NULL,
  `contents` varchar(1000) DEFAULT NULL,
  `pay_sxf` char(110) DEFAULT NULL,
  `pay_paixu` int(11) DEFAULT '0',
  `pay_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `pay_flag` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sc_pay`
--

INSERT INTO `sc_pay` (`ID`, `pay_fenlei`, `pay_name`, `ant_img`, `pay_acount`, `contents`, `pay_sxf`, `pay_paixu`, `pay_time`, `pay_flag`) VALUES
(6, '1', 'paypal', '../Images/other/210314050159_798.png,', 'cms@qq.com', 'After clicking “Check Out”, you will be redirected to PayPal to complete your purchase securely.', '0.02+0.01*P', 2, '2017-06-19 08:38:52', 1),
(7, '2', 'Western Union', '../Images/other/210314050211_1271.png,', '', 'Western Union', '', 18, '2017-06-19 09:06:17', 1);

-- --------------------------------------------------------

--
-- 表的结构 `sc_products`
--

CREATE TABLE `sc_products` (
  `ID` int(11) NOT NULL,
  `products_name` char(200) DEFAULT NULL COMMENT '商品名称',
  `products_category` varchar(50) DEFAULT NULL COMMENT '分类ID',
  `products_meta` char(100) DEFAULT NULL COMMENT 'Title meta标签',
  `products_key` char(200) DEFAULT NULL COMMENT '商品meta关键词',
  `products_des` char(220) DEFAULT NULL COMMENT '商品meta描述',
  `products_guige` text COMMENT '概括描述',
  `products_model` char(50) DEFAULT NULL COMMENT '商品型号',
  `products_sku` char(50) DEFAULT NULL COMMENT 'sku',
  `ant_img` varchar(2000) DEFAULT NULL COMMENT '商品图片',
  `contents` longtext COMMENT '商品详细内容',
  `products_sprice` float DEFAULT '0' COMMENT '商城价格',
  `products_oprice` float DEFAULT '0' COMMENT '市场价格',
  `products_url` char(100) DEFAULT NULL COMMENT '商品seo链接',
  `products_aurl` char(100) DEFAULT NULL,
  `products_index` int(11) DEFAULT '0' COMMENT '首页推荐',
  `products_new` int(11) DEFAULT '0' COMMENT '最新产品',
  `products_hot` int(11) DEFAULT '0' COMMENT '人气商品',
  `products_tejia` int(11) DEFAULT '0' COMMENT '特价商品',
  `products_sx` char(100) DEFAULT NULL COMMENT '商品属性ID',
  `products_suxin` varchar(1000) DEFAULT NULL COMMENT '商品属性',
  `products_zk` char(20) DEFAULT NULL COMMENT '折扣ID',
  `products_parner` char(50) DEFAULT NULL COMMENT '供应商',
  `products_l` char(10) DEFAULT NULL COMMENT '长',
  `products_w` char(10) DEFAULT NULL COMMENT '宽',
  `products_h` char(10) DEFAULT NULL COMMENT '高',
  `products_zeke` varchar(1000) DEFAULT NULL COMMENT '商品批发价格段',
  `products_similar` char(100) DEFAULT NULL COMMENT '相关产品',
  `products_zt` int(11) DEFAULT '1' COMMENT '商品上下架',
  `products_kucun` int(11) DEFAULT '1000' COMMENT '商品库存',
  `products_weight` char(50) DEFAULT '10' COMMENT '商品重量',
  `products_dw` char(20) DEFAULT NULL COMMENT '重量单位',
  `products_m` char(10) DEFAULT '1' COMMENT '是小起订量',
  `products_b` char(10) DEFAULT '0' COMMENT '最大起订量',
  `products_paixu` int(11) DEFAULT '10000' COMMENT '商品排序',
  `products_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `languageID` int(11) DEFAULT NULL,
  `products_zdyone` char(10) DEFAULT '1',
  `products_zdytwo` char(10) DEFAULT NULL,
  `products_zdythree` char(10) DEFAULT NULL,
  `products_start` int(11) DEFAULT '0',
  `Itemnb` char(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sc_products`
--

INSERT INTO `sc_products` (`ID`, `products_name`, `products_category`, `products_meta`, `products_key`, `products_des`, `products_guige`, `products_model`, `products_sku`, `ant_img`, `contents`, `products_sprice`, `products_oprice`, `products_url`, `products_aurl`, `products_index`, `products_new`, `products_hot`, `products_tejia`, `products_sx`, `products_suxin`, `products_zk`, `products_parner`, `products_l`, `products_w`, `products_h`, `products_zeke`, `products_similar`, `products_zt`, `products_kucun`, `products_weight`, `products_dw`, `products_m`, `products_b`, `products_paixu`, `products_time`, `languageID`, `products_zdyone`, `products_zdytwo`, `products_zdythree`, `products_start`, `Itemnb`) VALUES
(1, '1.69 Inch Full Touch Fitness Tracker IP67 Waterproof Bluetooth Call Smart watch', ',1,2,3,4,', '1.69 Inch Full Touch Fitness Tracker IP67 Waterproof Bluetooth Call Sm', 'Waterproof Bluetooth', '1.69 Inch Full Touch Fitness Tracker IP67 Waterproof Bluetooth Call Sm', 'battery: 200mAh large capacity polymer batteries\r\nMain screen:1.69 IPS, 240 * 280\r\nTouch screen:2.5D HD screen\r\nHeart rate Blood pressure, oxygen .temperature:Support\r\nLooking for a wristband function:Support\r\nBluetooth calling:Support\r\nRemote music:Control phone player, pause, previous song, next song\r\nIncoming call denied:Long-pressed watch to hang up the phone\r\nDial number:Watch dialing is supported\r\nRaise your hand and light up the screen:Support', 'Smart-001', 'Smart-001', '../Images/product/smart-watch-169_7304.jpg,../Images/product/smart-watch-169_2148.jpg,../Images/product/smart-watch-169_5003.jpg,../Images/product/smart-watch-169_9369.jpg,../Images/product/smart-watch-169_6362.jpg,../Images/product/smart-watch-169_6594.jpg,../Images/product/smart-watch-169_7422.jpg,', '&lt;img src=&quot;/Images/attached/image/20210308/20210308160038_87305.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160049_40371.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160100_36201.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160109_48058.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160121_77118.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160126_87030.jpg&quot; alt=&quot;&quot; /&gt;&lt;br /&gt;', 17.99, 24.99, 'smart-watch-001', NULL, 1, 1, 1, 1, '8', NULL, '2', 'Smart', '', '', '', '1,1,2-3,0.9,4-5,0.85,6+,0.7', '', 1, 1000, '100', 'g', '1', '0', 1000, '2021-03-08 07:58:37', 1, '1', NULL, NULL, 2, '2021030897429'),
(2, '1.69 Inch Full Touch Fitness Tracker IP67 Waterproof Bluetooth Call Smart watch', ',1,2,3,4,', '', 'Waterproof Bluetooth', '1.69 Inch Full Touch Fitness Tracker IP67 Waterproof Bluetooth Call Sm', 'battery: 200mAh large capacity polymer batteries\r\nMain screen:1.69 IPS, 240 * 280\r\nTouch screen:2.5D HD screen\r\nHeart rate Blood pressure, oxygen .temperature:Support\r\nLooking for a wristband function:Support\r\nBluetooth calling:Support\r\nRemote music:Control phone player, pause, previous song, next song\r\nIncoming call denied:Long-pressed watch to hang up the phone\r\nDial number:Watch dialing is supported\r\nRaise your hand and light up the screen:Support', 'smat-002', 'smat-002', '../Images/product/smart-watch-169_5003.jpg,../Images/product/smart-watch-169_7304.jpg,../Images/product/smart-watch-169_2148.jpg,../Images/product/smart-watch-169_9369.jpg,../Images/product/smart-watch-169_6362.jpg,../Images/product/smart-watch-169_6594.jpg,../Images/product/smart-watch-169_7422.jpg,', '&lt;img src=&quot;/Images/attached/image/20210308/20210308160038_87305.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160049_40371.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160100_36201.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160109_48058.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160121_77118.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160126_87030.jpg&quot; alt=&quot;&quot; /&gt;&lt;br /&gt;', 15.99, 22.99, 'smat-002', NULL, 0, 1, 0, 1, NULL, NULL, '2', 'Smart', '', '', '', '1,1,2-3,0.9,4-5,0.85,6+,0.7', '', 1, 1000, '100', 'g', '1', '0', 1000, '2021-03-08 08:06:15', 1, '1', NULL, NULL, 0, '2021030811940'),
(3, '1.69 Inch Full Touch Fitness Tracker IP67 Waterproof Bluetooth Call Smart watch', ',1,', '', 'Waterproof Bluetooth', '1.69 Inch Full Touch Fitness Tracker IP67 Waterproof Bluetooth Call Sm', 'battery: 200mAh large capacity polymer batteries\r\nMain screen:1.69 IPS, 240 * 280\r\nTouch screen:2.5D HD screen\r\nHeart rate Blood pressure, oxygen .temperature:Support\r\nLooking for a wristband function:Support\r\nBluetooth calling:Support\r\nRemote music:Control phone player, pause, previous song, next song\r\nIncoming call denied:Long-pressed watch to hang up the phone\r\nDial number:Watch dialing is supported\r\nRaise your hand and light up the screen:Support', 'smat-003', 'smat-003', '../Images/product/smart-watch-169_9369.jpg,../Images/product/smart-watch-169_7304.jpg,../Images/product/smart-watch-169_2148.jpg,../Images/product/smart-watch-169_5003.jpg,../Images/product/smart-watch-169_6362.jpg,../Images/product/smart-watch-169_6594.jpg,../Images/product/smart-watch-169_7422.jpg,', '&lt;img src=&quot;/Images/attached/image/20210308/20210308160038_87305.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160049_40371.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160100_36201.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160109_48058.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160121_77118.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160126_87030.jpg&quot; alt=&quot;&quot; /&gt;&lt;br /&gt;', 17.99, 24.99, 'smat-003', NULL, 1, 0, 1, 0, NULL, NULL, '2', 'Smart', '', '', '', '1,1,2-3,0.9,4-5,0.85,6+,0.7', '', 1, 1000, '100', 'g', '1', '0', 1000, '2021-03-08 08:06:16', 1, '1', NULL, NULL, 0, '2021030855941'),
(4, 'Touch Fitness Inch Full  Tracker IP67 Waterproof Bluetooth Call Smart watch', ',1,2,3,4,', '', 'Waterproof Bluetooth', '1.69 Inch Full Touch Fitness Tracker IP67 Waterproof Bluetooth Call Sm', 'battery: 200mAh large capacity polymer batteries\r\nMain screen:1.69 IPS, 240 * 280\r\nTouch screen:2.5D HD screen\r\nHeart rate Blood pressure, oxygen .temperature:Support\r\nLooking for a wristband function:Support\r\nBluetooth calling:Support\r\nRemote music:Control phone player, pause, previous song, next song\r\nIncoming call denied:Long-pressed watch to hang up the phone\r\nDial number:Watch dialing is supported\r\nRaise your hand and light up the screen:Support', 'smat-004', 'smat-004', '../Images/product/smart-watch-169_6362.jpg,../Images/product/smart-watch-169_7304.jpg,../Images/product/smart-watch-169_2148.jpg,../Images/product/smart-watch-169_5003.jpg,../Images/product/smart-watch-169_9369.jpg,../Images/product/smart-watch-169_6594.jpg,../Images/product/smart-watch-169_7422.jpg,', '&lt;img src=&quot;/Images/attached/image/20210308/20210308160038_87305.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160049_40371.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160100_36201.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160109_48058.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160121_77118.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160126_87030.jpg&quot; alt=&quot;&quot; /&gt;&lt;br /&gt;', 17.99, 24.99, '', NULL, 0, 1, 0, 1, NULL, NULL, '2', 'Smart', '', '', '', '1,1,2-3,0.9,4-5,0.85,6+,0.7', '', 1, 1000, '100', 'g', '1', '0', 1000, '2021-03-08 08:06:18', 1, '1', NULL, NULL, 0, '2021030817064'),
(5, '1.69 Inch Full Touch Fitness Tracker IP67 Waterproof Bluetooth Call Smart watch', ',1,2,3,4,', '', 'Waterproof Bluetooth', '1.69 Inch Full Touch Fitness Tracker IP67 Waterproof Bluetooth Call Sm', 'battery: 200mAh large capacity polymer batteries\r\nMain screen:1.69 IPS, 240 * 280\r\nTouch screen:2.5D HD screen\r\nHeart rate Blood pressure, oxygen .temperature:Support\r\nLooking for a wristband function:Support\r\nBluetooth calling:Support\r\nRemote music:Control phone player, pause, previous song, next song\r\nIncoming call denied:Long-pressed watch to hang up the phone\r\nDial number:Watch dialing is supported\r\nRaise your hand and light up the screen:Support', 'smat-005', 'smat-005', '../Images/product/smart-watch-169_6594.jpg,../Images/product/smart-watch-169_7304.jpg,../Images/product/smart-watch-169_2148.jpg,../Images/product/smart-watch-169_5003.jpg,../Images/product/smart-watch-169_9369.jpg,../Images/product/smart-watch-169_6362.jpg,../Images/product/smart-watch-169_7422.jpg,', '&lt;img src=&quot;/Images/attached/image/20210308/20210308160038_87305.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160049_40371.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160100_36201.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160109_48058.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160121_77118.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160126_87030.jpg&quot; alt=&quot;&quot; /&gt;&lt;br /&gt;', 17.99, 24.99, 'smat-005', NULL, 1, 0, 1, 0, NULL, NULL, '2', 'Smart', '', '', '', '1,1,2-3,0.9,4-5,0.85,6+,0.7', '', 1, 1000, '100', 'g', '1', '0', 1000, '2021-03-08 08:06:19', 1, '1', NULL, NULL, 0, '2021030839053'),
(6, '1.69 Inch Full Touch Fitness Tracker IP67 Waterproof Bluetooth Call Smart watch', ',1,', '', 'Waterproof Bluetooth', '1.69 Inch Full Touch Fitness Tracker IP67 Waterproof Bluetooth Call Sm', 'battery: 200mAh large capacity polymer batteries\r\nMain screen:1.69 IPS, 240 * 280\r\nTouch screen:2.5D HD screen\r\nHeart rate Blood pressure, oxygen .temperature:Support\r\nLooking for a wristband function:Support\r\nBluetooth calling:Support\r\nRemote music:Control phone player, pause, previous song, next song\r\nIncoming call denied:Long-pressed watch to hang up the phone\r\nDial number:Watch dialing is supported\r\nRaise your hand and light up the screen:Support', 'smat-006', 'smat-006', '../Images/product/smart-watch-169_7422.jpg,../Images/product/smart-watch-169_7304.jpg,../Images/product/smart-watch-169_2148.jpg,../Images/product/smart-watch-169_5003.jpg,../Images/product/smart-watch-169_9369.jpg,../Images/product/smart-watch-169_6362.jpg,../Images/product/smart-watch-169_6594.jpg,', '&lt;img src=&quot;/Images/attached/image/20210308/20210308160038_87305.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160049_40371.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160100_36201.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160109_48058.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160121_77118.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160126_87030.jpg&quot; alt=&quot;&quot; /&gt;&lt;br /&gt;', 17.99, 24.99, 'smat-006', NULL, 0, 1, 0, 1, NULL, NULL, '2', 'Smart', '', '', '', '1,1,2-3,0.9,4-5,0.85,6+,0.7', '', 1, 1000, '100', 'g', '1', '0', 1000, '2021-03-08 08:06:19', 1, '1', NULL, NULL, 0, '2021030856165'),
(7, 'Inch Full Touch Fitness Tracker IP67 Waterproof Bluetooth Call Smart watch', ',1,', '', 'Waterproof Bluetooth', '1.69 Inch Full Touch Fitness Tracker IP67 Waterproof Bluetooth Call Sm', 'battery: 200mAh large capacity polymer batteries\r\nMain screen:1.69 IPS, 240 * 280\r\nTouch screen:2.5D HD screen\r\nHeart rate Blood pressure, oxygen .temperature:Support\r\nLooking for a wristband function:Support\r\nBluetooth calling:Support\r\nRemote music:Control phone player, pause, previous song, next song\r\nIncoming call denied:Long-pressed watch to hang up the phone\r\nDial number:Watch dialing is supported\r\nRaise your hand and light up the screen:Support', 'smat-007', 'smat-007', '../Images/product/smart-watch-169_2148.jpg,../Images/product/smart-watch-169_7304.jpg,../Images/product/smart-watch-169_5003.jpg,../Images/product/smart-watch-169_9369.jpg,../Images/product/smart-watch-169_6362.jpg,../Images/product/smart-watch-169_6594.jpg,../Images/product/smart-watch-169_7422.jpg,', '&lt;img src=&quot;/Images/attached/image/20210308/20210308160038_87305.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160049_40371.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160100_36201.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160109_48058.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160121_77118.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160126_87030.jpg&quot; alt=&quot;&quot; /&gt;&lt;br /&gt;', 16.99, 23.99, 'smat-007', NULL, 1, 0, 1, 0, NULL, NULL, '2', 'Smart', '', '', '', '1,1,2-3,0.9,4-5,0.85,6+,0.7', '', 1, 1000, '100', 'g', '1', '0', 1000, '2021-03-08 08:06:20', 1, '1', NULL, NULL, 0, '2021030817908'),
(8, 'Touch Fitness Inch Full  Tracker IP67 Waterproof Bluetooth Call Smart watch', ',1,', '', 'Waterproof Bluetooth', '1.69 Inch Full Touch Fitness Tracker IP67 Waterproof Bluetooth Call Sm', 'battery: 200mAh large capacity polymer batteries\r\nMain screen:1.69 IPS, 240 * 280\r\nTouch screen:2.5D HD screen\r\nHeart rate Blood pressure, oxygen .temperature:Support\r\nLooking for a wristband function:Support\r\nBluetooth calling:Support\r\nRemote music:Control phone player, pause, previous song, next song\r\nIncoming call denied:Long-pressed watch to hang up the phone\r\nDial number:Watch dialing is supported\r\nRaise your hand and light up the screen:Support', 'smart-008', 'smart-008', '../Images/product/smart-watch-169_6362.jpg,../Images/product/smart-watch-169_7304.jpg,../Images/product/smart-watch-169_2148.jpg,../Images/product/smart-watch-169_5003.jpg,../Images/product/smart-watch-169_9369.jpg,../Images/product/smart-watch-169_6594.jpg,../Images/product/smart-watch-169_7422.jpg,', '&lt;img src=&quot;/Images/attached/image/20210308/20210308160038_87305.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160049_40371.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160100_36201.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160109_48058.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160121_77118.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/Images/attached/image/20210308/20210308160126_87030.jpg&quot; alt=&quot;&quot; /&gt;&lt;br /&gt;', 17.99, 24.99, 'smart-008', NULL, 0, 0, 0, 0, NULL, NULL, '2', 'Smart', '', '', '', '1,1,2-3,0.9,4-5,0.85,6+,0.7', '', 1, 1000, '100', 'g', '1', '0', 1000, '2021-03-08 08:13:45', 1, '1', NULL, NULL, 0, '2021030837059'),
(9, '1.69 Inch Full Touch Fitness Tracker IP67 Waterproof Bluetooth Call Smart watch', ',1,', '1.69 Inch Full Touch Fitness Tracker IP67 Waterproof Bluetooth Call Sm', 'hello world,hello china', '1.69 Inch Full Touch Fitness Tracker IP67 Waterproof Bluetooth Call Sm', '1.69 Inch Full Touch Fitness Tracker IP67 Waterproof Bluetooth Call Smart watch', 'a-001', 'a-0001', '../Images/product/abc-009_8282.jpg,../Images/product/210310023109_1742.jpg,', '&lt;h1&gt;\r\n	1.69 Inch Full Touch Fitness Tracker IP67 Waterproof Bluetooth Call Smart watch\r\n&lt;/h1&gt;\r\n&lt;br /&gt;', 9.99, 19.99, '169-Inch-Full-Touch-Fitness', NULL, 1, 0, 0, 0, '7,8', NULL, '2', '', '100', '200', '300', '1,1,2-3,0.9,4-5,0.85,6+,0.7', '', 1, 1000, '10', 'g', '1', '0', 1000, '2021-03-10 06:41:31', 1, '1', NULL, NULL, 2, '2021031055508'),
(10, '1.69 Inch Full Touch Fitness Tracker IP67 Waterproof Bluetooth Call Smart watch', ',1,', NULL, 'hello world,hello china', '1.69 Inch Full Touch Fitness Tracker IP67 Waterproof Bluetooth Call Sm', '1.69 Inch Full Touch Fitness Tracker IP67 Waterproof Bluetooth Call Smart watch', NULL, NULL, '../Images/product/abc-009_8282.jpg,../Images/product/210310023109_1742.jpg,', '&lt;h1&gt;\r\n	1.69 Inch Full Touch Fitness Tracker IP67 Waterproof Bluetooth Call Smart watch\r\n&lt;/h1&gt;\r\n&lt;br /&gt;', 9.99, 19.99, NULL, NULL, 0, 0, 0, 0, NULL, NULL, '2', '', '100', '200', '300', '1,1,2-3,0.9,4-5,0.85,6+,0.7', '', 1, 1000, '10', 'g', '1', '0', 1000, '2021-03-10 06:48:53', 1, '1', NULL, NULL, 0, '2021031011659');

-- --------------------------------------------------------

--
-- 表的结构 `sc_property`
--

CREATE TABLE `sc_property` (
  `ID` int(11) NOT NULL,
  `suxin_id` int(11) DEFAULT '0',
  `pt_name` char(100) DEFAULT '',
  `pt_value` char(20) DEFAULT NULL,
  `ant_img` char(200) DEFAULT NULL,
  `pt_flag` int(11) DEFAULT '0',
  `pt_paixu` int(11) DEFAULT '1000',
  `pt_xs` int(11) DEFAULT '1',
  `itemnb` char(20) DEFAULT NULL,
  `pt_price` char(20) DEFAULT NULL,
  `pt_kc` char(20) DEFAULT NULL,
  `pt_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sc_property`
--

INSERT INTO `sc_property` (`ID`, `suxin_id`, `pt_name`, `pt_value`, `ant_img`, `pt_flag`, `pt_paixu`, `pt_xs`, `itemnb`, `pt_price`, `pt_kc`, `pt_time`) VALUES
(1, 8, 'Black', NULL, '../Images/product/210308040418_9385.jpg', 0, 1000, 1, '2021030897429', '', '', '2021-03-08 08:05:16'),
(2, 8, 'Gray', NULL, '../Images/product/210308040425_2723.jpg', 0, 1000, 1, '2021030897429', '', '', '2021-03-08 08:05:16'),
(3, 8, 'Cyan', NULL, '../Images/product/210308040441_6720.jpg', 0, 1000, 1, '2021030897429', '', '', '2021-03-08 08:05:16'),
(4, 8, 'Pink', NULL, '../Images/product/210308040459_1204.jpg', 0, 1000, 1, '2021030897429', '', '', '2021-03-08 08:05:16'),
(6, 8, 'Gold', NULL, '../Images/product/210308040538_8020.jpg', 0, 1000, 1, '2021030897429', '', '', '2021-03-08 08:05:39'),
(7, 7, 'x', NULL, NULL, 0, 1000, 1, '2021031055508', '19.99', '1000', '2021-03-10 06:36:27'),
(8, 7, 'L', NULL, NULL, 0, 1000, 1, '2021031055508', '19.99', '1000', '2021-03-10 06:36:27'),
(9, 7, 'xL', NULL, NULL, 0, 1000, 1, '2021031055508', '19.99', '1000', '2021-03-10 06:36:27'),
(10, 8, 'red', NULL, '../Images/product/210310023710_2378.jpg', 0, 1000, 1, '2021031055508', '19.99', '1000', '2021-03-10 06:37:12');

-- --------------------------------------------------------

--
-- 表的结构 `sc_suxin`
--

CREATE TABLE `sc_suxin` (
  `ID` int(11) NOT NULL,
  `sx_name` char(100) DEFAULT NULL,
  `sx_paixu` int(11) DEFAULT '1000',
  `sx_flag` int(11) DEFAULT '0',
  `sx_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sc_suxin`
--

INSERT INTO `sc_suxin` (`ID`, `sx_name`, `sx_paixu`, `sx_flag`, `sx_time`) VALUES
(7, 'size', 1, 1, '2021-01-03 08:05:52'),
(8, 'color', 1000, 1, '2020-12-09 08:29:58');

-- --------------------------------------------------------

--
-- 表的结构 `sc_tagandseo`
--

CREATE TABLE `sc_tagandseo` (
  `ID` int(11) NOT NULL,
  `tag_h_title` char(200) DEFAULT NULL COMMENT '首页标题',
  `tag_h_key` char(200) DEFAULT NULL,
  `tag_h_des` varchar(300) DEFAULT NULL,
  `tag_p_title` char(200) DEFAULT NULL,
  `tag_p_key` char(200) DEFAULT NULL,
  `tag_p_des` varchar(300) DEFAULT NULL,
  `tag_n_title` char(200) DEFAULT NULL,
  `tag_n_key` char(200) DEFAULT NULL,
  `tag_n_des` varchar(300) DEFAULT NULL,
  `tag_t_adv` varchar(500) DEFAULT NULL COMMENT '页面头部宣传语',
  `tag_h_about` longtext,
  `contents` longtext,
  `tag_service` varchar(1000) DEFAULT NULL,
  `tag_whosale` varchar(1000) DEFAULT NULL,
  `languageID` int(11) DEFAULT NULL,
  `tag_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sc_tagandseo`
--

INSERT INTO `sc_tagandseo` (`ID`, `tag_h_title`, `tag_h_key`, `tag_h_des`, `tag_p_title`, `tag_p_key`, `tag_p_des`, `tag_n_title`, `tag_n_key`, `tag_n_des`, `tag_t_adv`, `tag_h_about`, `contents`, `tag_service`, `tag_whosale`, `languageID`, `tag_time`) VALUES
(1, 'SEMCMS,SCSHOP website', 'SEMCMS,SCSHOP website', 'SEMCMS,SCSHOP website', 'SEMCMS,SCSHOP website', 'SEMCMS,SCSHOP website', 'SEMCMS,SCSHOP website', 'SEMCMS,SCSHOP website', 'SEMCMS,SCSHOP website', 'SEMCMS,SCSHOP website', 'Welcome to our website !', 'Mobile Phone Case,Leather case', '&lt;span style=&quot;margin:0px;padding:0px;color:#666666;font-family:muli-regular, sans-serif;white-space:normal;background-color:#FFFFFF;font-size:14px;&quot;&gt;&lt;span style=&quot;color:#333333;font-family:&amp;quot;font-size:14.4px;white-space:normal;background-color:#FFFFFF;&quot;&gt;Semcms is very suitable for foreign trade enterprises and E-commerce Internet applications. Since its first release in December 2009, semcms has continuously expanded its share of foreign trade market by relying on excellent user experience and leading technology.&amp;nbsp;&lt;br /&gt;\r\n&lt;br /&gt;\r\nCompany: Semcms Co., Ltd.&lt;br /&gt;\r\nAdd: No. 789-5D, Jimei North Avenue, Jimei District, Taizhou, China&lt;br /&gt;\r\nContact: Sophie Chong&lt;br /&gt;\r\nTel./Mobile: +86 159 888 0000&lt;br /&gt;\r\nWhatsapp: +86 159 888 0000&lt;br /&gt;\r\n&lt;br /&gt;\r\nContact : Jamie phone&lt;br /&gt;\r\nTel./Mobile: +86 159 888 0000&lt;br /&gt;\r\nWhatsapp: +86 159 888 0000&lt;br /&gt;\r\nEmail: info@sem-cms.com&lt;br /&gt;\r\n&lt;/span&gt;&lt;/span&gt;&lt;span style=&quot;margin:0px;padding:0px;color:#666666;font-family:muli-regular, sans-serif;white-space:normal;background-color:#FFFFFF;font-size:14px;&quot;&gt;&lt;/span&gt;', '&lt;li&gt;\r\n	&lt;i class=&quot;fa fa-get-pocket&quot; aria-hidden=&quot;true&quot;&gt;&lt;/i&gt; Secure Payment Provided\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n	&lt;i class=&quot;fa fa-space-shuttle&quot; aria-hidden=&quot;true&quot;&gt;&lt;/i&gt; Fast Delivery &amp;amp; Free Shipping Available\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n	&lt;i class=&quot;fa fa-refresh&quot; aria-hidden=&quot;true&quot;&gt;&lt;/i&gt; 30-Day MoneyBack Guarantee\r\n&lt;/li&gt;', NULL, 1, '2020-12-22 07:31:05');

-- --------------------------------------------------------

--
-- 表的结构 `sc_user`
--

CREATE TABLE `sc_user` (
  `ID` int(11) NOT NULL,
  `user_name` varchar(50) DEFAULT NULL,
  `user_admin` varchar(50) NOT NULL,
  `user_ps` varchar(50) NOT NULL,
  `user_tel` varchar(50) DEFAULT NULL,
  `user_qx` varchar(500) DEFAULT NULL,
  `user_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `user_email` varchar(100) DEFAULT NULL,
  `user_rzm` varchar(50) DEFAULT NULL,
  `user_open` int(11) DEFAULT '1',
  `ant_img` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sc_user`
--

INSERT INTO `sc_user` (`ID`, `user_name`, `user_admin`, `user_ps`, `user_tel`, `user_qx`, `user_time`, `user_email`, `user_rzm`, `user_open`, `ant_img`) VALUES
(6, 'SEMCMS', 'Admin', 'ccff8c23218835d1e6cd26d26321eb03', '13812345678', ',25,1,18,19,20,21,22,23,24,27,28,26,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,29,', '2021-03-14 09:45:21', 'info@sem-cms.com', NULL, 1, '../Images/banner/210310092017_4936.png,');

-- --------------------------------------------------------

--
-- 表的结构 `sc_words`
--

CREATE TABLE `sc_words` (
  `ID` int(11) NOT NULL,
  `wd_key` char(100) DEFAULT NULL,
  `wd_mail` char(100) DEFAULT NULL,
  `wd_ip` char(100) DEFAULT NULL,
  `wd_time` timestamp NULL DEFAULT NULL,
  `wd_flag` int(11) DEFAULT '0',
  `languageID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `sc_address`
--
ALTER TABLE `sc_address`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `userID` (`userID`);

--
-- Indexes for table `sc_banner`
--
ALTER TABLE `sc_banner`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `sc_blogcat`
--
ALTER TABLE `sc_blogcat`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `b_name` (`b_name`),
  ADD KEY `ID` (`ID`),
  ADD KEY `b_url` (`b_url`),
  ADD KEY `ant_img` (`ant_img`),
  ADD KEY `languageID` (`languageID`),
  ADD KEY `b_paixu` (`b_paixu`);

--
-- Indexes for table `sc_categories`
--
ALTER TABLE `sc_categories`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `languageID` (`languageID`),
  ADD KEY `category_paixu` (`category_paixu`),
  ADD KEY `category_open` (`category_open`),
  ADD KEY `category_path` (`category_path`),
  ADD KEY `category_url` (`category_url`),
  ADD KEY `ID` (`ID`),
  ADD KEY `category_name` (`category_name`);

--
-- Indexes for table `sc_config`
--
ALTER TABLE `sc_config`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `sc_country`
--
ALTER TABLE `sc_country`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `name` (`country_name`),
  ADD KEY `country_code_2` (`country_code_2`,`country_paixu`),
  ADD KEY `country_code_3` (`country_code_3`),
  ADD KEY `zhcart_country_code_2` (`country_code_2`,`country_paixu`),
  ADD KEY `zhcart_country_code_3` (`country_code_3`);

--
-- Indexes for table `sc_coupon`
--
ALTER TABLE `sc_coupon`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `cou_code` (`cou_code`);

--
-- Indexes for table `sc_currency`
--
ALTER TABLE `sc_currency`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `sc_delivery`
--
ALTER TABLE `sc_delivery`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `sc_discount`
--
ALTER TABLE `sc_discount`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `di_paixu` (`di_paixu`);

--
-- Indexes for table `sc_download`
--
ALTER TABLE `sc_download`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `sc_email`
--
ALTER TABLE `sc_email`
  ADD UNIQUE KEY `ID` (`ID`);

--
-- Indexes for table `sc_express`
--
ALTER TABLE `sc_express`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `sc_freeship`
--
ALTER TABLE `sc_freeship`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `sc_images`
--
ALTER TABLE `sc_images`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `sc_info`
--
ALTER TABLE `sc_info`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `info_title` (`info_title`(255)),
  ADD KEY `ID` (`ID`),
  ADD KEY `languageID` (`languageID`),
  ADD KEY `info_url` (`info_url`),
  ADD KEY `info_flag` (`info_flag`),
  ADD KEY `info_cat` (`info_cat`),
  ADD KEY `info_paixu` (`info_paixu`);

--
-- Indexes for table `sc_lable`
--
ALTER TABLE `sc_lable`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `languageID` (`languageID`);

--
-- Indexes for table `sc_language`
--
ALTER TABLE `sc_language`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `language_url` (`language_url`),
  ADD KEY `ID` (`ID`),
  ADD KEY `language_paixu` (`language_paixu`);

--
-- Indexes for table `sc_link`
--
ALTER TABLE `sc_link`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `sc_mailtemplate`
--
ALTER TABLE `sc_mailtemplate`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `sc_member`
--
ALTER TABLE `sc_member`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `me_email` (`me_email`);

--
-- Indexes for table `sc_menu`
--
ALTER TABLE `sc_menu`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `sc_msg`
--
ALTER TABLE `sc_msg`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `sc_mulu`
--
ALTER TABLE `sc_mulu`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `sc_order`
--
ALTER TABLE `sc_order`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `sc_pay`
--
ALTER TABLE `sc_pay`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `sc_products`
--
ALTER TABLE `sc_products`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `products_category` (`products_category`),
  ADD KEY `languageID` (`languageID`),
  ADD KEY `products_name` (`products_name`),
  ADD KEY `products_priceh` (`products_sprice`),
  ADD KEY `products_url` (`products_url`),
  ADD KEY `products_index` (`products_index`),
  ADD KEY `products_new` (`products_new`),
  ADD KEY `products_hot` (`products_hot`),
  ADD KEY `products_tejia` (`products_tejia`),
  ADD KEY `products_zt` (`products_zt`),
  ADD KEY `products_paixu` (`products_paixu`),
  ADD KEY `Itemnb` (`Itemnb`);

--
-- Indexes for table `sc_property`
--
ALTER TABLE `sc_property`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `itemnb` (`itemnb`),
  ADD KEY `suxin_id` (`suxin_id`),
  ADD KEY `pt_paixu` (`pt_paixu`);

--
-- Indexes for table `sc_suxin`
--
ALTER TABLE `sc_suxin`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `sx_paixu` (`sx_paixu`);

--
-- Indexes for table `sc_tagandseo`
--
ALTER TABLE `sc_tagandseo`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `languageID` (`languageID`);

--
-- Indexes for table `sc_user`
--
ALTER TABLE `sc_user`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `sc_words`
--
ALTER TABLE `sc_words`
  ADD PRIMARY KEY (`ID`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `sc_address`
--
ALTER TABLE `sc_address`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- 使用表AUTO_INCREMENT `sc_banner`
--
ALTER TABLE `sc_banner`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- 使用表AUTO_INCREMENT `sc_blogcat`
--
ALTER TABLE `sc_blogcat`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- 使用表AUTO_INCREMENT `sc_categories`
--
ALTER TABLE `sc_categories`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- 使用表AUTO_INCREMENT `sc_config`
--
ALTER TABLE `sc_config`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- 使用表AUTO_INCREMENT `sc_country`
--
ALTER TABLE `sc_country`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增ID', AUTO_INCREMENT=243;
--
-- 使用表AUTO_INCREMENT `sc_coupon`
--
ALTER TABLE `sc_coupon`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- 使用表AUTO_INCREMENT `sc_currency`
--
ALTER TABLE `sc_currency`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- 使用表AUTO_INCREMENT `sc_delivery`
--
ALTER TABLE `sc_delivery`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- 使用表AUTO_INCREMENT `sc_discount`
--
ALTER TABLE `sc_discount`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- 使用表AUTO_INCREMENT `sc_download`
--
ALTER TABLE `sc_download`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- 使用表AUTO_INCREMENT `sc_email`
--
ALTER TABLE `sc_email`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- 使用表AUTO_INCREMENT `sc_express`
--
ALTER TABLE `sc_express`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- 使用表AUTO_INCREMENT `sc_freeship`
--
ALTER TABLE `sc_freeship`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- 使用表AUTO_INCREMENT `sc_images`
--
ALTER TABLE `sc_images`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- 使用表AUTO_INCREMENT `sc_info`
--
ALTER TABLE `sc_info`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- 使用表AUTO_INCREMENT `sc_lable`
--
ALTER TABLE `sc_lable`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- 使用表AUTO_INCREMENT `sc_language`
--
ALTER TABLE `sc_language`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- 使用表AUTO_INCREMENT `sc_link`
--
ALTER TABLE `sc_link`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- 使用表AUTO_INCREMENT `sc_mailtemplate`
--
ALTER TABLE `sc_mailtemplate`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- 使用表AUTO_INCREMENT `sc_member`
--
ALTER TABLE `sc_member`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- 使用表AUTO_INCREMENT `sc_menu`
--
ALTER TABLE `sc_menu`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- 使用表AUTO_INCREMENT `sc_msg`
--
ALTER TABLE `sc_msg`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- 使用表AUTO_INCREMENT `sc_mulu`
--
ALTER TABLE `sc_mulu`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- 使用表AUTO_INCREMENT `sc_order`
--
ALTER TABLE `sc_order`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
--
-- 使用表AUTO_INCREMENT `sc_pay`
--
ALTER TABLE `sc_pay`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- 使用表AUTO_INCREMENT `sc_products`
--
ALTER TABLE `sc_products`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- 使用表AUTO_INCREMENT `sc_property`
--
ALTER TABLE `sc_property`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- 使用表AUTO_INCREMENT `sc_suxin`
--
ALTER TABLE `sc_suxin`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- 使用表AUTO_INCREMENT `sc_tagandseo`
--
ALTER TABLE `sc_tagandseo`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- 使用表AUTO_INCREMENT `sc_user`
--
ALTER TABLE `sc_user`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- 使用表AUTO_INCREMENT `sc_words`
--
ALTER TABLE `sc_words`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
