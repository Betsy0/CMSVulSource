<!DOCTYPE html>
<html>
<head>
	<title>©SEMCMS外贸商城管理系统 - 安装</title>
<meta charset="utf-8">
<script src="../Core/Js/jquery-3.5.1.min.js"></script>
<link rel="stylesheet" type="text/css" href="../Core/Css/font-awesome-47/css/font-awesome.min.css">
<style>
/* latin */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 400;
  src: local('Open Sans Regular'), local('OpenSans-Regular'), url(../Core/font/Open_Sans/mem8YaGs126MiZpBA-UFVZ0b.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
html,body{overflow-x: hidden;}
input,textarea,select{ font-size: 14px; font-weight: bold;  }
select{ height: 40px; padding: 2px 10px; }
body,input,textarea{ font-size:14px; font-family: 'Open Sans', sans-serif; background: #f4f7fa; color: #393836; }
.cb{clear: both;}

ul,li,dd,ol{ list-style: none; }
*{padding: 0px; margin:0px;}	
.intent{background: #33b35a; width: 100%;float: left; height: 100%;}
.incentet{ width: 100%; margin:auto; box-sizing: border-box;}
.intop{width: 100%; float:left; padding: 50px 0; text-align: center;  border-bottom: 1px solid #40e272;}
.intop img{cursor: pointer; width: 100px; border-radius: 200px; border: 2px solid #efefef; padding: 10px; background-color: #fff; }
.intop img:hover{transform: scale(1.2);transition: .5s transform;}
.intop h2{color: #fff; margin-top:30px;}
.inmid{border-top: 1px solid #238541; width: 100%;float: left; }
.inmid_center{width: 60%; margin:20px auto; }
.inmid_left{width: 20%;float: left;}
.inmid_left li{width: 100%;float: left; border-radius: 3px; padding:8px 0;background: #238541; margin-bottom: 5px; text-align: center; color: #fff; cursor:pointer;}
.inmid_left li:hover{background:#40e272; }
.inmid_right{width: 78%;float: right; }
.inmid_right_1{ width: 100%;float: left;background: #fff;padding: 1%;box-sizing: border-box; line-height: 200%;  border-radius: 2px; display: none; }
.inmid_right_1 strong{margin:15px 0; display: block;}
.nextstep{width: 100%;float: left; text-align: center; margin-top:20px;border-top:1px solid #efefef; padding: 20px 0;}
.nextstep span{  padding: 10px 30px;   background: #238541; color: #fff;border-radius: 3px; cursor: pointer; margin-left: 20px; }
.nextstep span:hover{background:#40e272; }
.nextstep a{color: #fff;}
.Tab{width: 100%;float: left; max-height: 450px; overflow-y: scroll;}

.table{ width: 100%;  border-bottom:1px solid #efefef; border-right:1px solid #efefef; background: #fff;}
.table td{  padding: 10px 5px;  border-top:1px solid #efefef;border-left:1px solid #efefef;}
.table input{ padding: 5px ;background: #fff; border:1px solid #efefef; }
#datatest{padding: 5px 10px; border:1px solid #efefef; cursor: pointer;}
.bot{width: 100%;float: left; padding: 15px; text-align: center;color: #fff; margin-top:30px;border-top:1px solid #40e272;}
#aznext{display: none;}
.tbopt{width: 100px;}
</style>
<script type="text/javascript">
	function ischange(id){
		for (var i = 1; i < 6; i++) {
			$("#tab_"+i).fadeOut(0);
			$("#lab_"+i).css("background-color","#238541"); 
		}
		 $("#tab_"+id).fadeIn(0);
		 $("#lab_"+id).css("background-color","#40e272"); 

         $(document).ready(function(){
            	if (id==4){
              
 setTimeout(function(){                
			         $.ajax({
	                    type: "POST",
	                    url: "act.php?type=install",
	                    data:$("#install").serialize(),
	                    async: false,
	                    success: function(data){
	                     $('#installdata').fadeIn();
	                     $("#installdata").html(data);
	                     if(data.indexOf('失败')>0){
	                     	$("#aznext").fadeOut();
	                     }else{
	                     	$("#aznext").fadeIn();
	                     }
	                    },
	                    error:function (err){ //失败回调函数
	                     $("#installdata").html(err); 
		                 $('#installdata').fadeOut(5000);	                 
	                    }
	                  });

			     },1000); 
 
	                  return false; 
	              }
	        if (id==5){
			     htmlobj=$.ajax({url:"act.php?type=installcom",async:false}); 
			     $("#comshow").html(htmlobj.responseText);
	        }      

	     });


	}

$(document).ready(function(){
	  $("#datatest").click(function(){
	  		   url=$(this).attr('url');
	           $.ajax({
	                    type: "POST",
	                    url: url,
	                    data:$("#install").serialize(),
	                    async: false,
	                    success: function(data){
	                     $('#testshow').fadeIn();
	                     $("#testshow").html(data); 
	                     $('#testshow').fadeOut(5000);
	                    },
	                    error:function (err){ //失败回调函数
	                     $("#testshow").html(err); 
		                 $('#testshow').fadeOut(5000);
	                    }
	                  });
	                return false; 
	  });



})

</script>	
</head>

<body class="intent">
		<div class="incentet">
			<div class="intop"><img src="Images/logo.png" alt="SEMCMS外贸商城管理系统"><br><h2>欢迎使用SEMCMS外贸网站 &middot; 商城管理系统</h2></div>
			<div class="cb"></div>
			<div class="inmid">
  				<div class="inmid_center">
  					<div class="inmid_left">
  						<ul>
  							<li style="background:#40e272; " id="lab_1">查看条款</li>
  							<li id="lab_2">检查环境</li>
  							<li id="lab_3">设置参数</li>
  							<li id="lab_4">安装数据</li>
  							<li id="lab_5">安装成功</li>
  					    </ul>
  				    </div>
  					<div class="inmid_right">
  				 
  						<div class="inmid_right_1" id="tab_1"  style="display: block;" >

						 <div class="Tab" >  							
  							<?php 
							$file_path = "license.txt";
							if(file_exists($file_path)){
							$str = file_get_contents($file_path);//将整个文件内容读入到一个字符串中
							//$str = str_replace("\r\n","<br />",$str);
							echo $str;
							}
  							?>
  						</div>
  						<div class="cb"></div>
  						<div class="nextstep" ><span onclick="ischange('2');">下一步 <i class="fa fa-share" aria-hidden="true"></i></span><a href="https://www.sem-cms.cn/wenda/wd-8/" target="_blank"> <span>查看视频教程 <i class="fa fa-share" aria-hidden="true"></i></span></a></div>
  						<div class="cb"></div>
  						   <div class="nextstep" > <a href="https://www.sem-cms.cn/wenda/view-53.html" target="_blank"> <span>如果在线安装不成功->请查看手动安装方法 <i class="fa fa-share" aria-hidden="true"></i></span></a></div>
  					</div>
  					<div class="cb"></div>
  					<div class="inmid_right_1" id="tab_2">
  						<div class="Tab">

  							 <?php
$sysos = $_SERVER["SERVER_SOFTWARE"];      //获取服务器标识的字串
$sysversion = PHP_VERSION;                   //获取PHP服务器版本
//以下两条代码连接MySQL数据库并获取MySQL数据库版本信息
//$mysqlinfo = mysqli_get_server_info($db_conn);
//从服务器中获取GD库的信息
if(function_exists("gd_info")){                 
	$gd = gd_info();
	$gdinfo = $gd['GD Version'];
}else {
    $gdinfo = "未知";
}
//从GD库中查看是否支持FreeType字体
$freetype = $gd["FreeType Support"] ? "支持" : "不支持";
//从PHP配置文件中获得是否可以远程文件获取
$allowurl= ini_get("allow_url_fopen") ? "支持" : "不支持";
//从PHP配置文件中获得最大上传限制
$max_upload = ini_get("file_uploads") ? ini_get("upload_max_filesize") : "Disabled";
//从PHP配置文件中获得脚本的最大执行时间
$max_ex_time= ini_get("max_execution_time")."秒";
//以下两条获取服务器时间，中国大陆采用的是东八区的时间,设置时区写成Etc/GMT-8
//date_default_timezone_set("Etc/GMT-8");
//$systemtime = date("Y-m-d H:i:s",time());
$ip=$_SERVER['REMOTE_ADDR'];
$xymc=$_SERVER['SERVER_PROTOCOL'];
$webport=$_SERVER['SERVER_PORT'];
$domain=$_SERVER['SERVER_NAME'];
$weblang=$_SERVER['HTTP_ACCEPT_LANGUAGE'];
$webyq=$_SERVER['SERVER_SOFTWARE'];
 
?>
<ul>
	<li><font color="red">系统要求 : Apache 2.2.1 + PHP版本:5.6 + Mysql版本:5.6 + 否则安装不成功！！！</font></li>
	<li>Web服务器 : <?php
$webfw=strtolower($sysos); 
if(strpos($webfw,'apache') !== false){ 
 echo 'Apache';
}else{
echo '<i class="fa fa-times" aria-hidden="true"></i>不支持,影响程序运行'; 
}
?></li>
	<li>PHP版本 : <?php echo $sysversion; ?></li>
	<li>GD库版本 : <?php echo $gdinfo; ?></li>
	<li>FreeType : <?php echo $freetype; ?></li>
	<li>远程文件获取 : <?php echo $allowurl; ?></li>
	<li>最大上传限制 : <?php echo $max_upload; ?></li>
	<li>最大执行时间 : <?php echo $max_ex_time; ?></li>
	<li>客户端IP : <?php echo $ip; ?></li>
	<li>../index.php <?php if(!is_writable("../index.php")){echo '<font color=red>没有权限 <i class="fa fa-times" aria-hidden="true"></i></font>';}else{echo '可写 <i class="fa fa-check" aria-hidden="true"></i>';}?></li>
		<li>../A_Admin <?php if(!is_writable("../A_Admin")){echo '<font color=red>没有权限 -> (后台路径需手动修改) <i class="fa fa-times" aria-hidden="true"></i></font> ';}else{echo '可写 <i class="fa fa-check" aria-hidden="true"></i>';}?></li>
		<li>../Core <?php if(!is_writable("../Core")){echo '<font color=red>没有权限 -> (数据库配置会失败) <i class="fa fa-times" aria-hidden="true"></i></font> ';}else{echo '可写 <i class="fa fa-check" aria-hidden="true"></i>';}?></li>	
		<li>../Images <?php if(!is_writable("../Images")){echo '<font color=red>没有权限 -> (图片会法保存) <i class="fa fa-times" aria-hidden="true"></i></font> ';}else{echo '可写 <i class="fa fa-check" aria-hidden="true"></i>';}?></li>	
		<li>../Template <?php if(!is_writable("../Template")){echo '<font color=red>没有权限 -> (模版会无法应用) <i class="fa fa-times" aria-hidden="true"></i></font> ';}else{echo '可写 <i class="fa fa-check" aria-hidden="true"></i>';}?></li>	
		<li>../install <?php if(!is_writable("../install")){echo '<font color=red>没有权限 -> (需求手动删除) <i class="fa fa-times" aria-hidden="true"></i></font> ';}else{echo '可写 <i class="fa fa-check" aria-hidden="true"></i>';}?></li>			
</ul>
  						</div>
  						<div class="cb"></div>
  						<div class="nextstep" ><span onclick="ischange('1');"><i class="fa fa-reply" aria-hidden="true"></i> 上一步</span> <span onclick="ischange('3');">下一步 <i class="fa fa-share" aria-hidden="true"></i></span></div>	
  					</div>
  			 
  					<div class="cb"></div>
  					<div class="inmid_right_1" id="tab_3">
  						<div class="Tab">
	  					    <form name="form" method="post" id="install">
							    <table class="table" cellspacing="1" cellpadding="0">
									<tr>
										<th class="tbopt"> 服务器地址:</th>
									     <td><input type="text" name="dbhost" value="localhost" size="35">  一般默认</td>
									</tr>
									<tr>
										<th class="tbopt"> 数据库名称:</th>	
									   <td><input type="text" name="dbname" value="semcms" size="35">  <input type="checkbox" name="mk_newdb" value="1" />新建数据库名,默认不勾选</td>
									</tr>
									<tr>
										<th class="tbopt"> 数据库账号:</th>
									    <td><input type="text" name="dbuser" value="root" size="35"></td>
									</tr>
									<tr>
										<th class="tbopt"> 数据库密码:</th>
									    <td><input type="text" name="dbpw" value="root" size="35"></td>
									</tr>
									<tr>
										<th class="tbopt"></th>
									    <td><span id="datatest" url="act.php?type=cs">测试数据库链接</span> <font color="red" id="testshow"></font> </td>
									</tr>
									<tr>
										<th class="tbopt"> 说明:</th>
									    <td>本系统需支持 php5.6 + mysql 5.6 + Apache 否则会影响功能使用！</td>
									</tr>
								</table>
		                      </form>
  						</div>
  						<div class="cb"></div>
  						<div class="nextstep" ><span onclick="ischange('2');"><i class="fa fa-reply" aria-hidden="true"></i> 上一步</span><span onclick="ischange('4');">下一步 <i class="fa fa-share" aria-hidden="true"></i></span></div>	
  					</div>
   					<div class="cb"></div>
  					<div class="inmid_right_1" id="tab_4">
  						<div class="Tab" id="installdata">
  							<i class="fa fa-spinner fa-spin fa-fw"></i> 安装数据库中,请稍后...
  						</div>
  						<div class="cb"></div>
  						<div class="nextstep" ><span onclick="ischange('3');"><i class="fa fa-reply" aria-hidden="true"></i> 上一步</span><span onclick="ischange('5');" id="aznext">下一步 <i class="fa fa-share" aria-hidden="true"></i></span></div>	
  					</div>
   					<div class="cb"></div>
  					<div class="inmid_right_1" id="tab_5">
  						<div class="Tab" id="comshow">
  							成功显示......
  						</div>
  						<div class="cb"></div>
  						 
  					</div>

  					</div>
  				</div>
			</div>
		</div>
		<div class="bot"> SEMCMS外贸商城管理系统 © <?php echo date("Y"); ?><script type="text/javascript">document.write(unescape("%3Cspan id='cnzz_stat_icon_1279754351'%3E%3C/span%3E%3Cscript src='https://v1.cnzz.com/z_stat.php%3Fid%3D1279754351%26show%3Dpic1' type='text/javascript'%3E%3C/script%3E"));</script></div>

</body>
</html>