<?php
// CopyRight © semcms (QQ:1181698019【黑蚂蚁.阿梁】)
// website:https://www.sem-cms.cn/

function Search_Data($em,$key,$db_conn,$lgid){
    $Ant=new WD_Data_Process();
    $wd_time = date("Y-m-d H:i:s");
    $wd_ip = GetIp();	
	$table = 'sc_words';
	$field = "wd_key,wd_mail,wd_ip,wd_time,languageID";
	$val = "('".$key."','".$em."','".$wd_ip."','".$wd_time."','".$lgid."')";
	$Ant->AntAdd($table,$field,$val,$db_conn);
}
