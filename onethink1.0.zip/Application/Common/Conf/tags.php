<?php
return array(
	'app_init'=>array('Common\Behavior\InitHook')
);