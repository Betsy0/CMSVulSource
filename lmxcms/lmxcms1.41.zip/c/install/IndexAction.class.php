<?php 
//lmxcms安装程序控制器
class IndexAction extends InstallAction{
    public function __construct() {
        parent::__construct();
    }
    
    public function index(){
        $this->smarty->display('1.html');
    }
    
    public function index_2(){
        $arr['install_mysqls'] = function_exists('mysql_connect') ? 1 : 0;
        $arr['install_gd'] = function_exists('gd_info');
        $arr['install_phpvs'] = phpversion();
        $arr['install_isphp'] = substr($arr['install_phpvs'],0,1) > 5 || substr($arr['install_phpvs'],0,1) == 5 ? 1 : 0;
        $arr['install_preg_replace'] = function_exists('preg_replace') ? 1 : 0;
        $arr['install_mysql_connect'] = function_exists('mysql_connect') ? 1 : 0;
        $arr['install_file_put_contents'] = function_exists('file_put_contents') ? 1 : 0;
        $arr['install_file_get_contents'] = function_exists('file_get_contents') ? 1 : 0;
        $dirArr = array(
            'install_dir_s' => '../',
            'install_dir_compile' => '../compile',
            'install_dir_data' => '../data',
            'install_dir_file' => '../file',
            'install_dir_inc' => '../inc',
            'install_dir_template' => '../template',
            'install_dir_install' => '../install',
        );
        //目录权限检测
        foreach($dirArr as $k=>$v){
            $dir[$k] = file::is_chmod($v);
        }
        //插入变量
        foreach($dir as $k=>$v){
            $this->smarty->assign($k,$v);
        }
        foreach($arr as $k=>$v){
            $this->smarty->assign($k,$v);
        }
        $this->smarty->display('2.html');
    }
    
    public function index_3(){
        if(!isset($_GET['sub2'])) rewrite::js_back ('请按照安装程序步骤安装');
        $this->smarty->display('3.html');
    }
    
    public function index_4(){
        if(!isset($_POST['sub3'])) rewrite::js_back ('请按照安装程序步骤安装');
        $postData = $this->checkform(); //验证数据
        $this->ismysql($postData); //验证mysql链接
        //修改缓存缓存文件
        $GLOBALS['public']['user_pwd_key'] = $postData['user_key']; //后台密码密钥
        $GLOBALS['public']['weburl'] = $this->url; //网站相对路径
        f('public/conf',$GLOBALS['public'],true);
        $this->updateConf($postData); //修改配置文件
        $this->index_4_to($postData);//开始安装
    }
    //修改配置文件
    private function updateConf($data){
        $configStr = file_get_contents('../inc/db.inc.php');
        $local = explode(':',$data['local']);
        $configStr = preg_replace('/define\(\'DB_HOST\',\'(.*)\'\)/',"define('DB_HOST','".$local[0]."')",$configStr);
        $configStr = preg_replace('/define\(\'DB_NAME\',\'(.*)\'\)/',"define('DB_NAME','".$data['dbname']."')",$configStr);
        $configStr = preg_replace('/define\(\'DB_USER\',\'(.*)\'\)/',"define('DB_USER','".$data['dbuser']."')",$configStr);
        $configStr = preg_replace('/define\(\'DB_PWD\',\'(.*)\'\)/',"define('DB_PWD','".$data['dbpwd']."')",$configStr);
        $configStr = preg_replace('/define\(\'DB_PORT\',\'(.*)\'\)/',"define('DB_PORT','".$local[1]."')",$configStr);
        $configStr = preg_replace('/define\(\'DB_PRE\',\'(.*)\'\)/',"define('DB_PRE','".$data['dbpre']."')",$configStr);
        //保存配置文件
        file_put_contents('../inc/db.inc.php',$configStr);
    }
    //验证数据库和管理员表单数据并返回
    private function checkform(){
        //获取数据
        $arr = p(1);
        unset($arr['sub3']);
        //验证数据
        if(!$arr['local']) rewrite::js_back('请填写数据库主机地址');
        if(!$arr['dbname']) rewrite::js_back('请填写数据库名称');
        if(!$arr['dbuser']) rewrite::js_back('请填写数据库用户名');
        if(!$arr['dbpre']) rewrite::js_back('请填写数据库表前缀');
        if(!preg_match('/_$/',$arr['dbpre'])) rewrite::js_back('数据库后缀必须以“_”结尾');
        if(!$arr['user_name']) rewrite::js_back('请填写管理员用户名');
        if(!$arr['user_pwd']) rewrite::js_back('请填写管理员密码');
        if(!$arr['user_pwd1']) rewrite::js_back('请填写管理员确认密码');
        if($arr['user_pwd'] != $arr['user_pwd1']) rewrite::js_back('管理员二次输入的密码不一致');
        if(!$arr['user_key']) rewrite::js_back('请填写密码加密字符串');
        return $arr;
    }
    //验证是否能够链接上mysql并导入数据库
    private function ismysql($data){
        $link=@mysql_connect($data['local'],$data['dbuser'],$data['dbpwd']);
        if(!$link) rewrite::js_back('无法链接数据库，请检查数据库配置信息');
        $select_db = @mysql_select_db($data['dbname'],$link);
        if(!$select_db) rewrite::js_back ('数据库名称有误，没有【'.$data['dbname'].'】这个数据库');
        mysql_close($link);
    }
    
    //第四步、导入数据库
    private function index_4_to($data){
        if(!$data) rewrite::js_back('请按照安装程序步骤安装');
        $this->smarty->display('4.html');
        $sql = file('mysql/lmxcms.sql');
        $index = 0;
        //初始化sql数据并分组sql
        foreach($sql as $v){
            if(preg_match('/^\s+$/',$v) || $v[0] == '#'){
                continue;
            }
            $v = str_replace(array('[--pre--]','[--webdir--]'),array($data['dbpre'],$this->url),trim($v));
            if(preg_match('/\;$/',$v)){
                $newsql[$index] .= $v;
                $index++;
            }else{
                $newsql[$index] .= $v;
            }
        }
        //执行sql
        $link=@mysql_connect($data['local'],$data['dbuser'],$data['dbpwd']);
        @mysql_select_db($data['dbname'],$link);
        mysql_query('SET NAMES '.DB_CHAR);
        foreach($newsql as $v){
            mysql_query($v,$link);
            if(preg_match('/^CREATE TABLE/',$v)){
                preg_match('/CREATE TABLE `(.*)`/U',$v,$dbname);
                echo "<script>$('#start').append('<li>创建【".$dbname[1]."】数据表成功</li>');scrollToBottom();</script>";
            }
            ob_flush(); 
            flush();
        }
        //插入管理员数据
        $GLOBALS['public']['user_pwd_key'] = $data['user_key'];
        $userSql = "INSERT INTO `".$data['dbpre']."user` VALUES(1,'".$data['user_name']."','".string::pwdmd5($data['user_pwd'])."','".time()."','".getip()."','".time()."','".getip()."',0,0,0,0);";
        mysql_query($userSql,$link);
        mysql_close($link);
        echo "<script type='text/javascript'>window.location.href='?m=Index&a=index_5';</script>'";
    }
    
    //安装完成
    public function index_5(){
        //创建安装完成印记
        file_put_contents('install_ok.txt','');
        $this->smarty->display('5.html');
    }
   
    
    
    
    
}
?>