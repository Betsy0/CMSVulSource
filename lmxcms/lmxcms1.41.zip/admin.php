<?php 
/**
 *  【梦想cms】 http://www.lmxcms.com
 * 
 *   后台入口文件
 */
define('LMXCMS',TRUE);
define('RUN_TYPE','admin');
require dirname(__FILE__).'/inc/config.inc.php';
require dirname(__FILE__).'/inc/run.inc.php';
?>