<?php 
 if(!defined('LMXCMS')){exit();} 
 //版本信息文件
 return array (
  'version' => '1.41',
) 
?>