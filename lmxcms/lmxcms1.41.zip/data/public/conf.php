<?php 
 if(!defined('LMXCMS')){exit();} 
 //本文件为缓存文件 无需手动更改
 return array (
  'default_temdir' => 'default',
  'user_pwd_key' => '1130973649',
  'weburl' => '/',
  'global' => 
  array (
    'webname_public' => '_梦想cms（lmxcms）',
  ),
  'globalType' => 
  array (
    'webname_public' => '1',
  ),
  'webname' => '梦想cms（lmxcms）是一套完全免费、开源、无授权限制的网站管理系统',
  'keywords' => 'lmxcms,梦想cms,无授权限制网站系统cms,免费cms系统,开源网站管理系统,开源cms',
  'description' => '梦想cms（lmxcms）完全免费、开源、无授权限制，您可以使用lmxcms在任何商业或者非商业网站上使用而不必支付任何费用，系统采用主流的mvc架构开发，更加容易进行二次开发，并且内置smarty模板引擎，标签扩展更灵活，并且支持html纯静态生成等功能。',
  'ishtml' => 0,
  'searchtime' => 5,
  'navsplit' => '-',
  'isbook' => 1,
  'repeatbook' => 10,
  'issmall' => 0,
  'iswater' => 0,
  'small_width' => 150,
  'small_height' => 140,
  'markImg' => '/file/mark/mark.png',
  'tuijianSelect' => '一级推荐
二级推荐
三级推荐
四级推荐
五级推荐
六级推荐
七级推荐
八级推荐
九级推荐
十级推荐',
  'remenSelect' => '一级热门
二级热门
三级热门
四级热门
五级热门
六级热门
七级热门
八级热门
九级热门
十级热门',
  'bookDisplay' => 1,
  'booknum' => 10,
  'searchnum' => 10,
  'login_mark' => 317529,
  'isbookdata' => 1,
  'version' => '1.4',
  'upload_file_pre' => 
  array (
    0 => 'rar',
    1 => 'zip',
  ),
  'upload_image_pre' => 
  array (
    0 => 'jpg',
    1 => 'gif',
    2 => 'png',
  ),
  'update_max_size' => 20,
  'q_upload_file_pre' => 
  array (
    0 => 'rar',
    1 => 'zip',
    2 => 'jpg',
    3 => 'gif',
    4 => 'png',
  ),
  'q_update_max_size' => 2,
  'is_search' => 1,
  'is_ip' => 0,
  'ip_list' => '',
  'contentkey' => 'lmxcms#####http://www.lmxcms.com#####0',
  'is_check_description' => 0,
  'is_content_key' => 0,
  'is_title_key' => 0,
) 
?>