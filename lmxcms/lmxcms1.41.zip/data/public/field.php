<?php 
 if(!defined('LMXCMS')){exit();} 
 //本文件为缓存文件 无需手动更改
 return array (
  1 => 
  array (
    3 => 
    array (
      'fid' => '3',
      'mid' => '1',
      'fname' => 'pic',
      'ftitle' => '产品图片',
      'ftype' => 'image',
      'ismust' => '0',
      'sort' => '2',
      'defaults' => '',
      'vice' => '0',
    ),
    4 => 
    array (
      'fid' => '4',
      'mid' => '1',
      'fname' => 'duotp',
      'ftitle' => '产品图片集',
      'ftype' => 'moreimage',
      'ismust' => '0',
      'sort' => '1',
      'defaults' => '',
      'vice' => '0',
    ),
    1 => 
    array (
      'fid' => '1',
      'mid' => '1',
      'fname' => 'content',
      'ftitle' => '正文',
      'ftype' => 'editor',
      'ismust' => '0',
      'sort' => '0',
      'defaults' => '',
      'vice' => '1',
    ),
  ),
  2 => 
  array (
    2 => 
    array (
      'fid' => '2',
      'mid' => '2',
      'fname' => 'content',
      'ftitle' => '正文',
      'ftype' => 'editor',
      'ismust' => '0',
      'sort' => '0',
      'defaults' => '',
      'vice' => '1',
    ),
  ),
) 
?>