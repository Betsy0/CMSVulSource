<?php 
/**
 *  【梦想cms】 http://www.lmxcms.com
 * 
 *   获取百度编辑器 单例模式
 */
defined('LMXCMS') or exit();
class edit{
    private static $editObj = null;
    private $path;
    public static function getEditObj(){
        if(self::$editObj == null) self::$editObj = new self();
        return self::$editObj;
    }
    
    //初始化配置参数
    private function __construct() {
        $this->path = '?m=Edit&a=editUpload';
    }
    
    //获取编辑器 $path:上传地址
    public function getEdit($path,$content=''){
        $path = trim($path,'/');
        $url = $_SERVER['SCRIPT_NAME'].'?m=Edit&a=editUpload';

        $str ="<div id='content'  style='width:100%;'>".html_entity_decode($content)."</div><textarea style='display:none;' id='contenttemp' name='content'>".html_entity_decode($content)."</textarea>";

        $str .= editJs()."<script type='text/javascript'>var editorParam = {
            dir: '".$path."',
            domain : window.location.protocol+ '//' + window.location.host + (window.location.port ? ':'+window.location.port : ''),
        };
        if(typeof E == 'undefined'){
            E = window.wangEditor;
        }
        var content = new E('#content');
        content.config.onchange = function (html) {
            // 第二步，监控变化，同步更新到 textarea
            $('#contenttemp').val(html)
        }
        content.config.uploadImgServer = '$url';
        content.config.uploadFileName = 'file';
        if(typeof editorParam != 'undefined'){
            content.config.uploadImgParams = editorParam;
        }
        content.create();
        </script>";
        return $str;
    }
    
    //图片附加上传类  上传地址  上传Upload类参数配置 配置具体查看 upload类
    public function upload($path,$domain,$config='') {
       if($config && is_array($config)){
           $upload = new upload();
           foreach($config as $k => $v){
               $upload->setConfig($k,$v);
           }
       }else{
           $upload = new upload();
       }
       $is_upload = $upload->upload($path);
       if($is_upload){
            $info = $upload->getSucc();
            echo json_encode(array(
                'errno' => 0,
                'data' => array(
                    array(
                        'url' => $domain.'/'.$path.'/'.$info[0]['file'],
                    )
                ),
            ));
       }else{
            echo json_encode(array(
                'errno' => -1,
                'error' => $upload->getMsg(),
            ));
       }
   } 
}
?>