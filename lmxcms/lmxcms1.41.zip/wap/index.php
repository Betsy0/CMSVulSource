<?php 
/**
 *  【梦想cms】 http://www.lmxcms.com
 * 
 *   前台入口文件
 */
define('LMXCMS',TRUE);
define('RUN_TYPE','index');
define('TEMDIR','m'); //手机模板目录
define('COMPILE_DIR','m'); //手机编译目录 
define('COMPILE_CACHE_DIR','m'); //手机编译缓存目录
require dirname(__FILE__).'/../inc/config.inc.php';
require dirname(__FILE__).'/../inc/run.inc.php';
?>