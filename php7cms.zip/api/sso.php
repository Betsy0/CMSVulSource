<?php

/**
 * 单点登录系统
 */

define('IS_API', 'sso'); // 项目标识
define('SELF', pathinfo(__FILE__, PATHINFO_BASENAME)); // 该文件的名称
require('../index.php'); // 引入主文件