<?php

/**
 * 百度编辑器
 */

define('IS_API', 'ueditor'); // 项目标识
define('SELF', pathinfo(__FILE__, PATHINFO_BASENAME)); // 该文件的名称
require('../index.php'); // 引入主文件