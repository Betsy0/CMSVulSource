<?php

return [

    'type' => 'module',
    'name' => '文章',
    'icon' => 'fa fa-code',
    'system' => '1',

];