<?php

/**
 * 百度编辑器处理接口
 */



require ROOTPATH.'api/umeditor/php/imageUp.php';