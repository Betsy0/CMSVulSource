<?php

/**
 * 百度编辑器处理接口
 */



require ROOTPATH.'api/ueditor/php/controller.php';