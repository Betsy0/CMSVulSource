<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
	<meta name="robots" content="noindex">

    <title>系统提示</title>

    <style type="text/css">
		<?= preg_replace('#[\r\n\t ]+#', ' ', file_get_contents(__DIR__.DIRECTORY_SEPARATOR.'debug.css')) ?>
	</style>
</head>
<body>

	<div class="container text-center">

		<h1 class="headline">暂时无法访问</h1>

	</div>

</body>

</html>
