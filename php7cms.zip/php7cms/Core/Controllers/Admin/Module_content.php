<?php namespace Phpcmf\Controllers\Admin;

class Module_content extends \Phpcmf\Common
{



}
