<?php namespace Phpcmf\Controllers\Admin;

class Menu extends \Phpcmf\Common
{

	public function index() {

        \Phpcmf\Service::M('Menu')->init('admin');
        \Phpcmf\Service::L('Input')->system_log('初始化后台菜单');
	}
	


}
