<?php namespace Phpcmf\Controllers\Admin;

// 管理员
class Root extends \Phpcmf\Table
{


}
