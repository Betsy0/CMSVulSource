<?php namespace Phpcmf\Controllers\Api;

// 付款
class Pay extends \Phpcmf\Common
{


}
