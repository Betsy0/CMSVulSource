<?php namespace Phpcmf\Controllers\Api;

// 交易下单
class Buy extends \Phpcmf\Common {

    public function index() {


    }
}
