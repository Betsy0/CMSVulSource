<?php namespace Phpcmf\Controllers\Api;

// 快捷登录接口
class Oauth extends \Phpcmf\Common
{

	/**
	 * 快捷登录
	 */
}
