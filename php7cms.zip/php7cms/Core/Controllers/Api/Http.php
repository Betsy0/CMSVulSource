<?php namespace Phpcmf\Controllers\Api;

// Http接口处理
class Http extends \Phpcmf\Common
{



}
