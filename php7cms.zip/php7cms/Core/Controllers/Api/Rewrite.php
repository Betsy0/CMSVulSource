<?php namespace Phpcmf\Controllers\Api;

// 系统默认伪静态处理
class Rewrite extends \Phpcmf\Common
{

	// test
	public function test() {
		echo '你的服务器支持伪静态功能 <br> 你可以自定义URL规则和解析规则了';exit;
	}

}
