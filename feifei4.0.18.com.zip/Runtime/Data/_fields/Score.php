<?php
return array (
  0 => 'score_id',
  1 => 'score_uid',
  2 => 'score_sid',
  3 => 'score_did',
  4 => 'score_type',
  5 => 'score_ext',
  6 => 'score_addtime',
  '_autoinc' => true,
  '_pk' => 'score_id',
  '_type' => 
  array (
    'score_id' => 'int(10)',
    'score_uid' => 'mediumint(8)',
    'score_sid' => 'tinyint(3)',
    'score_did' => 'mediumint(8)',
    'score_type' => 'tinyint(3)',
    'score_ext' => 'mediumint(8)',
    'score_addtime' => 'int(11)',
  ),
);
?>