<?php
return array (
  0 => 'link_id',
  1 => 'link_name',
  2 => 'link_logo',
  3 => 'link_url',
  4 => 'link_order',
  5 => 'link_type',
  '_autoinc' => true,
  '_pk' => 'link_id',
  '_type' => 
  array (
    'link_id' => 'tinyint(4) unsigned',
    'link_name' => 'varchar(255)',
    'link_logo' => 'varchar(255)',
    'link_url' => 'varchar(255)',
    'link_order' => 'tinyint(4)',
    'link_type' => 'tinyint(1)',
  ),
);
?>