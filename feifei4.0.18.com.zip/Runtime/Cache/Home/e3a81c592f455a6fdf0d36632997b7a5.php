<?php if (!defined('THINK_PATH')) exit();?><?php $item_score = ff_mysql_score('uid:'.$user_id.';limit:30;page_is:true;page_id:score;page_p:'.$user_page.';order:score_id;sort:desc');
$page = ff_url_page('user/center',array('action'=>'buy','p'=>'FFLINK'),true,'score',4);
$totalpages = ff_page_count('score', 'totalpages'); ?><!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<meta name="renderer" content="webkit">
<link rel="shortcut icon" href="<?php echo ($root); ?>favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="<?php echo ($public_path); ?>bootstrap/3.3.5/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo ($tpl_path); ?>user.css?<?php echo L("feifeicms_version");?>">
<script type="text/javascript">var cms = {
root:"<?php echo ($root); ?>",id:"<?php echo ($vod_id); ?><?php echo ($news_id); ?><?php echo ($special_id); ?>",userid:"<?php echo ($user_id); ?>",page:"<?php echo (($list_page)?($list_page):1); ?>",domain_m:"<?php echo ($site_domain_m); ?>"
}</script><script type="text/javascript" src="<?php echo ($public_path); ?>jquery/1.11.3/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo ($public_path); ?>bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo ($public_path); ?>js/system.js?<?php echo L("feifeicms_version");?>"></script>
<!--[if lt IE 9]>
<script src="<?php echo ($public_path); ?>html5shiv/3.7.2/html5shiv.min.js"></script>
<script src="<?php echo ($public_path); ?>respond/1.4.2/respond.min.js"></script>
<![endif]-->
<title>消费记录_<?php echo ($site_name); ?></title>
<meta name="keywords" content="<?php echo ($site_name); ?>用户中心">
<meta name="description" content="欢迎回到<?php echo ($site_name); ?>用户中心">
</head>
<body>
<body class="user-center">
<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
<div class="container">
  <div class="navbar-header navbar-left">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse">
    <span class="sr-only">切换导航</span>
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>
    </button>
    <a class="navbar-brand" href="<?php echo ff_url('user/center',array('action'=>'index'));?>">用户中心</a>
  </div>
  <div class="collapse navbar-collapse" id="navbar-collapse">
    <ul class="nav navbar-nav">
    	<li><a href="<?php echo ($root); ?>">网站首页</a></li>
      <li <?php if(($user_action)  ==  "index"): ?>class="active"<?php endif; ?>><a href="<?php echo ff_url('user/center',array('action'=>'index'));?>">帐号管理</a></li>
      <li <?php if(($user_action)  ==  "orders"): ?>class="active"<?php endif; ?>><a href="<?php echo ff_url('user/center',array('action'=>'orders'));?>">订单管理</a></li>
      <li <?php if(($user_action)  ==  "buy"): ?>class="active"<?php endif; ?>><a href="<?php echo ff_url('user/center',array('action'=>'buy'));?>">影币记录</a></li>
      <li <?php if(($user_action)  ==  "history"): ?>class="active"<?php endif; ?>><a href="<?php echo ff_url('user/center',array('action'=>'history'));?>">观看记录</a></li>
      <li <?php if(($user_action)  ==  "forum"): ?>class="active"<?php endif; ?>><a href="<?php echo ff_url('user/center',array('action'=>'forum'));?>">我的话题</a></li>
      <li <?php if(($user_action)  ==  "likes"): ?>class="active"<?php endif; ?>><a href="<?php echo ff_url('user/center',array('action'=>'likes'));?>">收藏</a></li>
      <li <?php if(($user_action)  ==  "wish"): ?>class="active"<?php endif; ?>><a href="<?php echo ff_url('user/center',array('action'=>'wish'));?>">想看</a></li>
      <li <?php if(($user_action)  ==  "do"): ?>class="active"<?php endif; ?>><a href="<?php echo ff_url('user/center',array('action'=>'do'));?>">在看</a></li>
      <li <?php if(($user_action)  ==  "collect"): ?>class="active"<?php endif; ?>><a href="<?php echo ff_url('user/center',array('action'=>'collect'));?>">看过</a></li>
      <li><a class="ff-text" href="<?php echo ff_url('user/logout');?>">退出</a></li>
  </div>
</div>
</nav>
<?php if(($user_action)  ==  "index"): ?><div class="container ff-bg">
    <h2 class="text-center">
      <a href="<?php echo ff_url('user/center');?>">
        <img class="img-circle face" src="<?php echo ((ff_url_img($user_face))?(ff_url_img($user_face)):$root.'Public/images/face/default.png'); ?> " align="用户中心">
      </a>
    </h2>
    <h4 class="text-center user-name">
      <?php echo (nb(htmlspecialchars($user_name))); ?>
    </h4>
    <h6 class="text-center user-link">
      <a href="<?php echo ff_url('user/index',array('id'=>$user_id));?>" class="ff-text">
        <?php echo ($site_url); ?><?php echo ff_url('user/index',array('id'=>$user_id));?>
      </a>
    </h6>
  </div>
  <div class="clearfix"></div><?php endif; ?>
<div class="container ff-bg">
<div class="row">
  <div class="col-xs-12 ff-col">
    <div class="page-header">
      <h4><span class="glyphicon glyphicon-menu-right ff-text"></span> 我的影币记录</h4>
    </div>
		<div class="table-responsive">
			<table class="table table-bordered table-responsive text-center">
			<thead>
				<tr>
					<th class="text-center">频道</th>
					<th class="text-center">类型</th>
					<th class="text-center">变化值</th>
					<th class="text-center">操作时间</th>
				</tr>
			</thead>
			<tbody>
			 <?php if(is_array($item_score)): $i = 0; $__LIST__ = $item_score;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$feifei): ++$i;$mod = ($i % 2 )?><tr>
					<td><?php switch($feifei["score_sid"]): ?><?php case "1":  ?>视频<?php break;?><?php case "2":  ?>文章<?php break;?><?php case "3":  ?>专题<?php break;?><?php default: ?>用户<?php endswitch;?></td>
					<td><?php switch($feifei["score_type"]): ?><?php case "1":  ?>影币充值<?php break;?><?php case "2":  ?>注册赠送<?php break;?><?php case "3":  ?>管理员操作<?php break;?><?php case "4":  ?>推广奖励<?php break;?><?php case "5":  ?>退货返还<?php break;?><?php case "6":  ?>卡密充值<?php break;?><?php case "21":  ?>升级VIP<?php break;?><?php case "22":  ?><a href="<?php echo ff_url('vod/read',array('id'=>$feifei['score_did']),true);?>" target="_blank">付费点播<?php break;?><?php default: ?>未知<?php endswitch;?></td>
					<td class="ff-text"><?php echo ($feifei["score_ext"]); ?></td>
					<td class="ff-text"><?php echo (date('Y-m-d H:i',$feifei["score_addtime"])); ?></td>
				</tr><?php endforeach; endif; else: echo "" ;endif; ?>
			</tbody>
			</table>
		</div>
  </div>
  <!-- -->
  <?php if(($totalpages)  >  "1"): ?><div class="clearfix"></div>
    <div class="col-xs-12 ff-col text-center">
      <ul class="pagination pagination-lg hidden-xs">
        <?php echo ($page); ?>
      </ul>
      <ul class="pager visible-xs">
      	<?php if(($user_page)  >  "1"): ?><li><a id="ff-prev" href="<?php echo ff_url('user/center', array('action'=>'buy','p'=>($user_page-1)), true);?>">上一页</a></li><?php endif; ?>
        <?php if(($user_page)  <  $totalpages): ?><li><a id="ff-next" href="<?php echo ff_url('user/center', array('action'=>'buy','p'=>($user_page+1)), true);?>">下一页</a></li><?php endif; ?>
       </ul> 
    </div><?php endif; ?>
</div><!--row end -->
</div>
<div class="clearfix ff-clearfix"></div>
<div class="container ff-bg ff-footer">
<div class="row">
  <div class="col-xs-12 ff-col text-center">
  <p><?php echo ($site_description); ?></p>
  <p><?php echo ($site_copyright); ?></p>
  <p>Powerd by <a href="http://www.feifeicms.com/" target="_blank">feifeicms <?php echo L("feifeicms_version");?></a></p>
  </div>
</div>
<span style="display:none"><?php echo ($site_tongji); ?></span>
</div>
</body>
</html>