<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<meta name="renderer" content="webkit">
<link rel="shortcut icon" href="<?php echo ($root); ?>favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="<?php echo ($public_path); ?>bootstrap/3.3.5/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo ($tpl_path); ?>user.css?<?php echo L("feifeicms_version");?>">
<script type="text/javascript">var cms = {
root:"<?php echo ($root); ?>",id:"<?php echo ($vod_id); ?><?php echo ($news_id); ?><?php echo ($special_id); ?>",userid:"<?php echo ($user_id); ?>",page:"<?php echo (($list_page)?($list_page):1); ?>",domain_m:"<?php echo ($site_domain_m); ?>"
}</script><script type="text/javascript" src="<?php echo ($public_path); ?>jquery/1.11.3/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo ($public_path); ?>bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo ($public_path); ?>js/system.js?<?php echo L("feifeicms_version");?>"></script>
<!--[if lt IE 9]>
<script src="<?php echo ($public_path); ?>html5shiv/3.7.2/html5shiv.min.js"></script>
<script src="<?php echo ($public_path); ?>respond/1.4.2/respond.min.js"></script>
<![endif]-->
<title>欢迎加入_<?php echo ($site_name); ?></title>
<meta name="keywords" content="<?php echo ($site_name); ?>用户注册界面">
<meta name="description" content="欢迎加入<?php echo ($site_name); ?>大家庭。">
<script>
$(document).ready(function(){	
$(".form-user-register").on('submit',function(e){
	$('.ff-alert').html('');
	$('.form-user-register .help-block').remove();
	$('.form-user-register .form-group').removeClass('has-error');
	if($("#user_name").val().length < 3 || $("#user_name").val().length >12){
		$('#user_name').parent().addClass('has-error');
		$('#user_name').after('<span class="help-block">用户名长度为3-12个字符</span>');
		return false;
	}
	if($("#user_email").val().search(/\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/)==-1){
		$('#user_email').parent().addClass('has-error');
		$('#user_email').after('<span class="help-block">请输入正确的EMAIL格式</span>');
		return false;
	}
	if($("#user_pwd").val().length < 6){
		$('#user_pwd').parent().addClass('has-error');
		$('#user_pwd').after('<span class="help-block">请至少输入6个字符作为密码</span>');
		return false;
	}
	$.ajax({
		url: $(this).attr('action'),
		type: 'POST',
		dataType: 'json',
		timeout: 6000,
		data: $(this).serialize(),
		beforeSend: function(xhr){
			$('#user-submit').html('正在注册');
		},
		error : function(){
			feifei.alert.warning('.ff-alert','请求失败，请刷新网页。');
		},
		success: function(json){
			if(json.status == 200){
				if(json.data.referer){
					top.location.href = json.data.referer;
				}else{
					top.location.href = '<?php echo ff_url("user/center",array("action"=>"index"));?>';
				}
			}else if(json.status == 201){
				$('#user-submit').html('注册');
				feifei.alert.warning('.ff-alert','已注册');
			}else{
				$('#user-submit').html('注册');
				feifei.alert.warning('.ff-alert',json.info);
			}
		},
		complete: function(xhr){
		}
	});
	return false;
});
});
</script>
</head>
<body class="user-register">
<div class="container ff-bg">
<div class="row">
<div class="col-md-6 col-md-offset-3">
  <h2 class="text-center">
  	<a href="<?php echo ff_url('user/register');?>">欢迎加入<?php echo ($site_name); ?></a>
  </h2>
  <h5 class="text-center">
    <a class="ff-text" href="<?php echo ($root); ?>">返回首页</a>
    <a class="ff-text" href="<?php echo ff_url('user/forget');?>">忘记密码</a>
    <a class="ff-text" href="<?php echo ff_url('user/login');?>">已有帐号登录</a>
  </h5>
  <div class="row">
  <div class="col-xs-12 ff-col">
  	<h4 class="text-muted">
      创建新账号
    </h4>
    <form class="form-horizontal form-user-register" action="<?php echo ff_url('user/post');?>" method="post" role="form" target="_blank">
      <div class="form-group">
        <label for="user_name" class="col-md-3 control-label">昵称</label>
        <div class="col-md-8">
          <input class="form-control" name="user_name" id="user_name" type="text" placeholder="字母、数字等，用户名唯一" title="" data-toggle="tooltip" data-placement="bottom" required>
        </div>
      </div>
      <div class="form-group">
        <label for="user_email" class="col-md-3 control-label">邮箱</label>
        <div class="col-md-8">
          <input class="form-control" name="user_email" id="user_email" type="text" placeholder="常用邮箱 test@feifeicms.com" required>
        </div>
      </div>
      <div class="form-group">
        <label for="user_pwd" class="col-md-3 control-label">密码</label>
        <div class="col-md-8">
          <input class="form-control" name="user_pwd" id="user_pwd" type="password" placeholder="不少于 6 位" required>
        </div>
      </div>
      <div class="form-group">
        <label for="user_pwd_re" class="col-md-3 control-label">确认密码</label>
        <div class="col-md-8">
          <input class="form-control" name="user_pwd_re" id="user_pwd_re" type="password" placeholder="重复输入密码" required>
        </div>
      </div>
      <div class="form-group">
        <div class="col-xs-8 checkbox text-right">
           <label id="ajax-info">同意并接受<a href="javascript:;">《服务条款》</a></label>
         </div>
         <div class="col-xs-3 text-right">
           <button type="submit" class="btn btn-success" id="user-submit">注册</button>
         </div>
      </div>
      <div class="form-group ff-alert clearfix">
  		</div>
  	</form>
  </div>
  </div>
</div>    
</div>
</div>
<div class="clearfix ff-clearfix"></div>
<div class="container ff-bg ff-footer">
<div class="row">
  <div class="col-xs-12 ff-col text-center">
  <p><?php echo ($site_description); ?></p>
  <p><?php echo ($site_copyright); ?></p>
  <p>Powerd by <a href="http://www.feifeicms.com/" target="_blank">feifeicms <?php echo L("feifeicms_version");?></a></p>
  </div>
</div>
<span style="display:none"><?php echo ($site_tongji); ?></span>
</div>
</body>
</html>