<?php if (!defined('THINK_PATH')) exit();?>﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>管理平台-<?php echo C("site_name");?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>
<frameset rows="82,*" frameborder="NO" border="0" framespacing="0" cols="*">  
	<frame name="top" scrolling="NO" noresize src="?s=Admin-Index-Top" />
	<frameset cols="140,*" frameborder="NO" border="0" framespacing="0" rows="*" />    
		<frame name="left" scrolling="NO" noresize src="?s=Admin-Index-Left" /> 
		<frame name="right" src="?s=Admin-Index-Right"></frame> 
	</frameset>
</frameset>
<noframes>
	<body >不支持框架!</body>
</noframes>
</html>