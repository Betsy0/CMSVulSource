<?php  return array (
  0 => 
  array (
    'catid' => '98',
    'parentid' => '0',
    'catname' => '精選品',
    'nofollow' => '0',
    'isblank' => '0',
    'isshow' => '1',
    'url' => '/index.php?case=archive&act=list&catid=98',
  ),
);