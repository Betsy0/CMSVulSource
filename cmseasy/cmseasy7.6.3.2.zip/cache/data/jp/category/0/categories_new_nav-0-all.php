<?php  return array (
  0 => 
  array (
    'catid' => '88',
    'parentid' => '0',
    'catname' => '私たちについて',
    'nofollow' => '0',
    'isblank' => '0',
    'isshow' => '1',
    'url' => '/index.php?case=archive&act=list&catid=88',
  ),
  1 => 
  array (
    'catid' => '98',
    'parentid' => '0',
    'catname' => '精選品',
    'nofollow' => '0',
    'isblank' => '0',
    'isshow' => '1',
    'url' => '/index.php?case=archive&act=list&catid=98',
    'children' => 
    array (
      0 => 
      array (
        'catid' => '102',
        'parentid' => '98',
        'catname' => '健康な子供',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=102',
      ),
      1 => 
      array (
        'catid' => '101',
        'parentid' => '98',
        'catname' => 'スマートウェア',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=101',
      ),
      2 => 
      array (
        'catid' => '100',
        'parentid' => '98',
        'catname' => '家電製品',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=100',
      ),
      3 => 
      array (
        'catid' => '99',
        'parentid' => '98',
        'catname' => 'インテリジェント製品',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=99',
      ),
    ),
  ),
  2 => 
  array (
    'catid' => '108',
    'parentid' => '0',
    'catname' => 'ニュース',
    'nofollow' => '0',
    'isblank' => '0',
    'isshow' => '1',
    'url' => '/index.php?case=archive&act=list&catid=108',
    'children' => 
    array (
      0 => 
      array (
        'catid' => '110',
        'parentid' => '108',
        'catname' => '業界ニュース',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=110',
      ),
      1 => 
      array (
        'catid' => '109',
        'parentid' => '108',
        'catname' => '企業ニュース',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=109',
      ),
    ),
  ),
  3 => 
  array (
    'catid' => '115',
    'parentid' => '0',
    'catname' => '人的資源',
    'nofollow' => '0',
    'isblank' => '0',
    'isshow' => '1',
    'url' => '/index.php?case=archive&act=list&catid=115',
  ),
  4 => 
  array (
    'catid' => '97',
    'parentid' => '0',
    'catname' => '連絡します',
    'nofollow' => '0',
    'isblank' => '0',
    'isshow' => '1',
    'url' => '/index.php?case=archive&act=list&catid=97',
  ),
);