<?php  return array (
  0 => 
  array (
    'typeid' => '206',
    'image' => '/html/upload/images/201907/15591099453652.jpg',
    'url' => '/index.php?case=type&act=list&typeid=206',
  ),
);