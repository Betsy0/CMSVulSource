<?php  return array (
  0 => 
  array (
    'catid' => '51',
    'parentid' => '0',
    'catname' => 'About us',
    'nofollow' => '0',
    'isblank' => '0',
    'isshow' => '1',
    'url' => '/index.php?case=archive&act=list&catid=51',
    'children' => 
    array (
      0 => 
      array (
        'catid' => '86',
        'parentid' => '51',
        'catname' => 'Leadership Care',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=86',
      ),
      1 => 
      array (
        'catid' => '85',
        'parentid' => '51',
        'catname' => 'honor',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=85',
      ),
      2 => 
      array (
        'catid' => '83',
        'parentid' => '51',
        'catname' => 'development history',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=83',
      ),
      3 => 
      array (
        'catid' => '82',
        'parentid' => '51',
        'catname' => 'Brief Introduction to the Group',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=82',
      ),
      4 => 
      array (
        'catid' => '81',
        'parentid' => '51',
        'catname' => 'Address by the Chairman',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=81',
      ),
    ),
  ),
  1 => 
  array (
    'catid' => '61',
    'parentid' => '0',
    'catname' => 'Shopping',
    'nofollow' => '0',
    'isblank' => '0',
    'isshow' => '1',
    'url' => '/index.php?case=archive&act=list&catid=61',
    'children' => 
    array (
      0 => 
      array (
        'catid' => '65',
        'parentid' => '61',
        'catname' => 'Healthy children',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=65',
      ),
      1 => 
      array (
        'catid' => '64',
        'parentid' => '61',
        'catname' => 'Intelligent Wearing',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=64',
      ),
      2 => 
      array (
        'catid' => '63',
        'parentid' => '61',
        'catname' => 'Home Appliance Products',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=63',
      ),
      3 => 
      array (
        'catid' => '62',
        'parentid' => '61',
        'catname' => 'Intelligent products',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=62',
      ),
    ),
  ),
  2 => 
  array (
    'catid' => '71',
    'parentid' => '0',
    'catname' => 'News',
    'nofollow' => '0',
    'isblank' => '0',
    'isshow' => '1',
    'url' => '/index.php?case=archive&act=list&catid=71',
    'children' => 
    array (
      0 => 
      array (
        'catid' => '73',
        'parentid' => '71',
        'catname' => 'Industry News',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=73',
      ),
      1 => 
      array (
        'catid' => '72',
        'parentid' => '71',
        'catname' => 'Enterprise News',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=72',
      ),
    ),
  ),
  3 => 
  array (
    'catid' => '77',
    'parentid' => '0',
    'catname' => 'Job',
    'nofollow' => '0',
    'isblank' => '0',
    'isshow' => '1',
    'url' => '/index.php?case=archive&act=list&catid=77',
    'children' => 
    array (
      0 => 
      array (
        'catid' => '80',
        'parentid' => '77',
        'catname' => 'Fashion figures',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=80',
      ),
      1 => 
      array (
        'catid' => '79',
        'parentid' => '77',
        'catname' => 'Employment opportunities',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=79',
      ),
      2 => 
      array (
        'catid' => '78',
        'parentid' => '77',
        'catname' => 'Employee Development',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=78',
      ),
    ),
  ),
  4 => 
  array (
    'catid' => '60',
    'parentid' => '0',
    'catname' => 'Contact us',
    'nofollow' => '0',
    'isblank' => '0',
    'isshow' => '1',
    'url' => '/index.php?case=archive&act=list&catid=60',
  ),
);