<?php  return array (
  0 => 
  array (
    'catid' => '61',
    'parentid' => '0',
    'catname' => 'Shopping',
    'nofollow' => '0',
    'isblank' => '0',
    'isshow' => '1',
    'url' => '/index.php?case=archive&act=list&catid=61',
    'children' => 
    array (
      0 => 
      array (
        'catid' => '62',
        'parentid' => '61',
        'catname' => 'Intelligent products',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=62',
      ),
      1 => 
      array (
        'catid' => '63',
        'parentid' => '61',
        'catname' => 'Home Appliance Products',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=63',
      ),
      2 => 
      array (
        'catid' => '64',
        'parentid' => '61',
        'catname' => 'Intelligent Wearing',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=64',
      ),
      3 => 
      array (
        'catid' => '65',
        'parentid' => '61',
        'catname' => 'Healthy children',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=65',
      ),
    ),
  ),
);