<?php  return array (
  0 => 
  array (
    'catid' => '61',
    'parentid' => '0',
    'catname' => 'Shopping',
    'nofollow' => '0',
    'isblank' => '0',
    'isshow' => '1',
    'url' => '/index.php?case=archive&act=list&catid=61',
  ),
);