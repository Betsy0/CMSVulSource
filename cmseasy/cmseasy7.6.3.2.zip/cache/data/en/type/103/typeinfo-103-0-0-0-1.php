<?php  return array (
  0 => 
  array (
    'typeid' => '103',
    'image' => '/html/upload/images/201907/15591099593550.jpg',
    'url' => '/index.php?case=type&act=list&typeid=103',
  ),
);