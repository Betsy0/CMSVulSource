<?php  return array (
  0 => 
  array (
    'catid' => '133',
    'parentid' => '0',
    'catname' => '정선 제품',
    'nofollow' => '0',
    'isblank' => '0',
    'isshow' => '1',
    'url' => '/index.php?case=archive&act=list&catid=133',
  ),
);