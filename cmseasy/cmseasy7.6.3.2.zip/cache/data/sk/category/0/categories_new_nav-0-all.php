<?php  return array (
  0 => 
  array (
    'catid' => '123',
    'parentid' => '0',
    'catname' => '우리가 어떻게',
    'nofollow' => '0',
    'isblank' => '0',
    'isshow' => '1',
    'url' => '/index.php?case=archive&act=list&catid=123',
  ),
  1 => 
  array (
    'catid' => '133',
    'parentid' => '0',
    'catname' => '정선 제품',
    'nofollow' => '0',
    'isblank' => '0',
    'isshow' => '1',
    'url' => '/index.php?case=archive&act=list&catid=133',
    'children' => 
    array (
      0 => 
      array (
        'catid' => '136',
        'parentid' => '133',
        'catname' => '스마트 착용',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=136',
      ),
      1 => 
      array (
        'catid' => '137',
        'parentid' => '133',
        'catname' => '건강 아동',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=137',
      ),
      2 => 
      array (
        'catid' => '135',
        'parentid' => '133',
        'catname' => '가전제품',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=135',
      ),
      3 => 
      array (
        'catid' => '134',
        'parentid' => '133',
        'catname' => '스마트 제품',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=134',
      ),
    ),
  ),
  2 => 
  array (
    'catid' => '143',
    'parentid' => '0',
    'catname' => '뉴스 정보',
    'nofollow' => '0',
    'isblank' => '0',
    'isshow' => '1',
    'url' => '/index.php?case=archive&act=list&catid=143',
    'children' => 
    array (
      0 => 
      array (
        'catid' => '145',
        'parentid' => '143',
        'catname' => '업종 뉴스',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=145',
      ),
      1 => 
      array (
        'catid' => '144',
        'parentid' => '143',
        'catname' => '기업 뉴스',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=144',
      ),
    ),
  ),
  3 => 
  array (
    'catid' => '147',
    'parentid' => '0',
    'catname' => '인적 자원',
    'nofollow' => '0',
    'isblank' => '0',
    'isshow' => '1',
    'url' => '/index.php?case=archive&act=list&catid=147',
    'children' => 
    array (
      0 => 
      array (
        'catid' => '150',
        'parentid' => '147',
        'catname' => '풍조 인물',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=150',
      ),
      1 => 
      array (
        'catid' => '149',
        'parentid' => '147',
        'catname' => '취업 기회',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=149',
      ),
      2 => 
      array (
        'catid' => '148',
        'parentid' => '147',
        'catname' => '종업원 발전',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=148',
      ),
    ),
  ),
  4 => 
  array (
    'catid' => '132',
    'parentid' => '0',
    'catname' => '연락해 주세요',
    'nofollow' => '0',
    'isblank' => '0',
    'isshow' => '1',
    'url' => '/index.php?case=archive&act=list&catid=132',
  ),
);