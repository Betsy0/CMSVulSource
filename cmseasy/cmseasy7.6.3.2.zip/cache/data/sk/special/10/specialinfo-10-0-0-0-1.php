<?php  return array (
  0 => 
  array (
    'spid' => '10',
    'adddate' => '1563520169',
    'banner' => '/html/upload/images/201907/15590979873694.jpg',
    'url' => '/index.php?case=special&act=show&spid=&10=',
  ),
);