<?php  return array (
  0 => 
  array (
    'catid' => '11',
    'parentid' => '0',
    'catname' => '精选产品',
    'nofollow' => '0',
    'isblank' => '0',
    'isshow' => '1',
    'url' => '/index.php?case=archive&act=list&catid=11',
    'children' => 
    array (
      0 => 
      array (
        'catid' => '12',
        'parentid' => '11',
        'catname' => '智能产品',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=12',
      ),
      1 => 
      array (
        'catid' => '13',
        'parentid' => '11',
        'catname' => '家电产品',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=13',
      ),
      2 => 
      array (
        'catid' => '14',
        'parentid' => '11',
        'catname' => '智能穿戴',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=14',
      ),
      3 => 
      array (
        'catid' => '15',
        'parentid' => '11',
        'catname' => '健康儿童',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=15',
      ),
    ),
  ),
);