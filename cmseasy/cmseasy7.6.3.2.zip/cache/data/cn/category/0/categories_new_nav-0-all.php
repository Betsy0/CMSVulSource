<?php  return array (
  0 => 
  array (
    'catid' => '1',
    'parentid' => '0',
    'catname' => '关于我们',
    'nofollow' => '0',
    'isblank' => '0',
    'isshow' => '1',
    'url' => '/index.php?case=archive&act=list&catid=1',
  ),
  1 => 
  array (
    'catid' => '11',
    'parentid' => '0',
    'catname' => '精选产品',
    'nofollow' => '0',
    'isblank' => '0',
    'isshow' => '1',
    'url' => '/index.php?case=archive&act=list&catid=11',
    'children' => 
    array (
      0 => 
      array (
        'catid' => '15',
        'parentid' => '11',
        'catname' => '健康儿童',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=15',
      ),
      1 => 
      array (
        'catid' => '14',
        'parentid' => '11',
        'catname' => '智能穿戴',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=14',
      ),
      2 => 
      array (
        'catid' => '13',
        'parentid' => '11',
        'catname' => '家电产品',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=13',
      ),
      3 => 
      array (
        'catid' => '12',
        'parentid' => '11',
        'catname' => '智能产品',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=12',
      ),
    ),
  ),
  2 => 
  array (
    'catid' => '21',
    'parentid' => '0',
    'catname' => '新闻资讯',
    'nofollow' => '0',
    'isblank' => '0',
    'isshow' => '1',
    'url' => '/index.php?case=archive&act=list&catid=21',
    'children' => 
    array (
      0 => 
      array (
        'catid' => '23',
        'parentid' => '21',
        'catname' => '行业新闻',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=23',
      ),
      1 => 
      array (
        'catid' => '22',
        'parentid' => '21',
        'catname' => '企业新闻',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=22',
      ),
    ),
  ),
  3 => 
  array (
    'catid' => '27',
    'parentid' => '0',
    'catname' => '人力资源',
    'nofollow' => '0',
    'isblank' => '0',
    'isshow' => '1',
    'url' => '/index.php?case=archive&act=list&catid=27',
    'children' => 
    array (
      0 => 
      array (
        'catid' => '30',
        'parentid' => '27',
        'catname' => '风尚人物',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=30',
      ),
      1 => 
      array (
        'catid' => '29',
        'parentid' => '27',
        'catname' => '就业机会',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=29',
      ),
      2 => 
      array (
        'catid' => '28',
        'parentid' => '27',
        'catname' => '员工发展',
        'nofollow' => '0',
        'isblank' => '0',
        'isshow' => '1',
        'url' => '/index.php?case=archive&act=list&catid=28',
      ),
    ),
  ),
  4 => 
  array (
    'catid' => '10',
    'parentid' => '0',
    'catname' => '联系我们',
    'nofollow' => '0',
    'isblank' => '0',
    'isshow' => '1',
    'url' => '/index.php?case=archive&act=list&catid=10',
  ),
);