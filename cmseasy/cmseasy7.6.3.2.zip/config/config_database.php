<?php if (!defined('ROOT')) exit('Can\'t Access !'); return array (

'database'=>array(
'hostname'=>'127.0.0.1',//MySQL服务器
'database'=>'',//数据库名
'user'=>'',//数据库用户名
'password'=>'',//数据库密码
'prefix'=>'cmseasy_',//数据库表前缀
'encoding'=>'utf8',//编码
'type' => 'mysqli',//数据库类型
),

);