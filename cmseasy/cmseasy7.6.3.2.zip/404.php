<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>404</title>
</head>
<body>
<style type="text/css">

.copy {clear:both; text-align:center; margin-top:20px; font-size:12px;color:#666;}
.copy a {color:#666;}

</style>
<div class='tip_box' style='width:150px;margin:0px auto;margin-top:50px;padding:20px;border:5px solid #ccc;border-radius: 5px 5px 5px 5px;text-align:center;'>
404 Error !
<br />
<a href="/">返回首页</a>
</div>

</body>
</html>