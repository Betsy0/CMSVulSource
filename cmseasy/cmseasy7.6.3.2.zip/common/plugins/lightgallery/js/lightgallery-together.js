document.write('<script src="/common/plugins/lightgallery/js/lightgallery.min.js"></script>');
document.write('<script src="/common/plugins/lightgallery/js/lg-pager.min.js"></script>');
document.write('<script src="/common/plugins/lightgallery/js/lg-fullscreen.min.js"></script>');
document.write('<script src="/common/plugins/lightgallery/js/lg-zoom.min.js"></script>');
document.write('<script src="/common/plugins/lightgallery/js/lg-hash.min.js"></script>');

