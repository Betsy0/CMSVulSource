<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - config.php -
//
// Copyrights (c) 2006-2019 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//*****************************************************************//

// Table prefix
// if you change this after you have installed bloofoxCMS, you have to rename all mysql-tables manually.
// if you need to change this before installing -> do it, but it should end by "_" to have a better structure
// default: $tbl_prefix = "bfCMS_";
$tbl_prefix = "bfCMS_";

// Mysql class
// by default the path is set to the file class_mysql.php in folder /system.
// you could change it if you need to place the file class_mysqli.php e.g. outside the public www path
// default: $mysql_config_path = "system/class_mysqli.php";
$mysql_config_path = "system/class_mysqli.php";

?>