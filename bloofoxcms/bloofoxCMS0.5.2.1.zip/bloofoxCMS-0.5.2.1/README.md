## bloofoxCMS

bloofoxCMS is a free open source web content management system (CMS) written in PHP using MySQL.

# bloofoxCMS runs with a minimum of requirements: 

- Webserver or Webspace 
- PHP 4.1 or higher 
- MySQL-Database 4.x and higher 
- FTP-Account

# bloofoxCMS documentation

Visit www.bloofox.com for more information.
