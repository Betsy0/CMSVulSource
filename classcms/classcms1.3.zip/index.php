<?php
$GLOBALS['C']['AdminDir']='admin';
$GLOBALS['C']['Debug']=0;



require('class/cms/cms.php');
ClassCMS_init();