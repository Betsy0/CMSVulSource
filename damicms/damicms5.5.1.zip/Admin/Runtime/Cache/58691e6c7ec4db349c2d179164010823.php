<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>网站后台管理</title>
<link href="__PUBLIC__/Admin/images/Admin_css.css" type=text/css rel=stylesheet>
<link rel="shortcut icon" href="__PUBLIC__/Admin/images/myfav.ico" type="image/x-icon" />
<script type="text/javascript" src="/damicms/Public/Admin/setdate/WdatePicker.js"></script><script type="text/javascript" src="/damicms/Public/Admin/js/admin.js"></script><script type="text/javascript" src="/damicms/Public/Admin/js/Ajax.js"></script><script type="text/javascript" src="/damicms/Public/Admin/js/Jquery.js"></script> 
</head>
<body>
<div class="main_center">
<table width="95%" border="0"  align=center cellpadding="3" cellspacing="1" bgcolor="#F2F9E8" class="table table-bordered">
<tr> 
<td colspan="7" align=left class="admintitle">提现列表</td></tr>
    <tr bgcolor="#f1f3f5" style="font-weight:bold;">
    <td width="10%" height="30" align="center" class="ButtonList">编号</td>
    <td width="10%" align="center" class="ButtonList">用户名</td>
    <td width="25%" align="center" class="ButtonList">联系方式</td>
    <td width="25%" align="center" class="ButtonList">余额</td>
	<td width="5%" align="center" class="ButtonList">提现金额</td>
	<td width="10%" align="center" class="ButtonList">联系电话</td>
    <td width="15%" height="30" align="center" class="ButtonList">操作</td>      
    </tr>
	<?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr bgcolor="#ffffff" onMouseOver="this.style.backgroundColor='#EAFCD5';" onMouseOut="this.style.backgroundColor='';this.style.color=''">
    <td height="25"><?php echo ($vo["id"]); ?></td>
    <td height="25" align="center"><a href="<?php echo U('Member/showuser',array('id'=>$vo[uid]));?>"><?php echo ($vo["username"]); if(($vo["realname"]) != ""): ?>【<?php echo ($vo["realname"]); ?>】<?php endif; ?></a></td>
    <td align="center">电话:<?php echo ($vo["tel"]); ?>&nbsp;/qq:<?php echo ($vo["qq"]); ?>&nbsp;/email:<?php echo ($vo["email"]); ?></td>
    <td align="center"><?php echo ($vo["have_money"]); ?></td>
    <td height="25" align="center"><?php echo ($vo["money"]); ?></td>
	 <td height="25" align="center"><?php echo ($vo["tel"]); ?></td>
    <td align="center">
    <?php if(($vo["status"]) != "1"): ?><a class="btn btn-success btn-sm active" href="javascript:if(confirm('您确定该笔提现已做过处理?')){
location.href='<?php echo U('Member/dotixian',array('id'=>$vo[id]));?>';}">处理扣款</a>
<?php else: ?><font color="#003300">已处理</font><?php endif; ?>
      <a class="btn btn-danger btn-sm active" href="javascript:if(confirm('您确定删除吗?')){
location.href='<?php echo U('Member/deltixian',array('id'=>$vo[id]));?>';}">删除</a>
    </td>
    </tr><?php endforeach; endif; else: echo "" ;endif; ?>
	<tr><td bgcolor="f7f7f7" colspan="7" align="left"><ul class="pagination"><?php echo ($page); ?></ul></td></tr>
</table>
</div>
</body>
</html>