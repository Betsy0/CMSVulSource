<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>附件清理</title>
<link href="__PUBLIC__/Admin/images/Admin_css.css" type=text/css rel=stylesheet>
<link rel="shortcut icon" href="__PUBLIC__/Admin/images/myfav.ico" type="image/x-icon" />
</head>
<body>
 
<table border="0"  cellspacing="1" cellpadding="3" height="1" class="admintable1">
<tr>
<td class="admintitle">附件清理</td>
</tr><tr>
<td height=30 bgcolor="#FFFFFF" class="td"><br><br><b>注意：</b>请谨慎使用本功能，操作前最好先备份下上传文件夹，以免文件丢失。<br><br>
<br><br>系统幻灯片文件夹为：__PUBLIC__/Uploads/hd/  系统LOGO文件夹为：__PUBLIC__/Uploads/logo/ 友情链接LOGO文件夹为：__PUBLIC__/Uploads/link/
  <br /><br /><input type="button" value="幻灯清理" class="btn btn-info" onClick="if(confirm('确定要清除幻灯片中的垃圾文件?\n\n请谨慎操作！'))location.href='__URL__/clearhd';return false;" />
<input type="button" value="LOGO清理" class="btn btn-warning" onClick="if(confirm('确定要清除logo文件夹中的垃圾文件?\n\n请谨慎操作！'))location.href='__URL__/clearlogo';return false;" /> 
<input type="button" value="友链清理" class="btn btn-danger" onClick="if(confirm('确定要清除友情链接文件夹中的垃圾文件?\n\n请谨慎操作！'))location.href='__URL__/clearlink';return false;" /> 
<input type="button" value="缓存清理" class="btn" onClick="if(confirm('点击确定开始清理系统缓存'))location.href='__URL__/clearcache';return false;" /> 
 <br /><br /><br />
</td>
</tr>
</table>
  
</body>
</html>