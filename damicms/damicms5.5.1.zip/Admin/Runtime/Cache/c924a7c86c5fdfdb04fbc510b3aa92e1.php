<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="__PUBLIC__/Admin/images/style.css" rel="stylesheet" type="text/css" />
<title></title>
</head>
 
<body>
<div id="footer">CopyRight &copy; 2012-2022 大米CMS 版本 Ver <?php echo (C("VERSION")); ?> </div><!--#footer -->
</body>
</html>