<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>网站后台管理</title>
<link href="__PUBLIC__/Admin/images/Admin_css.css" type=text/css rel=stylesheet>
<link rel="shortcut icon" href="__PUBLIC__/Admin/images/myfav.ico" type="image/x-icon" />
<script type="text/javascript" src="/damicms/Public/Admin/setdate/WdatePicker.js"></script><script type="text/javascript" src="/damicms/Public/Admin/js/admin.js"></script><script type="text/javascript" src="/damicms/Public/Admin/js/Ajax.js"></script><script type="text/javascript" src="/damicms/Public/Admin/js/Jquery.js"></script> 
</head>
<body>
<table border="0" cellspacing="2" cellpadding="3"  align="center" class="admintable" style="width:98%;margin-bottom:5px;">
    <tr>
      <td width="6%" height="25" bgcolor="f7f7f7">快速查找：      </td>
      <td width="93%" align="left" valign="top" bgcolor="f7f7f7">
	  <form name="form1" method="POST" action="__URL__/cartlist">
	    日期从&nbsp;
	    <input name="start_time" type="text" id="start_time" value="" class="s26"  onClick="WdatePicker({dateFmt:'yyyy-MM-dd'})">&nbsp;到&nbsp;<input name="end_time" type="text" id="end_time" value="" class="s26"  onClick="WdatePicker({dateFmt:'yyyy-MM-dd'})">&nbsp;关键字:&nbsp;
        <input name="keyword" type="text" id="keyword" value="" class="s26">
        <input type="submit" class="btn btn-danger btn-sm" value="搜索">
      </form></td>
      <td width="1%" align="right" bgcolor="f7f7f7"></td>
    </tr>
</table>
<div class="main_center">
<table width="95%" border="0"  align=center cellpadding="3" cellspacing="1" bgcolor="#F2F9E8" class="table table-bordered">
<tr> 
<td colspan="6" align=left class="admintitle">订单列表(说明:本系统与淘宝交易状态自动同步的)</td></tr>
    <tr bgcolor="#f1f3f5" style="font-weight:bold;">
    <td width="10%" height="30" align="center" class="ButtonList">订单号</td>
    <td width="30%" align="center" class="ButtonList">产品名称/型号</td>
	<td width="5%" align="center" class="ButtonList">订购姓名</td>
	<td width="10%" align="center" class="ButtonList">价格</td>
    <td width="25%" height="25" align="center" class="ButtonList">送货信息</td>  
    <td width="20%" height="25" align="center" class="ButtonList">状态</td>      
    </tr>
	<?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr bgcolor="#ffffff" onMouseOver="this.style.backgroundColor='#EAFCD5';" onMouseOut="this.style.backgroundColor='';this.style.color=''">
    <td height="25"><?php echo ($vo["group_trade_no"]); ?></td>
    <td height="25" align="center"><a href="./index.php?s=/articles_<?php echo ($vo["gid"]); ?>.html" target="_blank" title="产品详细"><?php echo ($vo["title"]); ?>/<?php echo ($vo["servial"]); ?></a></td>
    <td height="25" align="center"><?php echo ($vo["sh_name"]); ?></td>
	 <td height="25" align="center"><?php echo ($vo["num"]); ?>件/合计:<?php echo ($vo[price]*$vo[num]); ?>元</td>
    <td align="left"><?php echo ($vo["province"]); echo ($vo["city"]); echo ($vo["area"]); ?><br><?php echo ($vo["address"]); ?></td>
    <td align="center">
    <?php $status_arr = C('TRADE_STATUS'); ?>
    <select class="trade_status" name="trade_status" rel="<?php echo ($vo["buy_id"]); ?>">
    <?php if(is_array($status_arr)): $z = 0; $__LIST__ = $status_arr;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$voo): $mod = ($z % 2 );++$z;?><option value="<?php echo ($z-1); ?>" <?php if(($vo[status]) == $z-1): ?>selected="selected"<?php endif; ?> ><?php echo ($voo); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
    </select>
    <a class="btn btn-danger btn-sm active" href="javascript:if(confirm('您确定删除吗?')){
location.href='<?php echo U('Member/deltrade',array('buyid'=>$vo[buy_id]));?>';}">删除</a>
    </td>
    </tr><?php endforeach; endif; else: echo "" ;endif; ?>
	<tr><td bgcolor="f7f7f7" colspan="6" align="left"><ul class="pagination"><?php echo ($page); ?></ul></td></tr>
</table>
<script>
$(function(){
$('.trade_status').each(function(){
$(this).change(function(){
	if(confirm('您确定交易状态将设置为:' + $(this).find("option:selected").text() )){
var status = $(this).val();
var buyid= $(this).attr('rel');
$.getJSON("__URL__/ajax_change_trade", {status: status,buyid:buyid}, function(json){
		alert(json.data);
});
	}	
	});	
});
});
</script>
</div>
</body>
</html>