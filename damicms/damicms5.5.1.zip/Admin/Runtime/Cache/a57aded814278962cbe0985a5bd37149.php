<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>QQ配置</title>
<link href="__PUBLIC__/Admin/images/Admin_css.css" type=text/css rel=stylesheet>
<script type="text/javascript" src="/damicms/Public/Admin/js/admin.js"></script><script type="text/javascript" src="/damicms/Public/Admin/js/Jquery.js"></script>
</head>
<body>
<script>
function chk(){
if (document.myform.Title.value==""){
	alert("请填写标题！");
	document.myform.Title.focus();
	return false;
  }
}
</script>
<table width="100%" border="0" align="center" cellpadding="3" cellspacing="2" bgcolor="#FFFFFF" class="admintable">
<tr> 
  <th colspan="5" class="admintitle">QQ快捷登陆设置
  </th></tr>
<form action="__URL__/doqqset" method="post" name="myform">
<tr>
  <td colspan="5" class=b1_1>说明：本系统集成的是QQ快捷登陆 使用申请：<a href="http://connect.qq.com/intro/login" target="_blank"><font color="#FF0000" style="font-size:16px;"><b>http://connect.qq.com/intro/login</b></font></a></td>
  </tr>
<tr>
  <td class=b1_1>您的APP ID：</td>
  <td colspan=4 class=b1_1><input name="qq_appid" value="<?php echo C('QQ_APPID');?>" type="text" id="Title2" size="40" maxlength="60"></td>
</tr>
<tr> 
  <td width="20%" class=b1_1>您的APP KEY：</td>
  <td colspan=4 class=b1_1><input name="qq_appkey" value="<?php echo C('QQ_APPKEY');?>" type="text" id="Title3" size="40" maxlength="60"></td>
</tr>
<tr> 
  <td width="20%" class=b1_1>是否开启QQ快捷登陆：</td>
  <td colspan=4 class=b1_1><input name="qq_login" type="radio" value="0" <?php if(C('QQ_LOGIN') == 0): ?>checked<?php endif; ?> />关闭<input name="qq_login" type="radio" value="1" <?php if(C('QQ_LOGIN') == 1): ?>checked<?php endif; ?>>开启</td>
</tr>
<tr> 
  <td width="20%" class=b1_1></td>
  <td class=b1_1 colspan=4><input name="submit" type="submit" class="btn btn-info" value="保存设置">&nbsp;&nbsp;<input type="button" onclick="history.go(-1);" class="btn btn-info" value="返 回"></td>
</tr></form>
</table>

</body>
</html>