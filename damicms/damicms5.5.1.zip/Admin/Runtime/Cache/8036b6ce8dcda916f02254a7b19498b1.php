<?php if (!defined('THINK_PATH')) exit();?><html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>大米CMS后台管理</title>
</head>

<frameset rows="81,*,26" cols="*" framespacing="0" frameborder="no" border="0">
  <frame src="__URL__/head" name="topFrame" scrolling="No" noresize="noresize" id="topFrame" />
  <frame src="__URL__/center" name="mainFrame" id="mainFrame" />
  <frame src="__URL__/bottom" name="botFrame" id="botFrame" />
</frameset>
<noframes>
<body>
</body>
</noframes>
</html>