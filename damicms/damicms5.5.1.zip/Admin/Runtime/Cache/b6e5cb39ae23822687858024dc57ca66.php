<?php if (!defined('THINK_PATH')) exit();?><html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title></title>
<link href="__PUBLIC__/Admin/images/style.css" rel="stylesheet" type="text/css" /><style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
body,td{font-size:12px;}
a{ text-decoration:none;color:#ffffff;font-weight:bold; }
.STYLE1 {
	color: #43860c;
	font-size: 12px;
}
.link { padding:10px 0 0 20px;}
-->
</style>
</head>

<body>
<div id="header">
 
    <div class="nav">       
       <div class="logo fleft"></div>
      	<ul>     
      <div class="nav-right fright"></div> <div class="nav-left fleft"></div>
            <li class="first"><a href="__APP__/Index/main" target="main">管理首页</a></li>
        	<li><a href="__APP__/Fields/index" target="main">扩展字段</a></li>
            <li><a href="__APP__/Type/index" target="main">栏目管理</a></li>
            <li><a href="__APP__/Article/index" target="main">内容管理</a></li>
            <li><a href="__APP__/Clear/clearcache" target="main">清理缓存</a></li>
            <li><a href="__APP__/Update/index" target="main">一键升级</a></li>
            <li><a href="__ROOT__/index.php" target="_blank">网站首页</a></li>
            <li ><a href="http://www.damicms.com" target="_blank">大米官网</a></li>       
        </ul> 
        <a class="logout" href="<?php echo U('Public/loginout');?>" target="_top"> </a>
    </div>
    </div>
</body>
</html>