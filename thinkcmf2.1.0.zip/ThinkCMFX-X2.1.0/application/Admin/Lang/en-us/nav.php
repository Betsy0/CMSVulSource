<?php
return array(
		"NAVIGATION_NAME" => 'Name',
		'ADD_SUB_NAV' => 'Add Sub Nav',
		"DISPLAY" => 'Display',
		"HIDDEN" => 'Hidden',
		"NAVIGATION_CATEGORY" => 'Navigation Category',
		"PARENT" => "Parent",
		"LABEL" => 'Label',
		"HREF" => 'Href',
		"TARGET" => 'Target',
		"TARGET_DEFAULT" => 'Default',
		"TARGET_BLANK" =>'New Window',
		"ICON" => 'Icon'
);