<?php
return array(
		"USERNAME" => '用户名',
		"NICENAME" => '昵称',
		"AVATAR" => '头像',
		"EMAIL" => '邮箱',
		"REGISTRATION_TIME" => '注册时间',
		"LAST_LOGIN_TIME" => "最后登录时间",
		"LAST_LOGIN_IP" => '最后登录IP',
		"STATUS" => '状态',
		"ACTIONS" => "操作",
		"USER_STATUS_BLOCKED" => '已拉黑',
		"USER_STATUS_ACTIVATED" => '正常',
		"USER_STATUS_UNVERIFIED" => '未验证',
		"BLOCK_USER" =>'拉黑',
		"BLOCK_USER_CONFIRM_MESSAGE" =>'您确定要拉黑此用户吗？',
		"ACTIVATE_USER" =>'启用',
		"ACTIVATE_USER_CONFIRM_MESSAGE" =>'您确定要启用此用户吗？',
		"THIRD_PARTY_USER" => "第三方用户",
		"NOT_FILLED" => "未填写"
		
);