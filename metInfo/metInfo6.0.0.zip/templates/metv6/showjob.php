<?php defined('IN_MET') or exit('No permission'); ?>
<include file="head.php" />
<include file="foot.php" />