define(function(require, exports, module) {

	var $ = require('jquery');
	var common = require('common');

	$(document).on('click',".html", function(){

	});

});
