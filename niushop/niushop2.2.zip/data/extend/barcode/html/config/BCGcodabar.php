<?php
$classFile = 'BCGcodabar.barcode.php';
$className = 'BCGcodabar';
$baseClassFile = 'BCGBarcode1D.php';
$codeVersion = '5.2.0';
?>