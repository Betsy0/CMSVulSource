<div id="copy">
<?php echo $info['bottominfo']?> 
<?php echo $info['tongji']?>
<?php echo $info['icp']?>
</div>