<?php
/**
 * Project: Catfish.
 * Author: A.J
 * Date: 2016/12/6
 */
return [
    'Announcement' => 'Ankündigung',
    'The Announcement Plugin displays a bulletin at the top of the Home page' => 'Mitteilung auf der homepage der top-plug-in können zeigt eine ankündigung',
    'Notice content' => 'Ankündigung',
    'Save' => 'Speichern'
];