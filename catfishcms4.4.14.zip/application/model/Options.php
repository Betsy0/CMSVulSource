<?php
/**
 * Project: Catfish.
 * Author: A.J
 * Date: 2016/10/9
 */
namespace app\model;

use think\Model;

class Options extends Model
{

}