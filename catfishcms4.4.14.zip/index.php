<?php
/**
 * Project: Catfish.
 * Author: A.J
 * Date: 2016/9/29
 */
// 定义应用目录
define('APP_PATH', __DIR__ . '/application/');
// 加载引导文件
require __DIR__ . '/catfish/start.php';