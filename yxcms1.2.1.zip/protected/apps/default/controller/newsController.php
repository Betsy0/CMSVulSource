<?php
class newsController extends commonController
{
	public $sorttype=1;//资讯栏目类型
	public function index()
	{
		$id=in($_GET['id']);
		if(empty($id)) throw new Exception('栏目ID不能为空~', 404);
		else{
			$sortinfo=model('sort')->find("id='{$id}'",'id,name,path,url,type,deep,method,tplist,keywords,description,extendid');
			if($this->sorttype!=$sortinfo['type']) throw new Exception('栏目不存在~', 404);
			$path=$sortinfo['path'].','.$sortinfo['id'];
			$deep=$sortinfo['deep']+1;
		}

		$listRows=empty($sortinfo['url'])?10:intval($sortinfo['url']);//每页显示的信息条数
        $where="(sort LIKE '{$path}%' OR exsort LIKE '%{$id}%') AND ispass='1'";

		$_GET['exsort']=in($_GET['exsort']);
		if(!empty($_GET['exsort'])){
            $_GET['exsort']=str_replace('i'.$id, '', $_GET['exsort']);
            $_GET['exsort']=str_replace($id.'i', '', $_GET['exsort']);
            $_GET['exsort']=str_replace($id, '', $_GET['exsort']);
            $exwhere=str_replace('i', '%', $_GET['exsort']);
            if(!empty($exwhere)){
            	$exwhere='%'.$exwhere.'%';
            	$where.=" AND exsort LIKE '{$exwhere}'";
            }
           $this->exsort=$_GET['exsort'];
		}
        $page=empty($page)?1:$page;
		$url=empty($_GET['exsort'])?url($sortinfo['method'],array('id'=>$id,'page'=>'{page}')):url($sortinfo['method'],array('id'=>$id,'page'=>'{page}','exsort'=>$_GET['exsort']));
	    $limit=$this->pageLimit($url,$listRows);
		$count=model('news')->count($where);
		if(empty($sortinfo['extendid']))
		    $list=model('news')->select($where,'id,title,color,sort,exsort,addtime,origin,hits,method,picture,keywords,description','recmd DESC,norder desc,id DESC',$limit);
		else {
			$exid=$sortinfo['extendid'];
			$extables=model('extend')->select("id='{$exid}' or pid='{$exid}'","tableinfo","pid,norder DESC");
			if(empty($extables)) throw new Exception('自定义字段信息不存在~', 404);
			$list=model('news')->newsANDextend($extables,$path,$limit,$id,$exwhere);
		}
		if(!empty($list)){
		   foreach ($list as $key=>$vo) {
			  $list[$key]['url']=Check::url($vo['method'])?$vo['method']:url($vo['method'],array('id'=>$vo['id']));
			  $list[$key]['sort']=substr($vo['sort'],-6);
			  $list[$key]['exsort']=explode(',', $vo['exsort']);
			  $list[$key]['picturepath']=$this->NewImgPath.$vo['picture'];
			  if(!empty($vo['keywords'])) $list[$key]['tags']=gettags($vo['keywords']);
		   }
		}
		$this->daohang=$this->crumbs($path);//面包屑导航
		$this->sortlist=$this->sortArray(0,$deep,$path);//子分类信息
		$this->alist=$list;
		$this->num=$count;
		$this->id=$id;
		$this->type=$this->sorttype;
		$this->page=$this->pageShow($count);
		$this->title=$sortinfo['name'].'-'.$this->title;//title标签
		if(!empty($sortinfo['keywords'])) $this->keywords=$sortinfo['keywords'];
		if(!empty($sortinfo['description'])) $this->description=$sortinfo['description'];
		$this->rootid=$this->getrootid($id);//根节点id
		$tp=explode(',', $sortinfo['tplist']);
		$this->display($tp[0]);
	}
        
	public function content()
	{
		$id=intval(in($_GET['id']));
		if(empty($id)) throw new Exception('内容ID不能为空~', 404);
		$info=model('news')->find("id='{$id}'");
		if(empty($info)) throw new Exception('内容不存在~', 404);
		if(!$info['ispass']) throw new Exception('内容未进审核~', 404);
        model('news')->update("id='$id'","hits=hits+1");//点击
        
		//文章分页
		$page = new Page();
		$url =url($info['method'],array('id'=>$id));
		$info['exsort']=explode(',', $info['exsort']);
		$info['content'] = $page->contentPage(html_out($info['content']), '<hr style="page-break-after:always;" class="ke-pagebreak" />',$url,10,4); //文章分页
		//获取拓展数据
		$sortid=substr($info['sort'],-6,6);
		$tabid=model('sort')->find("id='{$sortid}'",'extendid');//获取拓展表
		if($tabid['extendid']!=0 && !empty($tabid['extendid'])){
			$tab=model('extend')->select("id='{$tabid['extendid']}' OR pid='{$tabid['extendid']}'",'id,name,tableinfo,type','id');//获取拓展表名和字段
			if(!empty($tab[0]['tableinfo'])){
				$extdata=model('extend')->Extfind($tab[0]['tableinfo'],"id='{$info['extfield']}'");	
				$extinfo=array();
				for($i=1;$i<count($tab);$i++){
					$extinfo[$tab[$i]['id']]=array('name'=>$tab[$i]['name'],'value'=>$extdata[$tab[$i]['tableinfo']],'type'=>$tab[$i]['type']);
				}
				$this->extinfo=$extinfo;//拓展信息	
			}
		}
		//获取拓展数据结束
        $topsort=substr($info['sort'],0,14); //获取顶级类
		$upnews=model('news')->find("ispass='1'  AND id>'$id' AND sort like '{$topsort}%'",'id,title,method','id ASC');//上一篇
		$downnews=model('news')->find("ispass='1' AND id<'$id' AND sort like '{$topsort}%'",'id,title,method','id DESC');//下一篇
		$crumbs=$this->crumbs($info['sort']);//面包屑导航
		$lastCrumb=end($crumbs);
		$this->title=$info['title'].'-'.$lastCrumb['name'].'-'.$this->title;//title标题
		if(!empty($info['keywords'])) {
			$this->keywords=$info['keywords'];
			if(!empty($info['keywords'])) $info['tags']=gettags($info['keywords']);
		}
		if(!empty($info['description'])) $this->description=$info['description'];
		$this->daohang=$crumbs;//面包屑导航
		$this->info=$info;
		$this->rootid=substr($info['sort'],8,6);
		$this->downnews=$downnews;
		$this->upnews=$upnews;
		$this->display($info['tpcontent']);
	}
}