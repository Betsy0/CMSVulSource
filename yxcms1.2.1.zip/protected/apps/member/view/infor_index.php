<?php if(!defined('APP_NAME')) exit;?>
<div id="contain">
  <ul class="breadcrumb">
     <li> <span>账户管理</span><span class="divider">/</span><span>资料完善</span></li>
  </ul>
  <form method="post" action="">
        <table class="table table-bordered">
            <tr>
              <td align="right" width="100">昵称：</td>
              <td><input type="text" name="nickname" value="{$info['nickname']}"/></td>
            </tr>
            <tr>
              <td align="right"  width="100">Email：</td>
              <td><input type="text" name="email" value="{$info['email']}"/></td>
            </tr>
            <tr>
              <td align="right"  width="100">手机：</td>
              <td><input type="text" name="tel" value="{$info['tel']}"/></td>
            </tr>
            <tr>
              <td align="right"  width="100">QQ：</td>
              <td><input  type="text" name="qq" value="{$info['qq']}"/></td>
            </tr>
            <tr>
              <td colspan="2" align="center">
              <input type="hidden" name="id" value="{$info['id']}">
              <input type="submit" name="dosubmit" value="修改" class="btn btn-primary">
              </td>
            </tr>
        </table>
  </form>
</div>
