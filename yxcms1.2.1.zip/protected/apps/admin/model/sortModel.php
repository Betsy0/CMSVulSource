<?php
class sortModel extends baseModel{
	protected $table = 'sort';
}