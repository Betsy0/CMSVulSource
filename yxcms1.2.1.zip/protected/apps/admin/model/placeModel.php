<?php
class placeModel extends baseModel{
	protected $table = 'place';
}