<?php
class groupModel extends baseModel{
	protected $table = 'group';
}