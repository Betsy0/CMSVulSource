<?php
class linkModel extends baseModel{
	protected $table = 'link';
}