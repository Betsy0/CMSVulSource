<?php
/*
 * Copyright (C) 2018 www.wellcms.cn
 * intodb-uid-fid-password.html
*/
!defined('DEBUG') AND exit('Access Denied.');

if ($method != 'POST') message(1, lang('method_error'));

$uid = param(1, 0);
$user = user_read_cache($uid);
if (empty($uid) || empty($user)) exit(lang('user_not_exists'));
$gid = $user['gid'];

$fid = param(2, 0);
$forum = array_value($forumlist, $fid);
empty($forum) AND exit(lang('forum_not_exists'));

$password = param(3);
empty($password) AND exit(lang('password_incorrect'));

$check = (md5(md5($password) . $user['salt']) == $user['password']);
empty($check) AND exit(lang('password_incorrect'));

$r = forum_access_user($fid, $user['gid'], 'allowthread');
empty($r) AND exit(lang('user_group_insufficient_privilege'));

$subject = param('subject', '', FALSE);
empty($subject) ? exit(lang('please_input_subject')) : $subject = xn_html_safe(filter_all_html($subject));

xn_strlen($subject) > 128 AND exit(lang('subject_length_over_limit', array('maxlength' => 128)));
// 过滤标题 关键词

$link = param('link', 0);
$type = $link ? 10 : 0;

$closed = param('closed', 0);
$thumbnail = param('thumbnail', 0);
$delete_pic = param('delete_pic', 0);
$save_image = param('save_image', 0);
$brief_auto = param('brief_auto', 0);
$doctype = param('doctype', 0);
$doctype > 10 AND exit(lang('doc_type_not_supported'));

$message = $_message = '';
if ($link == 0) {
    $message = param('message', '', FALSE);
    empty($message) ? exit(lang('please_input_message')) : xn_strlen($message) > 2028000 AND exit(lang('message_too_long'));
    $_message = filter_all_html($message);
}

$brief = param('brief');
if ($brief) {
    $brief = xn_html_safe(filter_all_html($brief));
    xn_strlen($brief) > 120 AND $brief = xn_substr($brief, 0, 120);
} else {
    $brief = ($brief_auto AND $_message) ? xn_html_safe(xn_substr($_message, 0, 120)) : '';
}

$keyword = param('keyword');
$keyword = xn_html_safe(filter_all_html($keyword));
// 超出则截取
xn_strlen($keyword) > 64 AND $keyword = xn_substr($keyword, 0, 64);

$description = param('description');
$description = xn_html_safe(filter_all_html($description));
// 超出则截取
xn_strlen($description) > 120 AND $description = xn_substr($description, 0, 120);

$tags = param('tags', '', FALSE);
$tags = xn_html_safe(filter_all_html(trim($tags, ',')));

// 首页flag
$flag_index_arr = array_filter(param('index', array()));
// 频道flag
$flag_cate_arr = array_filter(param('category', array()));
// 栏目flag
$flag_forum_arr = array_filter(param('forum', array()));
// 统计主题绑定flag数量
$flags = count($flag_index_arr) + count($flag_cate_arr) + count($flag_forum_arr);

$thread = array(
    'fid' => $fid,
    'type' => $type,
    'doctype' => $doctype,
    'subject' => $subject,
    'brief' => $brief,
    'keyword' => $keyword,
    'description' => $description,
    'closed' => $closed,
    'flags' => $flags,
    'thumbnail' => $thumbnail,
    'save_image' => $save_image,
    'delete_pic' => $delete_pic,
    'message' => $message
);

$tid = well_thread_create($thread);
$tid === FALSE AND exit(lang('create_failed'));
unset($thread);

$tag_json = well_tag_post($tid, $fid, $tags);
well_thread_update($tid, array('tag' => $tag_json)) === FALSE AND exit(lang('create_failed'));

// 首页flag
!empty($flag_index_arr) AND flag_create_thread(0, 1, $tid, $flag_index_arr) === FALSE AND exit(lang('create_failed'));

// 频道flag
$forum['fup'] AND !empty($flag_cate_arr) AND flag_create_thread($forum['fup'], 2, $tid, $flag_cate_arr) === FALSE AND exit(lang('create_failed'));

// 栏目flag
!empty($flag_forum_arr) AND flag_create_thread($fid, 3, $tid, $flag_forum_arr) === FALSE AND exit(lang('create_failed'));

exit(lang('create_successfully'));

?>