<?php
/*
 * Copyright (C) 2018 www.wellcms.cn
*/
!defined('DEBUG') AND exit('Access Denied.');
// tag

$action = param(1);

// hook tag__start.php

if ($action == 'list') {

    // hook tag__list_start.php

    $page = param(2, 1);
    $extra = array(); // 插件预留

    // hook tag__list_before.php

    $arrlist = $count ? well_tag_find($page, $conf['pagesize']) : NULL;

    // hook tag__list_middle.php

    $count = well_tag_count();
    $threads = $count > $conf['pagesize'] * 100 ? $conf['pagesize'] * 100 : $count;

    $pagination = pagination(tag_list_url($extra), $threads, $page, $conf['pagesize']);

    // hook tag__list_after.php

    $header['title'] = lang('well_tag') . '-' . $conf['sitename'];
    $header['mobile_title'] = '';
    $header['mobile_link'] = tag_list_url($extra);
    $header['keywords'] = lang('well_tag') . '-' . $conf['sitename'];
    $header['description'] = lang('well_tag') . '-' . $conf['sitename'];
    $_SESSION['fid'] = 0;

    // hook tag__list_end.php

    if ($ajax) {
        $conf['api_on'] ? message(0, $arrlist) : message(0, lang('closed'));
    } else {
        include _include(style_load(4));
    }

} else {

    // tag-tagid-page.htm
    $tagid = param(1, 0);
    empty($tagid) AND message(-1, lang('data_malformation'));

    $page = param(2, 1);
    $extra = array(); // 插件预留

    // hook tag__before.php

    $read = well_tag_read_by_tagid_cache($tagid);
    empty($read) AND message(-1, lang('well_tag_not_existed'));

    // hook tag__center.php

    $arr = well_tag_thread_find($tagid, $page, $conf['pagesize']);
    if ($arr) {
        $tidarr = arrlist_values($arr, 'tid');
        $threadlist = well_thread_find($tidarr, $conf['pagesize']);
    } else {
        $threadlist = NULL;
    }

    // hook tag__middle.php

    $count = well_tag_count();
    $threads = $read['count'] > $conf['pagesize'] * $conf['listsize'] ? $conf['pagesize'] * $conf['listsize'] : $read['count'];

    $pagination = pagination(tag_url($tagid, TRUE, $extra), $threads, $page, $conf['pagesize']);

    // hook tag__after.php

    $header['title'] = empty($read['title']) ? $read['name'] . lang('well_tag') . '-' . $conf['sitename'] : $read['title'];
    $header['mobile_title'] = '';
    $header['mobile_link'] = url('tag-list', $extra);
    $header['keywords'] = empty($read['keywords']) ? $read['name'] : $read['keywords'];
    $header['description'] = empty($read['description']) ? $read['name'] : $read['description'];
    $_SESSION['fid'] = 0;

    // hook tag__end.php

    if ($ajax) {
        $conf['api_on'] ? message(0, array('tag' => $read, 'thread' => $threadlist)) : message(0, lang('closed'));
    } else {
        include _include(style_load(5, $tagid));
    }
}

?>