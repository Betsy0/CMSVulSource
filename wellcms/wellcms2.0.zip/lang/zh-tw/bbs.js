var lang = {
	'warning': '警告',
	'tips_title': '提示：',
	'confirm': '確定',
	'confirm_title': '請確認以下信息：',
	'confirm_delete': '確定刪除嗎？',
	'close': '關閉',
	'yes': '是',
	'no': '否',
	'open': '打開',
	'close': '關閉',
	
	// hook lang_zh_tw_bbs_js.htm
};