<?php

!defined('DEBUG') AND exit('Access Denied.');

group_access($gid, 'manageother') == FALSE AND message(1, lang('user_group_insufficient_privilege'));

$action = param(1, 'cache');

// hook admin_other_start.php

if ($action == 'cache') {

    // hook admin_other_cache_get_post.php

    if ($method == 'GET') {

        // hook admin_other_cache_get_start.php

        $input = array();
        $input['clear_tmp'] = form_checkbox('clear_tmp', 1);
        $input['clear_cache'] = form_checkbox('clear_cache', 1);

        // hook admin_other_cache_get_end.php

        $header['title'] = lang('admin_clear_cache');
        $header['mobile_title'] = lang('admin_clear_cache');
        $header['mobile_link'] = url('other-cache');

        include _include(ADMIN_PATH . 'view/htm/other_cache.htm');

    } else {

        // hook admin_other_cache_post_start.php

        $clear_tmp = param('clear_tmp');
        $clear_cache = param('clear_cache');

        $clear_cache AND cache_truncate();
        $clear_cache AND $runtime = NULL; // 清空
        kv_cache_set('website', NULL);

        $clear_tmp AND rmdir_recusive($conf['tmp_path'], 1);

        // hook admin_other_cache_post_end.php

        message(0, lang('admin_clear_successfully'));
    }
} elseif ($action == 'map') {

    // hook admin_other_map_start.php

    $setting = array_value($config, 'setting');

    if ($method == 'GET') {

        $header['title'] = lang('map');
        $header['mobile_title'] = lang('map');
        $header['mobile_link'] = url('other-map');

        // hook admin_other_map_get_start.php

        // 1生成地图
        $type = param('type', 0);

        if ($type == 1) {

            // hook admin_other_map_xml_start.php

            !file_exists(array_value($setting, 'map', 'sitemap')) AND xn_mkdir(APP_PATH . array_value($setting, 'map', 'sitemap'), 0777);

            $page = param('page', 0); // 当前页数
            $n = param('n', 0); // 总页数
            $pagesize = 40000;
            $fids = param('fids');
            $fid = param('fid', 0);

            $forum_xml = $xml = '';
            $lastmod = date('Y-m-d');

            // hook admin_other_map_xml_before.php

            $dir = array_value($setting, 'map', 'sitemap') . '/';

            // hook admin_other_map_xml_middle.php

            $forumlist_show = category_list($forumlist);

            // hook admin_other_map_xml_after.php

            if (!empty($forumlist_show) && !$fids) {
                // 生成栏目索引

                $fids = '';
                foreach ($forumlist_show as $_forum) {

                    if (!$_forum['threads']) continue;

                    $fids .= $_forum['fid'] . '|';

                    $n = ceil($_forum['threads'] / $pagesize);

                    //--------------生成栏目索引---------------
                    for ($i = 0; $i < $n; ++$i) {
                        $forum_xml .= '    <loc>' . url_prefix() . '/' . $dir . 'forum-' . $_forum['fid'] . '-' . $i . '.xml</loc>
    <lastmod>' . $lastmod . '</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.8</priority>' . "\r\n";
                    }

                    if ($forum_xml) {
                        $forum_xml = trim($forum_xml, "\r\n");
                        $forum_map = <<<EOT
<?xml version="1.0" encoding="utf-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
<sitemapindex>
    <sitemap>
{$forum_xml}
    </sitemap>
</sitemapindex>
</urlset>
EOT;

                        file_put_contents_try(APP_PATH . $setting['map'] . '/index.xml', $forum_map);
                    }
                }

                $thread = rtrim($fids, '|');

                message(0, jump('Create a section index', url('other-map', array('type' => 1, 'fids' => rtrim($fids, '|'))), 1));

            } else {

                $fidarr = explode('|', $fids);
                empty($fid) AND $fid = $fidarr[0];

                // 按照栏目生成内容索引 可以创建已生成标识，不用重复生成旧数据，VIP版再添加吧

                $forum = $forumlist_show[$fid];
                empty($n) AND $n = ceil($forum['threads'] / $pagesize);

                $arrlist = thread_tid_find_by_fid($fid, $page, $pagesize, FALSE);

                foreach ($arrlist as $_thread) {
                    $xml .= '    <url>
        <loc>' . url_prefix() . '/' . well_url_format($fid, $_thread['tid']) . '</loc>
        <mobile:mobile type="pc,mobile"/>
        <lastmod>' . $lastmod . '</lastmod>
        <changefreq>daily</changefreq>
        <priority>0.8</priority>
    </url>' . "\r\n";
                }

                if ($xml) {
                    $xml = trim($xml, "\r\n");
                    $map = <<<EOT
<?xml version="1.0" encoding="utf-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
{$xml}
</urlset>
EOT;

                    file_put_contents_try(APP_PATH . $setting['map'] . '/forum-' . $fid . '-' . $page . '.xml', $map);
                }

                $page += 1;
                if ($page == $n) {
                    $page = 0;
                    $fid = array_value($fidarr, 1, 0);
                    $n = 0;
                    unset($fidarr[0]);

                    $fidarr = array_filter($fidarr);
                    empty($fidarr) AND message(0, jump('Complete', url('other-map'), 2));
                }
                $fids = implode('|', $fidarr);

                message(0, jump('Forum : ' . $forum['name'] . ' Number : ' . ($page + 1), url('other-map', array('type' => 1, 'fid' => $fid, 'fids' => $fids, 'n' => $n, 'page' => $page)), 1));

            }

            // hook admin_other_map_xml_end.php

        } else {

            $input = array();
            $input['map'] = form_text('map', array_value($setting, 'map', 'sitemap'), FALSE, lang('setting_map_tips'));

            // hook admin_other_map_get_before.php

            $arr = array();
            if (array_value($setting, 'map')) {
                foreach (glob('../' . array_value($setting, 'map') . '/' . '*.*') as $file) {
                    $arr[] = url_prefix() . '/' . str_replace('../', '', $file);
                }
            }
        }

        // hook admin_other_map_get_end.php

        include _include(ADMIN_PATH . 'view/htm/other_map.htm');

    } elseif ($method == 'POST') {

        // hook admin_other_map_post_start.php

        $map = param('map', '', FALSE);
        // 英文 数字 下划线及三种组合 不支持其他字符
        !preg_match('/^[a-z\d_]*$/i', $map) AND message(1, lang('english_number_tips'));

        // hook admin_other_map_post_before.php

        $setting['map'] = $map;

        // hook admin_other_map_post_middle.php

        $config['setting'] = $setting;

        // hook admin_other_map_post_after.php

        setting_set('conf', $config);

        // hook admin_other_map_post_end.php

        message(0, lang('save_successfully'));
    }

} elseif ($action == 'increase') {

    $installed = array_value($config, 'installed');

    $type = param('type', 0);

    if ($method == 'GET') {

        $page = param('page', 0);
        $page += 1;
        $n = param('n', 0);
        $fid = param('fid', 0);
        $tid = param('tid', 0);

        if ($n == 1) {
            $count = 250;
        } elseif ($n == 2) {
            $count = 500;
        } elseif ($n == 3) {
            $count = 2500;
        } elseif ($n == 4) {
            $count = 5000;
        } else {
            $count = 50;
        }

        if ($type == 1 && $page <= $count) {

            empty($fid) AND message(0, jump('No section', url('other-increase'), 1));

            // 投入正常运营的站点不能灌水
            $runtime['articles'] AND $installed == 0 AND message(0, lang('create_failed'));

            if (empty($tid)) {
                $tid = well_thread_maxid();
                $tid += 1;
            }

            $number = $tid + 20000;
            $subject = 'WellCMS X 性能测试';
            $message = 'WellCMS X 性能测试';
            $thread = $thread_tid = $data = '';
            for ($tid; $tid < $number; ++$tid) {
                $thread .= '(' . $tid . ',' . $fid . ',"' . $subject . '",' . $uid . ',' . $time . '),';
                $thread_tid .= '(' . $tid . ',' . $fid . ',' . $uid . '),';
                $data .= '(' . $tid . ',"' . $message . '"),';
            }

            $thread = rtrim($thread, ',');
            $r = db_exec("REPLACE INTO `{$db->tablepre}website_thread` (`tid`,`fid`,`subject`,`uid`,`create_date`) VALUES $thread");
            $r === FALSE AND message(-1, 'Create thread error');

            $thread_tid = rtrim($thread_tid, ',');
            db_exec("REPLACE INTO `{$db->tablepre}website_thread_tid` (`tid`,`fid`,`uid`) VALUES $thread_tid") === FALSE AND message(-1, 'Create thread tid error');

            $data = rtrim($data, ',');
            db_exec("REPLACE INTO `{$db->tablepre}website_data` (`tid`,`message`) VALUES $data") === FALSE AND message(-1, 'Create data error');

            forum_update($fid, array('threads+' => 20000));
            user_update($uid, array('articles+' => 20000));

            // 灌水标识
            if ($installed == 0) {
                $config['installed'] = 1;
                setting_set('conf', $config);
            }

            message(0, jump('Number : ' . $page . '<br><br>threads : ' . ($page * 20000), url('other-increase', array('type' => 1, 'fid' => $fid, 'n' => $n, 'tid' => $tid, 'page' => $page)), 1));

        } else {
            $columnlist = category_list($forumlist);
        }

        $header['title'] = lang('increase_thread');
        $header['mobile_title'] = lang('increase_thread');
        $header['mobile_link'] = url('other-increase');

        include _include(ADMIN_PATH . 'view/htm/other_increase.htm');

    } elseif ($method == 'POST') {

        if ($type == 1) {

            db_exec("TRUNCATE  `{$db->tablepre}website_thread`");
            db_exec("TRUNCATE  `{$db->tablepre}website_thread_tid`");
            db_exec("TRUNCATE  `{$db->tablepre}website_data`");
            db_exec("TRUNCATE  `{$db->tablepre}website_attach`");
            db_exec("TRUNCATE  `{$db->tablepre}website_flag`");
            db_exec("TRUNCATE  `{$db->tablepre}website_flag_thread`");
            db_exec("TRUNCATE  `{$db->tablepre}website_tag`");
            db_exec("TRUNCATE  `{$db->tablepre}website_tag_thread`");
            db_exec("TRUNCATE  `{$db->tablepre}website_operate`");
            db_exec("TRUNCATE  `{$db->tablepre}website_comment`");
            db_exec("TRUNCATE  `{$db->tablepre}website_comment_pid`");
            db_exec("TRUNCATE  `{$db->tablepre}website_thread_sticky`");

            cache_truncate();
            kv_cache_set('website', NULL);

            $n = user_count();
            $arrlist = user_find(array(), array(), 1, $n);
            $uids = array();
            foreach ($arrlist as $val) {
                $uids[] = $val['uid'];
            }
            user__update($uids, array('articles' => 0, 'comments' => 0));
            unset($arrlist);

            $fids = array();
            foreach ($forumlist as $val) {
                $fids[] = $val['fid'];
            }

            forum_update($fids, array('threads' => 0));

            // 灌水标识
            if ($installed == 1) {
                $config['installed'] = 0;
                setting_set('conf', $config);
            }
        }

        message(0, lang('delete_successfully'));
    }
} elseif ($action == 'optimize') {
    // 作废 海量数据下会超时
    if ($method == 'GET') {

        // hook admin_other_optimize_get_start.php

        $input = array();
        $input['optimize'] = form_checkbox('optimize', 1);

        // hook admin_other_optimize_get_before.php

        $header['title'] = lang('optimize_table');
        $header['mobile_title'] = lang('optimize_table');
        $header['mobile_link'] = url('system-optimize');

        // hook admin_other_optimize_get_end.php

        include _include(ADMIN_PATH . 'view/htm/other_optimize.htm');

    } else {

        // hook admin_other_optimize_post_start.php

        $optimize = param('optimize');

        // hook admin_other_optimize_post_before.php

        $optimize AND db_sql_find_one("OPTIMIZE TABLE `{$db->tablepre}cache`, `{$db->tablepre}forum`, `{$db->tablepre}forum_access`, `{$db->tablepre}group`, `{$db->tablepre}kv`, `{$db->tablepre}session`, `{$db->tablepre}session_data`, `{$db->tablepre}user`, `{$db->tablepre}website_attach`, `{$db->tablepre}website_data`, `{$db->tablepre}website_flag`, `{$db->tablepre}website_flag_thread`, `{$db->tablepre}website_modelog`, `{$db->tablepre}website_comment`, `{$db->tablepre}website_comment_pid`, `{$db->tablepre}website_thread`, `{$db->tablepre}website_thread_tid`, `{$db->tablepre}website_thread_sticky`, `{$db->tablepre}website_tag`, `{$db->tablepre}website_tag_thread`");

        // hook admin_other_optimize_post_end.php

        message(0, lang('admin_clear_successfully'));
    }
} elseif ($action == 'link') {

    if ($method == 'GET') {

        // hook admin_other_link_get_start.php

        $page = param(2, 1);
        $pagesize = 20;

        $input = array();
        $input['name'] = form_text('name', '', $width = FALSE, lang('website_name'));
        $input['url'] = form_text('url', '', $width = FALSE, lang('website_url'));

        // hook admin_other_link_get_before.php

        $n = link_count();
        $arrlist = link_get($page, $n);

        // hook admin_other_link_get_after.php

        $pagination = pagination(url('other-link-{page}'), $n, $page, $pagesize);

        $header['title'] = lang('friends_link');
        $header['mobile_title'] = lang('friends_link');
        $header['mobile_link'] = url('other-link');

        // hook admin_other_link_get_end.php

        include _include(ADMIN_PATH . 'view/htm/other_link.htm');

    } elseif ($method == 'POST') {

        $type = param('type', 0);

        if ($type == 1) {
            $name = param('name', '', FALSE);
            $name = filter_all_html($name);
            $name = xn_html_safe($name);

            $url = param('url', '', FALSE);
            $url = filter_all_html($url);
            $url = xn_html_safe($url);

            link_create(array('name' => $name, 'url' => $url, 'create_date' => $time)) === FALSE AND message(-1, lang('create_failed'));

            message(0, lang('create_successfully'));

        } elseif ($type == 2) {
            // 排序
            $arr = _POST('data');

            empty($arr) && message(1, lang('data_is_empty'));

            foreach ($arr as &$val) {
                $rank = intval($val['rank']);
                $id = intval($val['id']);
                intval($val['oldrank']) != $rank && $id && link_update($id, array('rank' => $rank));
            }

            message(0, lang('update_successfully'));

        } else {

            $id = param('2', 0);
            link_delete($id) === FALSE AND message(-1, lang('delete_failed'));

            message(0, lang('delete_successfully'));
        }
    }
}

// hook admin_other_end.php

?>