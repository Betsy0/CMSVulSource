<?php
!defined('DEBUG') AND exit('Access Denied.');

//include XIUNOPHP_PATH . 'xn_zip.func.php';

$action = param(1);

// 初始化风格变量 / init style var
style_init();

empty($action) AND $action = 'local';

if ($action == 'local') {

    if ($method == 'GET') {

        $pagination = '';
        $pugin_cate_html = '';

        $header['title'] = lang('local') . lang('plugin');
        $header['mobile_title'] = lang('local') . lang('plugin');

        include _include(ADMIN_PATH . "view/htm/style_list.htm");

    } elseif ($method == 'POST') {

        group_access($gid, 'manageplugin') == FALSE AND message(1, lang('user_group_insufficient_privilege'));

        $dir = param(2, '', FALSE);
        $type = param(3, 0);

        empty($dir)AND message(1, lang('data_malformation'));

        if ($type) {

            $config['style'] AND style_uninstall($config['style']);

            $config['style'] != $dir AND style_install($dir);

            plugin_clear_tmp_dir();

            message(0, lang('install_successfully'));

        } else {

            $config['style'] == $dir AND style_uninstall($config['style']);

            plugin_clear_tmp_dir();

            message(0, lang('uninstall_successfully'));
        }
    }
}

?>