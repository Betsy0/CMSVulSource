<?php
/*
 * Copyright (C) 2018 www.wellcms.cn
 */
return array(
    // hook admin_menu_conf_start.php
    'content' => array(
        'url' => url('content-list'),
        'text' => lang('manage') . lang('content'),
        'icon' => 'icon-pencil-square',
        'tab' => array(
            // hook admin_menu_conf_content_start.php
            'content' => array('url' => url('content-list'), 'text' => lang('content') . lang('list')),
            // hook admin_menu_conf_content_before.php
            'sticky' => array('url' => url('sticky-list'), 'text' => lang('sticky') . lang('list')),
            // hook admin_menu_conf_content_center.php
            'comment' => array('url' => url('comment-list'), 'text' => lang('comment') . lang('list')),
            // hook admin_menu_conf_content_after.php
            'page' => array('url' => url('page-list'), 'text' => lang('single_page') . lang('list')),
            /*审核主题插在此处*/
            // hook admin_menu_conf_content_end.php
        )
    ),
    // hook admin_menu_conf_column_before.php
    'forum' => array(
        'url' => url('column-list'),
        'text' => lang('manage') . lang('forum'),
        'icon' => 'icon-columns',
        'tab' => array(
            // hook admin_menu_conf_column_start.php
            'website' => array('url' => url('column-list'), 'text' => lang('website')),
            // hook admin_menu_conf_column_end.php
        )
    ),
    // hook admin_menu_conf_category_before.php
    'category' => array(
        'url' => url('column-list'),
        'text' => lang('manage') . lang('category'),
        'icon' => 'icon-sort-alpha-asc',
        'tab' => array(
            // hook admin_menu_conf_category_start.php
            'flag' => array('url' => url('flag-list'), 'text' => lang('customize')),
            // hook admin_menu_conf_category_center.php
            //'tag' => array('url' => url('tag-list'), 'text' => lang('tag')),
            // hook admin_menu_conf_category_end.php
        )
    ),
    // hook admin_menu_conf_user_before.php
    'user' => array(
        'url' => url('user-list'),
        'text' => lang('manage') . lang('user'),
        'icon' => 'icon-user',
        'tab' => array(
            // hook admin_menu_conf_user_start.php
            'list' => array('url' => url('user-list'), 'text' => lang('user') . lang('list')),
            // hook admin_menu_conf_user_center.php
            'group' => array('url' => url('group-list'), 'text' => lang('admin_user_group')),
            // hook admin_menu_conf_user_after.php
            'create' => array('url' => url('user-create'), 'text' => lang('admin_user_create')),
            // hook admin_menu_conf_user_end.php
        )
    ),
    // hook admin_menu_conf_plugin_before.php
    'plugin' => array(
        'url' => url('plugin'),
        'text' => lang('manage') . lang('plugin'),
        'icon' => 'icon-cogs',
        'tab' => array(
            // hook admin_menu_conf_plugin_local_before.php
            'plugin' => array('url' => url('plugin-local'), 'text' => lang('local') . lang('plugin')),
            // hook admin_menu_conf_plugin_local_after.php
            'style' => array('url' => url('style-local'), 'text' => lang('local') . lang('style')),
            // hook admin_menu_conf_style_local_after.php
        )
    ),
    // hook admin_menu_conf_other_before.php
    'other' => array(
        'url' => url('other'),
        'text' => lang('other') . lang('function'),
        'icon' => 'icon-wrench',
        'tab' => array(
            // hook admin_menu_conf_other_map_before.php
            'map' => array('url' => url('other-map'), 'text' => lang('map')),
            // hook admin_menu_conf_other_increase_before.php
            'increase' => array('url' => url('other-increase'), 'text' => lang('increase_thread')),
            // hook admin_menu_conf_other_chain_before.php
            'link' => array('url' => url('other-link'), 'text' => lang('friends__link')),
            // hook admin_menu_conf_other_cache_before.php
            'cache' => array('url' => url('other-cache'), 'text' => lang('cache')),
            // hook admin_menu_conf_other_cache_after.php
            /*'optimize' => array('url' => url('other-optimize'), 'text' => lang('optimize_table')),*/
            // hook admin_menu_conf_other_after.php
        )
    ),
    // hook admin_menu_conf_setting_before.php
    'setting' => array(
        'url' => url('setting-base'),
        'text' => lang('system').lang('setting'),
        'icon' => 'icon-cog',
        'tab' => array(
            // hook admin_menu_conf_setting_base_before.php
            'website' => array('url' => url('setting-website'), 'text' => lang('admin_site_setting')),
            // hook admin_menu_conf_setting_base_after.php
            'base' => array('url' => url('setting-base'), 'text' => lang('admin_setting_base')),
            // hook admin_menu_conf_setting_system_after.php
            'smtp' => array('url' => url('setting-smtp'), 'text' => lang('admin_setting_smtp')),
            // hook admin_menu_conf_setting_smtp_after.php
        )
    ),
    // hook admin_menu_conf_end.php
);

?>