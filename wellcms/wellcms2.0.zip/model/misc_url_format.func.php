<?php
/*
 * Copyright (C) 2018 www.wellcms.cn
 */

// hook model_format_start.php

// 导航 格式化URL
function well_nav_format($forum, $extra = array())
{
    // hook model_nav_format_start.php
    if ($forum['type']) {
        // hook model_nav_format_before.php
        if ($forum['category'] == 0) {
            // 根据模型 返回列表URL
            // hook model_nav_format_list_before.php
            $url = well_nav_list_format($forum, FALSE, $extra);
            // hook model_nav_format_list_after.php
        } elseif ($forum['category'] == 1) {
            // 频道
            // hook model_nav_format_category_before.php
            $url = url('category-' . $forum['fid'], $extra);
            // hook model_nav_format_category_after.php
        } elseif ($forum['category'] == 2) {
            // 频道
            // hook model_nav_format_category_before.php
            $url = url('read-' . trim($forum['brief']), $extra);
            // hook model_nav_format_category_after.php
        }
        // hook model_nav_format_after.php
    } else {
        // hook model_nav_format_forum_before.php
        $url = url('forum-' . $forum['fid'], $extra);
        // hook model_nav_format_forum_after.php
    }
    // hook model_nav_format_end.php
    return $url;
}

// 区分
function well_nav_list_format($forum, $page = FALSE, $extra = array())
{
    // hook model_nav_list_format_start.php
    // 自己可以根据需要按照model区分路径
    $page = $page === TRUE ? '-{page}' : '';
    $url = url('list-' . $forum['fid'] . $page, $extra);
    /*if ($forum['model'] == 0) {
        $url = url('list-' . $forum['fid']);
    }*/
    // hook model_nav_list_format_end.php
    return $url;
}

// 单独导航URL
function well_nav_url($fid, $page = FALSE, $extra = array())
{
    global $forumlist;
    $forum = array_value($forumlist, $fid);
    if (empty($forum)) return '';

    // hook model_nav_format_start.php
    if ($forum['type']) {
        // hook model_nav_format_before.php
        if ($forum['category'] == 1) {
            // 频道
            // hook model_nav_format_category_before.php
            $page = $page === TRUE ? '-{page}' : '';
            $url = url('category-' . $forum['fid'] . $page, $extra);
            // hook model_nav_format_category_after.php
        } else {
            // 根据模型 返回列表URL
            // hook model_nav_format_list_before.php
            $url = well_nav_list_format($forum, $page, $extra);
            // hook model_nav_format_list_after.php
        }
        // hook model_nav_format_after.php
    } else {
        // hook model_nav_format_forum_before.php
        $url = url('forum-' . $forum['fid'], $extra);
        // hook model_nav_format_forum_after.php
    }
    // hook model_nav_format_end.php
    return $url;
}

function flag_url($flagid, $page = FALSE, $extra = array())
{
    $page = $page ? '-{page}' : '';
    // hook model_flag_url_format_start.php
    $url = url('flag-' . $flagid . $page, $extra);
    // hook model_flag_url_format_end.php
    return $url;
}

function flag_list_url($extra = array())
{
    // hook model_flag_list_url_format_start.php
    $url = url('flag-list-{page}', $extra);
    // hook model_flag_list_url_format_end.php
    return $url;
}

function tag_url($tagid, $page = FALSE, $extra = array())
{
    $page = $page === TRUE ? '-{page}' : '';
    // hook model_tag_url_format_start.php
    $url = url('tag-' . $tagid . $page, $extra);
    // hook model_tag_url_format_end.php
    return $url;
}

function tag_list_url($extra = array())
{
    // hook model_tag_list_url_format_start.php
    $url = url('tag-list-{page}', $extra);
    // hook model_tag_list_url_format_end.php
    return $url;
}

// 格式化主题URL
function well_thread_url_format(&$threadlist)
{
    // hook model_thread_url_format_start.php
    foreach ($threadlist as &$_thread) {
        $_thread['url'] = well_url_format($_thread['fid'], $_thread['tid']);
        // hook model_thread_url_format_after.php
    }
    // hook model_thread_url_format_end.php
}

// 一 格式化 URL 根据fid查询别名 xx/tid-{page}.htm
function well_url_format($fid, $tid, $page = FALSE, $extra = array())
{
    global $forumlist;
    // hook model_url_format_start.php
    if (empty($forumlist[$fid])) return url('read-' . $tid, $extra);
    // hook model_url_format_before.php
    $forum = $forumlist[$fid];
    $page = $page === TRUE ? '-{page}' : '';
    // hook model_url_format_after.php
    if ($forum['type']) {
        // CMS
        // hook model_url_format_model_start.php
        // 自己可以根据需要按照model区分路径
        $url = url('read-' . $tid . $page, $extra);
        /*if ($forum['model'] == 0) {
            $url = url('read-' . $tid . $page);
        }*/
        // hook model_url_format_model_end.php
    } else {
        // BBS
        // hook model_url_format_thread_before.php
        $url = url('thread-' . $tid . $page, $extra);
        // hook model_url_format_thread_after.php
    }
    // hook model_url_format_end.php
    return $url;
}

// 二 格式化 URL 别名 well_alia
function well_url_alias($forum, $tid, $extra = array())
{
    // hook model_url_alias_start.php
    $url = url('read-' . $tid, $extra);
    // hook model_url_alias_end.php
    return $url;
}

/*// 分页数控制为100
function page_control($threads, $pagesize = 20, $page = 100)
{
    return $threads > $pagesize * $page ? $pagesize * $page : $threads;
}*/

// hook model_format_end.php

?>