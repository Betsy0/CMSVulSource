<?php
require_once('common/incfiles/jtbc.php');
jtbc_get_pathinfo_result();
?>