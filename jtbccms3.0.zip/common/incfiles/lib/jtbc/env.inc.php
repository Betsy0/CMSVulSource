<?php
//******************************//
// JTBC Powered by jtbc.cn      //
//******************************//
namespace jtbc {
  class env
  {
    public static $language = null;
    public static $template = null;
    public static $majorGenre = null;
  }
}
//******************************//
// JTBC Powered by jtbc.cn      //
//******************************//
?>