<?php
namespace jtbc;
class ui extends page {}
?>