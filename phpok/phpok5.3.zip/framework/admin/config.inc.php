<?php
/***********************************************************
	Filename: {phpok}/admin/config.inc.php
	Note	: 网站后台配置信息
	Version : 4.0
	Web		: www.phpok.com
	Author  : qinggan <qinggan@188.com>
	Update  : 2013年6月3日
***********************************************************/
if(!defined("PHPOK_SET")){exit("<h1>Access Denied</h1>");}
$site_rs["title"] = "PHPOK官网";
?>