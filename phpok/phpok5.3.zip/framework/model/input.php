<?php
/***********************************************************
	Filename: .php
	Note	: 表单模型管理器
	Version : 4.0
	Web		: www.phpok.com
	Author  : qinggan <qinggan@188.com>
	Update  : 2013年06月25日 16时26分
***********************************************************/
if(!defined("PHPOK_SET")){exit("<h1>Access Denied</h1>");}

?>