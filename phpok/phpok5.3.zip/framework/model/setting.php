<?php
/*****************************************************************************************
	文件： {phpok}/model/setting.php
	备注： 常规项目配置
	版本： 4.x
	网站： www.phpok.com
	作者： qinggan <qinggan@188.com>
	时间： 2015年09月09日 12时59分
*****************************************************************************************/
if(!defined("PHPOK_SET")){exit("<h1>Access Denied</h1>");}
class setting_model_base extends phpok_model
{
	public function __construct()
	{
		parent::model();
	}

	
}

?>