<?php
define('NoDb', true);
require('inc/config.php');
match_route();