<!-- 头部<?php if(!defined('ucms'))exit; ?> -->
<div class="header warp">
	<div class="fl"><a href="{{homeurl}}"><img src="{{tempdir}}images/logo.png"></a></div>
	<div class="fr"><a href="http://uuu.la/help/3.html" target="_blank"><img src="//uuu.la/uploadfile/image/top.png" alt="ucms模板制作指南"></a></div>
</div>
<div class="clear"></div>
<div class="navwarp">
	<div class="warp">
	<ul class="nav">
		{{n()}}
	</ul>
	</div>
</div>
<div class="warp">
	<div class="urhere">
		<em>当前位置</em> : {{b()}}
	</div>
</div>