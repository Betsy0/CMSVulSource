<!-- ad<?php if(!defined('ucms'))exit; ?> -->
<div class="box">
	<p>广告位</p>
	<ul>
		<a href="http://uuu.la" target="_blank"><img src="//uuu.la/uploadfile/image/right.png" alt="UCMS"></a>
	</ul>
</div>