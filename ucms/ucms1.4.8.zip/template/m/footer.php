<!-- 底部<?php if(!defined('ucms'))exit; ?> -->
<div class="clear"></div>
<div class="footer warp">
	&copy; {{date(Y)}} {{copyright}}. All rights reserved. {{//未授权请勿去掉版权,免费授权:http://uuu.la/services/}}
	{{z(备案号)}} {{z(统计代码)}}
	
</div>
