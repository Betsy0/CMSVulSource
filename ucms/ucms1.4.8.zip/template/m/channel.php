<!-- 底部下属栏目<?php if(!defined('ucms'))exit; ?> -->
<div class="box">
	<p>栏目列表</p>
	<ul class="channelist">
	{{$set=array()}}
		{{$set['cid']=`cid}}
		{{n($set)}}
	</ul>
</div>