<!-- 右侧广告<?php if(!defined('ucms'))exit; ?> -->
<div class="box">
	<p class="box_title">广告位</p>
	<p class="box_content">
		<a href="http://uuu.la" target="_blank"><img src="//uuu.la/uploadfile/image/right.png" alt="UCMS"></a>
	</p>
</div>