<!-- 右侧下属栏目列表<?php if(!defined('ucms'))exit; ?> -->
<div class="box">
	<p class="box_title">栏目列表</p>
	<p class="box_content">
		<ul class="box_channel_list">
		{{$set=array()}}
		{{$set['cid']=`cid}}
		{{n($set)}}
		</ul>
	</p>
</div>