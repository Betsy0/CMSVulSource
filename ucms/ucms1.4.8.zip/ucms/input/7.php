<?php
if($inputvalue=='') {
	$inputvalue=0;
}
?>
<input<?php echo($style);?> name="<?php echo($inputname);?>" type="text"  value="<?php echo(($inputvalue));?>" size="10"  class="inputtext">