<?php
return array (
  'page' => 1,
  'article' => 2,
  'picture' => 3,
  'product' => 4,
  'download' => 5,
  'team' => 6,
);
?>