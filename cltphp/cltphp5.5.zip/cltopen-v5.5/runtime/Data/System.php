<?php
return array (
  'id' => 1,
  'name' => 'CLTPHP',
  'url' => 'http://www.cltphp.com/',
  'title' => 'CLTPHP',
  'key' => 'CLTPHP,CLTPHP内容管理系统,php',
  'des' => 'CLTPHP内容管理系统，微信公众平台、APP移动应用设计、HTML5网站API定制开发。大型企业网站、个人博客论坛、手机网站定制开发。更高效、更快捷的进行定制开发。',
  'bah' => '陕ICP备15008093号-3',
  'copyright' => '2015-2020',
  'ads' => '西安市雁塔区',
  'tel' => '18792402229',
  'email' => '1109305987@qq.com',
  'logo' => '/uploads/20170904/9f04d8be2a05d926bc3e328eded02378.png',
);
?>