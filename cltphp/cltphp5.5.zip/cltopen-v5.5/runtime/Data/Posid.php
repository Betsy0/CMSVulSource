<?php
return array (
  1 => 
  array (
    'id' => 1,
    'name' => '首页推荐',
    'listorder' => 0,
  ),
  2 => 
  array (
    'id' => 2,
    'name' => '当前分类推荐',
    'listorder' => 0,
  ),
);
?>