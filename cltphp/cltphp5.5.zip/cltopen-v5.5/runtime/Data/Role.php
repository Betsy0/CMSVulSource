<?php
return array (
  1 => 
  array (
    'id' => 1,
    'name' => '超级管理员',
    'status' => 1,
    'remark' => '超级管理',
    'pid' => 0,
    'listorder' => 0,
  ),
  2 => 
  array (
    'id' => 2,
    'name' => '普通管理员',
    'status' => 1,
    'remark' => '普通管理员',
    'pid' => 0,
    'listorder' => 0,
  ),
  3 => 
  array (
    'id' => 3,
    'name' => '注册用户',
    'status' => 1,
    'remark' => '注册用户',
    'pid' => 0,
    'listorder' => 0,
  ),
  4 => 
  array (
    'id' => 4,
    'name' => '游客',
    'status' => 1,
    'remark' => '游客',
    'pid' => 0,
    'listorder' => 0,
  ),
);
?>