<?php

$url=str_replace('hack_vote','Info_vote_',$WEBURL);
echo "<META HTTP-EQUIV=REFRESH CONTENT='0;URL=$url'>";
exit;
?>