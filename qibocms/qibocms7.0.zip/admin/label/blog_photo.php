<?php
!function_exists('html') && exit('ERR');
include(dirname(__FILE__)."/blog_log.php");
?>