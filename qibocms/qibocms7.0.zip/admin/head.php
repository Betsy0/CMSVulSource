<?php
require(dirname(__FILE__)."/"."template/head.htm");
?>