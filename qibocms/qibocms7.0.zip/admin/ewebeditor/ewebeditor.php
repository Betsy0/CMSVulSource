<?php
header("location:../kindeditor.php?id=$_GET[id]&style=$_GET[style]&etype=$_GET[etype]");exit;
?>