<?php
require(dirname(__FILE__)."/"."template/foot.htm");
exit;
?>