<?php
$_CACHE['settings'] = array (
  'accessemail' => '',
  'censoremail' => '',
  'censorusername' => '',
  'dateformat' => 'y-n-j',
  'doublee' => '1',
  'nextnotetime' => '0',
  'timeoffset' => '28800',
  'pmlimit1day' => '100',
  'pmfloodctrl' => '15',
  'pmcenter' => '1',
  'sendpmseccode' => '1',
  'pmsendregdays' => '0',
  'maildefault' => 'username@21cn.com',
  'mailsend' => '1',
  'mailserver' => 'smtp.21cn.com',
  'mailport' => '25',
  'mailauth' => '1',
  'mailfrom' => 'UCenter <username@21cn.com>',
  'mailauth_username' => 'username@21cn.com',
  'mailauth_password' => 'password',
  'maildelimiter' => '0',
  'mailusername' => '1',
  'mailsilent' => '1',
  'version' => '1.5.0',
);

?>