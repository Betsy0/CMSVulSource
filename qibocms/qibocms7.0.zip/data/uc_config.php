<?php
define('UC_CONNECT', 'mysql');
define('UC_DBHOST', 'localhost');
define('UC_DBUSER', 'root');
define('UC_DBPW', 'sohu');
define('UC_DBNAME', 'dz');
define('UC_DBCHARSET', 'gbk');
define('UC_DBTABLEPRE', '`dz`.pre_ucenter_');
define('UC_DBCONNECT', '0');
define('UC_KEY', 'fdsafd43');
define('UC_API', 'http://v7.com/dz/uc_server');
define('UC_CHARSET', 'gbk');
define('UC_IP', '');
define('UC_APPID', '2');
define('UC_PPP', '20'); 
?>