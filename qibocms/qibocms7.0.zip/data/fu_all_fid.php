<?php
unset($Fid_db);
$Fu_Fid_db[0][1]='444';
		$Fu_Fid_db[name][1]='444';
		?>