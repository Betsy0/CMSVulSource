<?php 
$GuideFid[1]="<a href='$webdb[www_url]' class='guide_menu'>&gt;首页</a> -&gt; <a  href='list.php?fid=1' class='guide_menu'>444</a>";
?>