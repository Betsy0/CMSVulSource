<?php 
$GuideFid[1]="<a href='$webdb[www_url]' class='guide_menu'>&gt;首页</a> -&gt; <a  href='list.php?fid=1' class='guide_menu'>时事新闻专题</a>";
$GuideFid[2]="<a href='$webdb[www_url]' class='guide_menu'>&gt;首页</a> -&gt; <a  href='list.php?fid=2' class='guide_menu'>娱乐新闻专题</a>";
$GuideFid[3]="<a href='$webdb[www_url]' class='guide_menu'>&gt;首页</a> -&gt; <a  href='list.php?fid=3' class='guide_menu'>2008北京生活大盘点</a>";
?>