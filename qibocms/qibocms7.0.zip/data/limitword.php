<?php 
$Limitword['造反']='造**';
$Limitword['法轮功']='法**功';
