<?php 
$GuideFid[1]="<a href='$webdb[www_url]' class='guide_menu'>&gt;首页</a> -&gt; <a  href='list.php?fid=1' class='guide_menu'>新闻中心</a>";
$GuideFid[3]="<a href='$webdb[www_url]' class='guide_menu'>&gt;首页</a> -&gt; <a  href='list.php?fid=1' class='guide_menu'>新闻中心</a> -&gt; <a  href='list.php?fid=3' class='guide_menu'>社会新闻</a>";
$GuideFid[4]="<a href='$webdb[www_url]' class='guide_menu'>&gt;首页</a> -&gt; <a  href='list.php?fid=1' class='guide_menu'>新闻中心</a> -&gt; <a  href='list.php?fid=4' class='guide_menu'>IT业界</a>";
$GuideFid[29]="<a href='$webdb[www_url]' class='guide_menu'>&gt;首页</a> -&gt; <a  href='list.php?fid=29' class='guide_menu'>产品库</a>";
$GuideFid[30]="<a href='$webdb[www_url]' class='guide_menu'>&gt;首页</a> -&gt; <a  href='list.php?fid=29' class='guide_menu'>产品库</a> -&gt; <a  href='list.php?fid=30' class='guide_menu'>晾衣机</a>";
$GuideFid[9]="<a href='$webdb[www_url]' class='guide_menu'>&gt;首页</a> -&gt; <a  href='list.php?fid=9' class='guide_menu'>图片中心</a>";
$GuideFid[10]="<a href='$webdb[www_url]' class='guide_menu'>&gt;首页</a> -&gt; <a  href='list.php?fid=9' class='guide_menu'>图片中心</a> -&gt; <a  href='list.php?fid=10' class='guide_menu'>美女欣赏</a>";
$GuideFid[11]="<a href='$webdb[www_url]' class='guide_menu'>&gt;首页</a> -&gt; <a  href='list.php?fid=11' class='guide_menu'>下载中心</a>";
$GuideFid[12]="<a href='$webdb[www_url]' class='guide_menu'>&gt;首页</a> -&gt; <a  href='list.php?fid=11' class='guide_menu'>下载中心</a> -&gt; <a  href='list.php?fid=12' class='guide_menu'>建站软件</a>";
$GuideFid[13]="<a href='$webdb[www_url]' class='guide_menu'>&gt;首页</a> -&gt; <a  href='list.php?fid=13' class='guide_menu'>影视频道</a>";
$GuideFid[14]="<a href='$webdb[www_url]' class='guide_menu'>&gt;首页</a> -&gt; <a  href='list.php?fid=13' class='guide_menu'>影视频道</a> -&gt; <a  href='list.php?fid=14' class='guide_menu'>网友视频</a>";
$GuideFid[15]="<a href='$webdb[www_url]' class='guide_menu'>&gt;首页</a> -&gt; <a  href='list.php?fid=15' class='guide_menu'>商城频道</a>";
$GuideFid[16]="<a href='$webdb[www_url]' class='guide_menu'>&gt;首页</a> -&gt; <a  href='list.php?fid=15' class='guide_menu'>商城频道</a> -&gt; <a  href='list.php?fid=16' class='guide_menu'>数码产品</a>";
$GuideFid[17]="<a href='$webdb[www_url]' class='guide_menu'>&gt;首页</a> -&gt; <a  href='list.php?fid=17' class='guide_menu'>FLASH频道</a>";
$GuideFid[18]="<a href='$webdb[www_url]' class='guide_menu'>&gt;首页</a> -&gt; <a  href='list.php?fid=17' class='guide_menu'>FLASH频道</a> -&gt; <a  href='list.php?fid=18' class='guide_menu'>MTV类</a>";
$GuideFid[26]="<a href='$webdb[www_url]' class='guide_menu'>&gt;首页</a> -&gt; <a  href='list.php?fid=11' class='guide_menu'>下载中心</a> -&gt; <a  href='list.php?fid=26' class='guide_menu'>装机软件</a>";
$GuideFid[27]="<a href='$webdb[www_url]' class='guide_menu'>&gt;首页</a> -&gt; <a  href='list.php?fid=11' class='guide_menu'>下载中心</a> -&gt; <a  href='list.php?fid=27' class='guide_menu'>办公软件</a>";
$GuideFid[31]="<a href='$webdb[www_url]' class='guide_menu'>&gt;首页</a> -&gt; <a  href='list.php?fid=1' class='guide_menu'>新闻中心</a> -&gt; <a  href='list.php?fid=31' class='guide_menu'>新闻头条</a>";
$GuideFid[32]="<a href='$webdb[www_url]' class='guide_menu'>&gt;首页</a> -&gt; <a  href='list.php?fid=1' class='guide_menu'>新闻中心</a> -&gt; <a  href='list.php?fid=32' class='guide_menu'>推荐新闻</a>";
$GuideFid[33]="<a href='$webdb[www_url]' class='guide_menu'>&gt;首页</a> -&gt; <a  href='list.php?fid=1' class='guide_menu'>新闻中心</a> -&gt; <a  href='list.php?fid=33' class='guide_menu'>图片新闻</a>";
$GuideFid[34]="<a href='$webdb[www_url]' class='guide_menu'>&gt;首页</a> -&gt; <a  href='list.php?fid=1' class='guide_menu'>新闻中心</a> -&gt; <a  href='list.php?fid=34' class='guide_menu'>热点事件</a>";
$GuideFid[38]="<a href='$webdb[www_url]' class='guide_menu'>&gt;首页</a> -&gt; <a  href='list.php?fid=1' class='guide_menu'>新闻中心</a> -&gt; <a  href='list.php?fid=38' class='guide_menu'>一语惊人</a>";
$GuideFid[39]="<a href='$webdb[www_url]' class='guide_menu'>&gt;首页</a> -&gt; <a  href='list.php?fid=1' class='guide_menu'>新闻中心</a> -&gt; <a  href='list.php?fid=39' class='guide_menu'>web新闻</a>";
$GuideFid[40]="<a href='$webdb[www_url]' class='guide_menu'>&gt;首页</a> -&gt; <a  href='list.php?fid=11' class='guide_menu'>下载中心</a> -&gt; <a  href='list.php?fid=40' class='guide_menu'>杀毒软件</a>";
?>