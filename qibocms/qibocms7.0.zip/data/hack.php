<?php

$menu_partDB['other'][]='电子商务管理';
$menudb['电子商务管理']['在线充值支付管理']=array('power'=>'alipay_set','link'=>'index.php?lfj=alipay&job=list');

$menu_partDB['other'][]='其它功能';
$menudb['其它功能']['JS内容调用']=array('power'=>'js_list','link'=>'index.php?lfj=js&job=list');

$menu_partDB['other'][]='内容模型插件功能';
$menudb['内容模型插件功能']['不良词语过滤']=array('power'=>'limitword_list','link'=>'index.php?lfj=limitword&job=list');

$menu_partDB['other'][]='内容模型插件功能';
$menudb['内容模型插件功能']['内容好坏举报管理']=array('power'=>'report_list','link'=>'index.php?lfj=report&job=list');

$menu_partDB['other'][]='电子商务管理';
$menudb['电子商务管理']['商城订单管理']=array('power'=>'shoporder','link'=>'index.php?lfj=shoporder&job=list');

$menu_partDB['other'][]='其它功能';
$menudb['其它功能']['推广赚取积分功能']=array('power'=>'propagandize','link'=>'index.php?lfj=propagandize&job=list');

$menu_partDB['other'][]='内容模型插件功能';
$menudb['内容模型插件功能']['来源地址管理']=array('power'=>'copyfrom_list','link'=>'index.php?lfj=copyfrom&job=list');

$menu_partDB['other'][]='其它功能';
$menudb['其它功能']['积分介绍管理']=array('power'=>'jfadmin_mod','link'=>'index.php?lfj=jfadmin&job=listjf');

$menu_partDB['other'][]='电子商务管理';
$menudb['电子商务管理']['点卡充值管理']=array('power'=>'moneycard_make','link'=>'index.php?lfj=moneycard&job=make');

$menu_partDB['other'][]='内容模型插件功能';
$menudb['内容模型插件功能']['字符替换']=array('power'=>'limitword_replace','link'=>'index.php?lfj=limitword&job=replace');

$menu_partDB['other'][]='其它功能';
$menudb['其它功能']['附件管理']=array('power'=>'attachment_list','link'=>'index.php?lfj=attachment&job=list');

$menu_partDB['other'][]='其它功能';
$menudb['其它功能']['地区管理']=array('power'=>'area_list','link'=>'index.php?lfj=area&job=list');

if($IS_BIZPhp168||$GLOBALS[IS_BIZPhp168]){
$menu_partDB['other'][]='内容模型插件功能';
$menudb['内容模型插件功能']['防采集设置']=array('power'=>'article_more_avoidgather','link'=>'index.php?lfj=article_more&job=avoidgather');
}

$menu_partDB['other'][]='其它功能';
$menudb['其它功能']['系统在线升级']=array('power'=>'upgrade_ol','link'=>'index.php?lfj=upgrade&job=get');

$menu_partDB['other'][]='内容模型插件功能';
$menudb['内容模型插件功能']['</a><A HREF=\'index.php?lfj=getkeyword&job=list\' target=\'main\'>关键字管理</A> | <A HREF=\'index.php?lfj=getkeyword&job=get\' target=\'main\'>提取关键字</A><a>']=array('power'=>'getkeyword_do','link'=>'index.php?lfj=getkeyword&job=list');

$menu_partDB['other'][]='内容模型插件功能';
$menudb['内容模型插件功能']['百度新闻协议/google协议']=array('power'=>'googlemap_makemap','link'=>'index.php?lfj=googlemap&job=makemap');

$menu_partDB['other'][]='数据采集器';
$menudb['数据采集器']['新浪新闻采集']=array('power'=>'gather_copysina','link'=>'index.php?lfj=gather&job=copysina');

$menu_partDB['other'][]='消息/邮件群发';
$menudb['消息/邮件群发']['站内消息群发']=array('power'=>'message_send','link'=>'index.php?lfj=message&job=send');

$menu_partDB['other'][]='站外功能';
$menudb['站外功能']['CNZZ流量统计']=array('power'=>'cnzz_set','link'=>'index.php?lfj=cnzz&job=ask');

$menu_partDB['other'][]='风格/模板设置';
$menudb['风格/模板设置']['风格管理']=array('power'=>'style_editstyle','link'=>'index.php?lfj=style&job=edittpl');

$menu_partDB['other'][]='数据采集器';
$menudb['数据采集器']['采集规则管理']=array('power'=>'gather_list','link'=>'index.php?lfj=gather&job=list');

$menu_partDB['other'][]='消息/邮件群发';
$menudb['消息/邮件群发']['邮件群发']=array('power'=>'mail_send','link'=>'index.php?lfj=mail&job=send');

$menu_partDB['other'][]='站外功能';
$menudb['站外功能']['PHPWIND营销模块']=array('power'=>'code_code','link'=>'index.php?lfj=code&job=code');

$menu_partDB['other'][]='日志管理';
$menudb['日志管理']['后台登录日志']=array('power'=>'logs_login_logs','link'=>'index.php?lfj=logs&job=login_logs');

$menu_partDB['other'][]='风格/模板设置';
$menudb['风格/模板设置']['标签数据导入与导出']=array('power'=>'labelstyle','link'=>'index.php?lfj=labelstyle&job=label');

$menu_partDB['other'][]='风格/模板设置';
$menudb['风格/模板设置']['模板设置']=array('power'=>'template_list','link'=>'index.php?lfj=template&job=list');

$menu_partDB['other'][]='数据采集器';
$menudb['数据采集器']['采集规则分类管理']=array('power'=>'gather_list_sort','link'=>'index.php?lfj=gather&job=listsort');

$menu_partDB['other'][]='消息/邮件群发';
$menudb['消息/邮件群发']['手机短信群发']=array('power'=>'sms_send','link'=>'index.php?lfj=sms&job=send');

$menu_partDB['other'][]='日志管理';
$menudb['日志管理']['后台操作日志']=array('power'=>'logs_admin_do_logs','link'=>'index.php?lfj=logs&job=admin_logs');

$menu_partDB['other'][]='插件大全';
$menudb['插件大全']['QQ在线聊天']=array('power'=>'oicq','link'=>'index.php?lfj=hack&hack=oicq&job=edit');

$menu_partDB['other'][]='插件大全';
$menudb['插件大全']['用户登录插件']=array('power'=>'login','link'=>'index.php?lfj=hack&hack=login&job=list');

$menu_partDB['other'][]='插件大全';
$menudb['插件大全']['后台菜单']=array('power'=>'adminmap','link'=>'index.php?lfj=adminmap&job=list');

$menu_partDB['other'][]='插件大全';
$menudb['插件大全']['用户消费积分记录']=array('power'=>'moneylog','link'=>'index.php?lfj=moneylog&job=list');

$menu_partDB['other'][]='插件大全';
$menudb['插件大全']['搜索']=array('power'=>'search','link'=>'index.php?lfj=hack&hack=search&job=list');

$menu_partDB['other'][]='插件大全';
$menudb['插件大全']['站点统计信息']=array('power'=>'webmsg','link'=>'index.php?lfj=hack&hack=webmsg&job=list');

$menu_partDB['other'][]='插件大全';
$menudb['插件大全']['定时任务']=array('power'=>'crontab','link'=>'index.php?lfj=crontab&job=list');

$menu_partDB['other'][]='插件大全';
$menudb['插件大全']['数据统计表']=array('power'=>'webstat','link'=>'index.php?lfj=webstat&job=list');
?>