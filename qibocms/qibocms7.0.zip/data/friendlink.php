<?php
$friendlinkDB[1]=array('5'=>array('name'=>'齐博CMS','url'=>'http://www.qibosoft.com','logo'=>'http://v7.com/upload_files/../images/default/friendlink.gif','descrip'=>'国内著名的CMS建站系统提供商'),
'26'=>array('name'=>'中国站长站','url'=>'http://www.chinaz.com/','logo'=>'http://v7.com/upload_files/friendlink/1_20090418160432_JNCry.gif','descrip'=>'中国站长站'),
'25'=>array('name'=>'站长网','url'=>'http://admin5.com/','logo'=>'http://v7.com/upload_files/friendlink/1_20090418160400_wqpAk.gif','descrip'=>'站长网'),
'27'=>array('name'=>'WEB开发网','url'=>'http://www.cncms.com.cn/','logo'=>'http://v7.com/upload_files/friendlink/1_20090418160451_64IKO.gif','descrip'=>'WEB开发网'),
'12'=>array('name'=>'PHPWIND官方论坛','url'=>'http://www.phpwind.net/','logo'=>'http://www.phpwind.net/logo.gif','descrip'=>'PHPWIND官方论坛'));
$friendlinkDB[0]=array('34'=>array('name'=>'CNZZ','url'=>'http://www.fengwu.net/','descrip'=>'CNZZ'),
'39'=>array('name'=>'华夏名网','url'=>'http://www.sudu.cn/','descrip'=>''),
'29'=>array('name'=>'中电华通','url'=>'http://www.chinaccnet.com/','descrip'=>'中电华通'));

$friendlink_DB[2][1]=array('26'=>array('name'=>'中国站长站','url'=>'http://www.chinaz.com/','logo'=>'http://v7.com/upload_files/friendlink/1_20090418160432_JNCry.gif','descrip'=>'中国站长站'),
'25'=>array('name'=>'站长网','url'=>'http://admin5.com/','logo'=>'http://v7.com/upload_files/friendlink/1_20090418160400_wqpAk.gif','descrip'=>'站长网'),
'27'=>array('name'=>'WEB开发网','url'=>'http://www.cncms.com.cn/','logo'=>'http://v7.com/upload_files/friendlink/1_20090418160451_64IKO.gif','descrip'=>'WEB开发网'));
$friendlink_DB[2][0]=array('34'=>array('name'=>'CNZZ','url'=>'http://www.fengwu.net/','descrip'=>'CNZZ'));

$friendlink_DB[3][1]=array();
$friendlink_DB[3][0]=array('39'=>array('name'=>'华夏名网','url'=>'http://www.sudu.cn/','descrip'=>''),
'29'=>array('name'=>'中电华通','url'=>'http://www.chinaccnet.com/','descrip'=>'中电华通'));