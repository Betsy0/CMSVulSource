<?php
 return array (
  'AllowUploadMax' => '0',
  'upfileType' => '',
  'upfileMaxSize' => '',
  'comment_num' => '',
  'comment_yz' => '1',
  'comment_img' => '1',
  'gid' => '4',
  'gptype' => '1',
  'grouptitle' => '前台管理员',
  'levelnum' => '0',
  'totalspace' => '0',
  'allowsearch' => '0',
  'allowadmin' => '0',
  'allowadmindb' => 
  array (
    'mymenu' => NULL,
  ),
);
?>