<?php

/**
* 以下变量需根据您的服务器说明档修改
*/
$dbhost = 'localhost';		// 数据库服务器(一般不必改)
$dbuser = 'root';			// 数据库用户名
$dbpw = 'sohu';					// 数据库密码
$dbname = 'v7';				// 数据库名
$pre='qb_';				// 网站表区分符 

$database = 'mysql';		// 数据库类型(一般不必改)
$pconnect = 0;				// 数据库是否持久连接(一般不必改)
$dbcharset = '';		// 数据库编码,如果出现网页乱码,你可以尝试改为gbk或latin1或utf8或big5,即可解决

	?>