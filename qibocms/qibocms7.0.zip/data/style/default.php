<?php
unset($styledb);
		$styledb['name']='V7风格';
		$styledb['keywords']='default';
?>