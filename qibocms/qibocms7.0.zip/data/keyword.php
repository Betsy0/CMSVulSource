<?php 
$Key_word['公司']='';
