<?php 
$ltitle[2]='游客组';		
$ltitle[3]='超级管理员';		
$ltitle[4]='前台管理员';		
$ltitle[8]='普通会员';		$memberlevel[8]=0;
$ltitle[9]='VIP会员';		$memberlevel[9]=10000;
$ltitle[10]='钻石会员';		$memberlevel[10]=30000;
