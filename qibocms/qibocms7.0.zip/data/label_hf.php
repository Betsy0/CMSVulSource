<?php

		$label[head_guides]=En_TruePath(stripslashes("      <div class=\"ico_guide bbs\"><a href=\"http://www_qibosoft_com/bbs/\" target=\'_blank\'>社区</a></div>
	  <div class=\"ico_guide post\"><a href=\"http://www_qibosoft_com/do/post.php\">投稿</a></div>
	  <div class=\"ico_guide sell\"><a href=\"http://www_qibosoft_com/do/buymoneycard.php?paytype=yeepay\">充值</a></div>
	  <div class=\"ico_guide jf\"><a href=\"http://www_qibosoft_com/do/jf.php\">积分</a></div>
	  <div class=\"ico_guide user\"><a href=\"http://www_qibosoft_com/do/list_form.php?mid=2\">招聘</a></div>
	  <div class=\"ico_guide search\"><a href=\"http://www_qibosoft_com/do/search.php\">搜索</a></div>
	  <div class=\"ico_guide book\"><a href=\"http://www_qibosoft_com/do/guestbook.php\">留言</a></div>
	  <div class=\"ico_guide digg\"><a href=\"http://www_qibosoft_com/do/listsp.php?fid=1\">专题</a></div>"),0);
		$label[head_search]=En_TruePath(stripslashes("<a href=\"http://www_qibosoft_com/do/search.php?keyword=齐博CMS\" class=\"b\">齐博CMS</a> 
        <a href=\"http://www_qibosoft_com/do/search.php?keyword=注册域名\" target=\"_blank\">注册域名</a> 
        <a href=\"http://www_qibosoft_com/do/search.php?keyword=CEO\" target=\"_blank\">CEO</a> 
        <a href=\"http://www_qibosoft_com/do/search.php?keyword=源码下载\" target=\"_blank\">源码下载</a> 
        <a href=\"http://www_qibosoft_com/do/search.php?keyword=IT资讯\" target=\"_blank\">IT资讯</a> 
        <a href=\"http://www_qibosoft_com/do/search.php?keyword=主机空间\" target=\"_blank\">主机空间</a> 
        <a href=\"http://www_qibosoft_com/do/search.php?keyword=建站手册\" class=\"b\" target=\"_blank\">建站手册</a> 
        <a href=\"http://www_qibosoft_com/do/search.php?keyword=论坛程序\" target=\"_blank\">论坛程序</a> 
        <a href=\"http://www_qibosoft_com/do/search.php?keyword=健康咨询\" class=\"b\" target=\"_blank\">健康咨询</a>"),0);