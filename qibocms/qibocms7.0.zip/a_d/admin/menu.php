<?php

return array(
'参数设置'=>array('power'=>'center','link'=>'file=center&job=config'),
'普通广告位管理'=>array('power'=>'norm_listad','link'=>'file=norm&job=listad'),
'普通广告销售管理'=>array('power'=>'norm_listuserad','link'=>'file=norm&job=listuserad'),
'竞价广告位管理'=>array('power'=>'compete_listad','link'=>'file=compete&job=listad'),
'竞价广告销售管理'=>array('power'=>'compete_listuser','link'=>'file=compete&job=listuser'),
);
?>