<?php

return array(
	'name'=>'广告模块',
	'pre'=>'ad_',
	'setup'=>2,
	'forbid_del'=>1,
);

?>