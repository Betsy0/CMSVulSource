<?php
$webdb['module_pre']='ad_';
$webdb['Info_webname']='广告系统';
$webdb['Info_webOpen']='1';
$webdb['module_close']='0';
$webdb['module_id']='24';
