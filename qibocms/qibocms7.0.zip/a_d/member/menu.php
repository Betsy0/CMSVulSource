<?php

return array(
	'购买普通广告'=>array('power'=>'1','link'=>'norm.php?job=list'),
	'购买竞价广告'=>array('power'=>'1','link'=>'compete.php?job=list'),
);

?>