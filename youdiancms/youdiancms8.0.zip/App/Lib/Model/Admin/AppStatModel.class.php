<?php
class AppStatModel extends Model{
	function getAppStat($offset = -1, $length = -1, $p = array()){
		if( $offset >= 0 && $length > 0){
			$this->limit($offset.','.$length);
		}
		
		if( !empty($p['Platform']) ){
			$where['Platform'] = $p["Platform"];
		}		
		
		if( !empty($p['StartTime']) && !empty($p['EndTime']) ){			 
			 $where['Time'] = array( array('egt', $p['StartTime']),array('elt', $p['EndTime']) );
		}
		
		$result = $this->where($where)->order('Time desc')->select();
		return $result;
	}
	
	function getAppStatCount($p = array()){	
		if( !empty($p['Platform']) ){
			$where['Platform'] = $p["Platform"];
		}		
		if( !empty($p['StartTime']) && !empty($p['EndTime']) ){			 
			 $where['Time'] = array( array('egt', $p['StartTime']),array('elt', $p['EndTime']) );
		}
		
		$n = $this->where($where)->count();
		return $n;
	}
}