<?php
/**
 * Youdian Content Management System
 * Copyright (C) YoudianSoft Co.,Ltd (http://www.youdiancms.com). All rights reserved. 
 */
class LanguageModel extends Model{
	function getLanguage($IsEnable = -1){
		if( $IsEnable != -1 ){
			$this->where("IsEnable=$IsEnable");
		}
		$data = $this->order('LanguageOrder asc')->select();
		return $data;
	}
}
