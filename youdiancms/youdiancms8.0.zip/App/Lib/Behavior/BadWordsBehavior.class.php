<?php
/**
 * Youdian Content Management System
 * Copyright (C) YoudianSoft Co.,Ltd (http://www.youdiancms.com). All rights reserved.
 */
class BadWordsBehavior extends Behavior {
    public function run(&$content) {
    	//不替换管理后台和会员后台，否则基本设置中的脏话过滤设置也会被替换
    	if( strtolower(GROUP_NAME) == "admin" || strtolower(GROUP_NAME) == "member" ) return;
    	$data = $GLOBALS['Config']['WEB_BAD_WORDS'];
    	if(empty($data)) return;
    	$data = str_replace(array("\r\n","\r"), "\n", $data);
    	$data = explode ("\n", $data);
    	$search = array();
    	$replace = array();
    	foreach ($data as $v){
    		if( strpos($v, '=') ){
    			$t = explode ("=", $v);
    			$search[] = $t[0];
    			$replace[] = $t[1];
    		}else{
    			$search[] = $v;
    			$replace[] = '';
    		}
    	}
    	if( count($search) <= 0 ) return;
		$content = str_replace($search, $replace, $content);
    }
}