<?php
/**
 * Youdian Content Management System
 * Copyright (C) YoudianSoft Co.,Ltd (http://www.youdiancms.com). All rights reserved.
 */
class EmptyAction extends BaseAction {
	public function _empty($method) {
		$this->display("./Public/tpl/".C('TMPL_404') );
	}
}