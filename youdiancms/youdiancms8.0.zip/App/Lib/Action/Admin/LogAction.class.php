<?php
/**
 * Youdian Content Management System
 * Copyright (C) YoudianSoft Co.,Ltd (http://www.youdiancms.com). All rights reserved.
 */
class LogAction extends AdminBaseAction{
	//友情链接
	function index(){
		$p['Parameter'] = array(
				'UserName' => $_REQUEST['UserName'],
				'LogType' => $_REQUEST['LogType'],
		);
		$p['HasPage'] = true; //表示有分页
		$this->opIndex( $p );
	}
	
	//删除、批量删除
	function del(){
		if( !empty($_REQUEST['UserName']) ){
			$p['Parameter']['UserName'] = $_REQUEST['UserName'];
		}
		if( !empty($_REQUEST['LogType']) ){
			$p['Parameter']['LogType'] = $_REQUEST['LogType'];
		}
		if( is_numeric($_REQUEST['p']) ){
			$p['Parameter']['p'] = $_REQUEST['p'];
		}
		$this->opDel( $p );
	}

	//清除所有日志
	function delAll(){
		$this->opDelAll( );
	}
	
	function config(){
		$m = D('Admin/Config');
		$data = $m->getConfig('basic'); //配置数据不从缓存中提取
		$this->assign('LogStatus', $data['LOG_STATUS'] );
		$this->assign('LogTypeAllow', $data['LOGTYPE_ALLOW'] );
		$this->assign('Action', __URL__.'/saveConfig' );
		$this->display();
	}
	
	//保存配置
	function saveConfig(){
		if( isset($_POST) ){
			unset( $_POST['__hash__'] );
			if( is_array($_POST['LOGTYPE_ALLOW']) ){
				$_POST['LOGTYPE_ALLOW'] = implode(',', $_POST['LOGTYPE_ALLOW']);
			}else{
				$_POST['LOGTYPE_ALLOW'] = '';
			}
			$m = D("Admin/Config");
			if( $m->saveConfig($_POST,'basic') ){
				WriteLog();
				$this->ajaxReturn(null, '保存成功!' , 1);
			}else{
				$this->ajaxReturn(null, '保存失败!' , 0);
			}
		}
	}
	
	//通过IP获取地理位置
	function getLocation(){
		//现对ip进行去重
		$ips = array_unique($_POST['UserIP']);
		$m = D('Admin/Log');
		foreach ($ips as $ip){
			$data = yd_ip2location($ip);
			if( $data !== false ){
				$city = implode(' ', $data);
				$m->setCity($ip, $city);
			}
		}
		$this->ajaxReturn(null, '保存成功!' , 1);
	}
}