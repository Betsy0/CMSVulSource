<?php
return array (
  'DB_TYPE' => 'mysqli',
  'DB_HOST' => 'localhost',
  'DB_NAME' => 'ydbase',
  'DB_USER' => 'cms',
  'DB_PWD' => 'cms',
  'DB_PORT' => '3306',
  'DB_PREFIX' => 'youdian_',
);
?>