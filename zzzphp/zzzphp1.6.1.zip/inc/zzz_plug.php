<?php
function parserPlugLoop($zcontent){
	return $zcontent;
}
?>