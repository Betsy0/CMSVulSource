<?php
//<-- ZZZCMS-->
//版本号 版本时间 版本介绍网址 略过升级时间 
//<-- /ZZZCMS-->
const ZZZ_VERSION = "V1.6.1";
const ZZZ_VERDATE = "190128";
const ZZZ_VERURL = "zzzcms.com/a/news/31_222_1.html";
const ZZZ_VERTIME = "2019/01/28 14:00:00";
const ZZZ_VERDESC = "zzzcms php 1.6.1";