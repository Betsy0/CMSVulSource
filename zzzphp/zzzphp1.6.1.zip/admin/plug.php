<?php
require_once '../inc/zzz_class.php';
function  plug_list(){}
?>