<?php
define('ISWAP', 1); 
define('WAPPATH', 'wap/'); 
require '../inc/zzz_client.php';


