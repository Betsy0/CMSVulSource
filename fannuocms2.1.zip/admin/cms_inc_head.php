<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="renderer" content="webkit" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<title>凡诺企业网站管理系统后台</title>
<link rel="stylesheet" href="../editor/themes/default/default.css" />
<link href="../plus/ui/ui.css" rel="stylesheet" type="text/css" />
<link href="../plus/ui/font.css" rel="stylesheet" type="text/css" />
<link href="cms_style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="../plus/jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="../plus/ui/ui.js"></script>
<script type="text/javascript" src="../plus/jquery.waypoints.min.js"></script>
<script type="text/javascript" src="../plus/laydate/laydate.js"></script>
<script type="text/javascript" src="../plus/admin.js"></script>
<script charset="utf-8" type="text/javascript" src="../editor/kindeditor.js"></script>
