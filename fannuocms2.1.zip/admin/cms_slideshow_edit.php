<?php
include('./cms_inc.php');
include('./cms_check.php');
if ( isset($_POST['save']) ) {
	null_back($_POST['s_picture'],'请输入或上传图片');
	non_numeric_back($_POST['s_order'],'请输入排序数字');
	$_data['s_name'] = $_POST['s_name'];
	$_data['s_parent'] = $_POST['s_parent'];
	$_data['s_picture'] = $_POST['s_picture'];
	$_data['s_url'] = $_POST['s_url'];
	$_data['s_order'] = $_POST['s_order'];
	$_data['s_content'] = $_POST['s_content'];
	$_data['s_order'] = $_POST['s_order'];
	$sql = 'update cms_slideshow set '.arrtoupdate($_data).' where id = '.$_GET['id'].'';
	if(sql_query($sql)){
		alert_href('幻灯修改成功!','cms_slideshow.php');
	}else{
		alert_back('修改失败!');
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('./cms_inc_head.php') ?>
<script type="text/javascript">
KindEditor.ready(function(K) {
	var editor = K.editor();
	K('#picture').click(function() {
		editor.loadPlugin('image', function() {
			editor.plugin.imageDialog({
			imageUrl : K('#s_picture').val(),
			clickFn : function(url, title, width, height, border, align) {
				K('#s_picture').val(url);
				editor.hideDialog();
				}
			});
		});
	});
});
</script>
</head>
<body>
<?php include('./cms_inc_header.php') ?>
<div id="content">
	<div class="container oh">
			<?php include('./cms_inc_left.php') ?>
			<div id="right">
				<div class="hd-1">修改幻灯</div>
				<div class="bd-1">
					<?php
					$result = sql_query('select * from cms_slideshow where id = '.$_GET['id'].' ');
					if ($row = sql_fetch_array($result)){
					?>
					<form method="post">
						<div class="form-group">
							<div class="label"><label for="s_name">名称</label></div>
							<div class="field">
								<input id="s_name" class="input" name="s_name" type="text" size="60" value="<?php echo $row['s_name'];?>" />
							</div>
						</div>
						<div class="form-group">
							<div class="label"><label for="s_parent">属于</label></div>
							<div class="field">
								<select id="s_parent" class="input" name="s_parent">
									<option value="1" <?php echo ($row['s_parent'] == 1) ? 'selected="selected"' : '' ; ?>>电脑端</option>
									<?php
									if (!$system_closem) {
									?>
									<option value="2" <?php echo ($row['s_parent'] == 2) ? 'selected="selected"' : '' ; ?>>手机端</option>
									<?php
									}
									?>
								</select>
							</div>
						</div>
						<div class="form-group">
							<div class="label"><label for="s_picture">图片 <span class="badge bg-dot">必填</span></label> <span class="badge bg-green cp" id="picture">上传</span></div>
							<div class="field">
								<input id="s_picture" class="input" name="s_picture" type="text" size="60" data-validate="required:请输入或上传图片" value="<?php echo $row['s_picture'];?>" />
							</div>
						</div>
						<div class="form-group">
							<div class="label"><label for="s_url">链接</label></div>
							<div class="field">
								<input id="s_url" class="input" name="s_url" type="text" size="60" value="<?php echo $row['s_url'];?>" />
							</div>
						</div>
						<div class="form-group">
							<div class="label"><label for="s_order">排序 <span class="badge bg-dot">必填</span></label></div>
							<div class="field">
								<input id="s_order" class="input" name="s_order" type="text" size="60" data-validate="required:必填,plusinteger:请输入排序数字" value="<?php echo $row['s_order'];?>" />
							</div>
						</div>
						<div class="form-group">
							<div class="label"><label for="s_content">内容</label></div>
							<div class="field">
								<textarea id="s_content" class="input" name="s_content" row="5" /><?php echo $row['s_content'];?></textarea>
							</div>
						</div>
						<div class="form-group">
							<div class="label"><label></label></div>
							<div class="field">
								<input id="save" class="btn bg-dot" name="save" type="submit" value="修改幻灯" />
							</div>
						</div>
					</form>
					<?php } ?>
				</div>
			</div>
	</div>
</div>
<?php include('./cms_inc_footer.php') ?></body>
</html>