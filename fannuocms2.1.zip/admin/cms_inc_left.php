<div id="left">
	<dl>
		<dt><span class="icon-bars"> 内容管理</span></dt>
		<dd><a<?php echo (file_self() == 'cms_detail_add.php') ? ' class="current"' : '';?> href="cms_detail_add.php">添加详情</a></dd>
		<dd><a<?php echo (file_self() == 'cms_detail.php') ? ' class="current"' : '';?> href="cms_detail.php">管理详情</a></dd>
		<dd><a<?php echo (file_self() == 'cms_channel_add.php') ? ' class="current"' : '';?> href="cms_channel_add.php">添加频道</a></dd>
		<dd><a<?php echo (file_self() == 'cms_channel.php') ? ' class="current"' : '';?> href="cms_channel.php">管理频道</a></dd>
		<dd><a<?php echo (file_self() == 'cms_slideshow.php') ? ' class="current"' : '';?> href="cms_slideshow.php">管理幻灯</a></dd>
		<dd><a<?php echo (file_self() == 'cms_chip.php') ? ' class="current"' : '';?> href="cms_chip.php">碎片内容</a></dd>
		<dt><span class="icon-users"> 交互管理</span></dt>
		<dd><a<?php echo (file_self() == 'cms_feedback.php') ? ' class="current"' : '';?> href="cms_feedback.php">留言管理</a></dd>
		<dd><a<?php echo (file_self() == 'cms_link.php') ? ' class="current"' : '';?> href="cms_link.php">友情链接</a></dd>
		<dt><span class="icon-cog"> 系统设置</span></dt>
		<dd><a<?php echo (file_self() == 'cms_system.php') ? ' class="current"' : '';?> href="cms_system.php">基本设置</a><dd>
		<dd><a<?php echo (file_self() == 'cms_admin.php') ? ' class="current"' : '';?> href="cms_admin.php">管理员</a><dd>
	</dl>
<p>
</div>

