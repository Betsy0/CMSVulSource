<div id="header">
	<div class="container">
		<div class="line">
			<div class="x6 name">凡诺企业网站管理系统</div>
			<div class="x6 ar menu">
				<a class="btn bg-black" href="cms_channel.php" ><span class="icon-home"> 后台首页</span></a>
				<a class="btn bg-black" href="exit.php" onClick="return confirm('确定要退出吗？')"><span class="icon-sign-out"> 安全退出</span></a>
				<a class="btn bg-black" href="../" target="_blank"><span class="icon-eye"> 预览网站</span></a>
				<a class="btn bg-black" href="http://www.pcfinal.cn" target="_blank"><span class="icon-question-circle"> 官方网站</span></a>
			</div>
		</div>
	</div>
</div>
