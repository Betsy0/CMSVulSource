<?php
include('./cms_inc.php');
include('./cms_check.php');
if(isset($_POST['save'])){
	$_data['c_name'] = $_POST['c_name'];
	$_data['c_content'] = $_POST['c_content'];
	$_data['c_safe'] = $_POST['c_safe'];
	$sql = 'update cms_chip set '.arrtoupdate($_data).' where id = '.$_GET['id'].'';
	if(sql_query($sql)){
		alert_href('碎片修改成功!','cms_chip.php');
	}else{
		alert_back('碎片修改失败!');
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('./cms_inc_head.php') ?>
<script type="text/javascript">
	KindEditor.ready(function(K) {
		K.create('#c_content');
	});
</script>
</head>
<body>
<?php include('./cms_inc_header.php') ?>
<div id="content">
	<div class="container oh">
			<?php include('./cms_inc_left.php') ?>
			<div id="right">
				<div class="hd-1">修改碎片</div>
				<div class="bd-1">
					<?php
					$result = sql_query('select * from cms_chip where id = '.$_GET['id'].'');
					if($row = sql_fetch_array($result)){
					?>
					<form method="post">
						<div class="form-group">
							<div class="label"><label for="c_name">碎片名称 <span class="badge bg-dot">必填</span></label></div>
							<div class="field">
								<input id="c_name" class="input" name="c_name" type="text" size="60" data-validate="required:请填写碎片名称" value="<?php echo $row['c_name']?>" />
								<div class="input-note">请填写碎片名称</div>
							</div>
						</div>
						<div class="form-group">
							<div class="label"><label for="c_content">碎片内容</label></div>
							<div class="field">
								<textarea id="c_content" class="input" name="c_content" row="5" /><?php echo htmlspecialchars($row['c_content'])?></textarea>
								<div class="input-note">请填写碎片内容</div>
							</div>
						</div>
						<div class="form-group">
							<div class="label"><label for="c_safe">安全保护</label></div>
							<div class="field">
								<label class="btn"><input id="c_safe" name="c_safe" type="radio" value="0" <?php echo ($row['c_safe'] == 0 ? 'checked="checked"':'')?>/>否</label>
								<label class="btn"><input name="c_safe" type="radio" value="1" <?php echo ($row['c_safe'] == 1 ? 'checked="checked"':'')?>/>是</label>
								<div class="input-note">描述</div>
							</div>
						</div>
						<div class="form-group">
							<div class="label"><label></label></div>
							<div class="field">
								<input id="save" class="btn bg-dot" name="save" type="submit" value="修改碎片内容" />
							</div>
						</div>
					</form>
					<?php
					}
					?>
				</div>
			</div>
	</div>
</div>
<?php include('./cms_inc_footer.php') ?>
</body>
</html>