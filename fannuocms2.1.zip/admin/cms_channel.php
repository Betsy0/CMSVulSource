<?php
include('./cms_inc.php');
include('./cms_check.php');
if (isset($_GET['del'])){
	$sql = 'select * from cms_channel where id = '.$_GET['del'].'';
	$result = sql_query($sql);
	$row = sql_fetch_array($result);
	if($row['c_ifsub'] == 0 && $row['c_safe']==0)	{
		sql_query('delete from cms_channel where id = '.$_GET['del'].'');
		sql_query('delete from cms_detail where d_parent = '.$_GET['del'].'');
		update_channel();
		alert_href('删除成功！','cms_channel.php');
	}else{
		alert_back('此频道存在下级或已受保护，无法删除！');
	}

}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('./cms_inc_head.php') ?>
</head>
<body>
<?php include('./cms_inc_header.php') ?>
<div id="content">
	<div class="container oh">
			<?php include('./cms_inc_left.php') ?>
			<div id="right">
				<div class="hd-1">管理频道</div>
				<div class="bd-1">
					<div class="quote border-green mb20">
						<div class="l10">
							<div class="x2"><span class="btn bg-dot btn-block">收费版优势 →</span></div>
							<div class="x2"><span class="btn bg-black btn-block">支持手机版</span></div>
							<div class="x2"><span class="btn bg-black btn-block">多套模板切换</span></div>
							<div class="x2"><span class="btn bg-black btn-block">内容模型较多</span></div>
							<div class="x2"><span class="btn bg-black btn-block">支持静态</span></div>
							<div class="x2"><span class="btn bg-black btn-block">有技术服务</span></div>
						</div>
						<div class="quote mt20">
						<p>购买咨询：QQ：<a href="http://wpa.qq.com/msgrd?v=3&uin=5474131&site=qq&menu=yes">5474131</a>　电话/微信：13400472755　网址：<a href="http://www.pcfinal.cn" target="_blank">www.pcfinal.cn</a></p>
						</div>
					</div>
					<table class="table table-bordered table-hover table-striped">
						<tr>
							<th>ID</th>
							<th>排序</th>
							<th>频道名称</th>
							<th>频道模型</th>
							<th>内容模型</th>
							<th>内容操作</th>
							<th>频道操作</th>
						</tr>
						<?php echo channel_manage(0,0); ?>
					</table>
					<div class="quote border-red mt10">
						 同级别频道，排序数字越小越靠前
					</div>
				</div>

			</div>
	</div>
</div>
<?php include('./cms_inc_footer.php') ?>
</body>
</html>