<?php
include('./cms_inc.php');
include('./cms_check.php');
if (isset($_POST['save'])) {
	$_data['c_name'] = $_POST['c_name'];
	$_data['c_content'] = $_POST['c_content'];
	$_data['c_safe'] = $_POST['c_safe'];
	$str = arrtoinsert($_data);
	$sql = 'insert into cms_chip ('.$str[0].') values ('.$str[1].')';
	if (sql_query($sql)) {
		alert_href('碎片添加成功!','cms_chip.php');
	} else {
		alert_back('添加失败!');
	}

}
if(isset($_GET['del'])){
	$result = sql_query('select * from cms_chip where id = '.$_GET['del'].' ');
	$row = sql_fetch_array($result);
	if($row['c_safe'] == 1){
		alert_back('此碎片内容受保护,无法删除！');
	}
	$result = 'delete from cms_chip where id = '.$_GET['del'].'';
	if(sql_query($result)){
		alert_href('删除成功!','cms_chip.php');
	}else{
		alert_back('删除失败！');
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('./cms_inc_head.php') ?>
<script type="text/javascript">
	KindEditor.ready(function(K) {
		K.create('#c_content');
	});
</script>
</head>
<body>
<?php include('./cms_inc_header.php') ?>
<div id="content">
	<div class="container oh">
			<?php include('./cms_inc_left.php') ?>
			<div id="right">
				<div class="hd-1">碎片管理</div>
				<div class="bd-1">
					<table class="table table-bordered">
						<tr>
							<th>ID</th>
							<th>碎片名称</th>
							<th>调用代码</th>
							<th>操作</th>
						</tr>
						<?php
						$result = sql_query('select * from cms_chip order by id asc');
						while($row = sql_fetch_array($result)){
						?>
						<tr class="ac">
							<td><?php echo $row['id']?></td>
							<td class="al"><?php echo $row['c_name']?></td>
							<td><span class="badge">&lt;?php echo get_chip(<?php echo $row['id']?>)?&gt;</span></td>
							<td>
								<a class="btn bg-sub" href="cms_chip_edit.php?id=<?php echo $row['id']?>"><span class="icon-edit"> 修改</span></a>
								<?php
								if ($row['c_safe'] == 0) {
								?><a class="btn bg-dot" href="cms_chip.php?del=<?php echo $row['id']?>" onclick="return confirm('确认要删除吗？')"><span class="icon-times"> 删除</span></a>
								<?php
								}
								?>
							</td>
						</tr>
						<?php
						}
						?>
					</table>
				</div>
				<div class="hd-1">添加碎片</div>
				<div class="bd-1">
					<form method="post">
						<div class="form-group">
							<div class="label"><label for="c_name">碎片名称 <span class="badge bg-dot">必填</span></label></div>
							<div class="field">
								<input id="c_name" class="input" name="c_name" type="text" size="60" data-validate="required:请填写碎片名称" value="" />
								<div class="input-note">请填写碎片名称</div>
							</div>
						</div>
						<div class="form-group">
							<div class="label"><label for="c_content">碎片内容</label></div>
							<div class="field">
								<textarea id="c_content" class="input" name="c_content" row="5" /></textarea>
								<div class="input-note">请填写碎片内容</div>
							</div>
						</div>
						<div class="form-group">
							<div class="label"><label for="c_safe">安全保护</label></div>
							<div class="field">
								<label class="btn"><input id="c_safe" name="c_safe" type="radio" value="0" checked="checked"/>否</label>
								<label class="btn"><input name="c_safe" type="radio" value="1" />是</label>
								<div class="input-note">保护后不能直接删除</div>
							</div>
						</div>
						<div class="form-group">
							<div class="label"><label></label></div>
							<div class="field">
								<input id="save" class="btn bg-dot" name="save" type="submit" value="添加碎片内容" />
							</div>
						</div>
					</form>
				</div>
			</div>
	</div>
</div>
<?php include('./cms_inc_footer.php') ?>
</body>
</html>