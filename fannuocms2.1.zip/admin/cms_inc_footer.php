<div id="footer">
	<div class="container">
		<div class="line">
			<p>版权所有 2008-2018 保留所有权利</p>
			<p>当前版本：免费版-<?php echo $system_version; ?></p>
		</div>
	</div>
</div>
