<?php
$dir = dirname(__FILE__);
require_once($dir.'/system/conn.php');
require_once($dir.'/system/library.php');
require_once($dir.'/system/config.php');
require_once($dir.'/system/function.php');
?>