<?php
ob_start();
session_start();
define('PCFINAL', TRUE);
date_default_timezone_set('PRC');//设置时区
header('Content-type:text/html; charset=utf-8');//设置编码
include_once('data.php');
if (function_exists('mysqli_close')) {
	$conn = mysqli_connect(DATA_HOST, DATA_USERNAME, DATA_PASSWORD,DATA_NAME);
	mysqli_set_charset($conn, 'utf8');
} else {
	$conn = mysql_connect(DATA_HOST, DATA_USERNAME, DATA_PASSWORD);
	mysql_select_db(DATA_NAME);
	mysql_query('set names utf8');
}
?>
