<?php
if(!defined('PCFINAL')) exit('Request Error!');
$system_version = '2.1-20181102';
$result = sql_query('select * from cms_system where id = 1');
$row = sql_fetch_array($result);
$system_template = $row['s_template'];
$system_mtemplate = $row['s_mtemplate'];
$system_domain = $row['s_domain'];
$system_mdomain = $row['s_mdomain'];
$system_name = $row['s_name'];
$system_seoname = $row['s_seoname'];
$system_keywords = $row['s_keywords'];
$system_description = $row['s_description'];
$system_copyright = $row['s_copyright'].'<p class="ar f12">系统开发：<a href="http://www.pcfinal.cn" target="_blank">凡诺</a></p>';
$system_mcopyright = $row['s_mcopyright'];
$system_hotkeywords = $row['s_hotkeywords'];
$system_feedback = $row['s_feedback'];
$system_phone = $row['s_phone'];
$system_qq = $row['s_qq'];
$system_qrcode = $row['s_qrcode'];
$system_mode = $row['s_mode'];
$system_p1 = $row['s_p1'];
$system_p2 = $row['s_p2'];
$system_p3 = $row['s_p3'];
$system_p4 = $row['s_p4'];
$system_square = $row['s_square'];
$system_slideshow = $row['s_slideshow'];
$s_path = '';
$t_path = '/template/'.$system_template.'/';
$t_mpath = '/template/'.$system_mtemplate.'/';
$result = sql_query('select * from cms_template where t_path = "'.$system_template.'" ');
if ($row = sql_fetch_array($result)){
	$system_logo = $row['t_logo'];
}
$result = sql_query('select * from cms_template where t_path = "'.$system_mtemplate.'" ');
if ($row = sql_fetch_array($result)){
	$system_mlogo = $row['t_logo'];
}
$system_closem = true;
//判断是否是移动设备
function ism() {
	$ism = false;
	return $ism;
}
//频道链接地址
function c_url($t0){
	global $s_path;
	return $s_path.'/channel.php?id='.$t0.'';
}
//详情链接地址
function d_url($t0){
	global $s_path;
	return $s_path.'/detail.php?id='.$t0.'';
}

//频道列表
function channel_list($t0,$t1){
	$tmp = '';
	$result = sql_query('select * from cms_channel where c_parent = '.$t0.' order by c_order asc , id asc ');
	while ($row = sql_fetch_array($result)){
		$tmp .= '<li><a '.($row['id'] == $t1 ? ' class="current"' : '').' href="'.c_url($row['id']).'" target="'.$row['c_target'].'">'.$row['c_name'].'</a></li>';
	}
	return $tmp;
}

function channel_dlist ($t0){
	$tmp = '';
	$result = sql_query('select * from cms_channel where c_parent = '.$t0.' order by c_order asc , id asc ');
	while ($row = sql_fetch_array($result)){
		$tmp .= '<div class="hd"><a href="'.c_url($row['id']).'" target="'.$row['c_target'].'">'.$row['c_name'].'</a></div>';
		$tmp .= '<div class="bd"><ul>';
			$results = sql_query('select * from cms_channel where c_parent = '.$row['id'].' order by c_order asc , id asc ');
			while ( $rows = sql_fetch_array($results) ) {
				$tmp .= '<li><a href="'.c_url($rows['id']).'" target="'.$rows['c_target'].'">'.$rows['c_name'].'</a></li>';
			}
		$tmp .= '</ul></div>';
	}
	return $tmp;
}

//频道和内容页的当前位置
function current_location($t0,$t1){
	$tmp = '';
	$result = sql_query('select * from cms_channel where id = '.$t0.'');
	while($row = sql_fetch_array($result)){
		$current = ($row['id'] == $t1 ? 'class ="current"' :'');
		$tmp = '<a '.$current.' href="'.c_url($row['id']).'">'.$row['c_name'].'</a>';
		if($row['c_parent'] <> 0){
			$tmp = current_location($row['c_parent'],$t1).' > '.$tmp;
		}
	}
	return $tmp;
}

//获取频道字段
function get_channel($t0,$t1){
	$result = sql_query('select * from cms_channel where id='.$t0.'');
	if (!!$row = sql_fetch_array($result)){
		return $row[$t1];
	}else{
		return '不存在';
	};
}

//获取碎片内容
function get_chip($t0){
	$result = sql_query('select * from cms_chip where id='.$t0.'');
	if (!!$row = sql_fetch_array($result)){
		return $row['c_content'];
	}else{
		return '';
	};
}

?>