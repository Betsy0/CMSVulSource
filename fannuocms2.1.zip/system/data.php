<?php
header('location:../install/index.php');
die();
//Mysql数据库信息
if(!defined('PCFINAL')) exit('Request Error!');
define('DATA_HOST', '127.0.0.1');
define('DATA_USERNAME', 'root');
define('DATA_PASSWORD', '123456');
define('DATA_NAME', 'ems');
?>