<div id="header">
	<div class="container">
		<div class="line ov">
			<div class="x3" id="logo"><a href="<?php echo $system_domain ?>"><img src="<?php echo $system_logo?>" title="<?php echo $system_seoname.'-'.$system_name; ?>" alt="<?php echo $system_seoname.'-'.$system_name; ?>"></a></div>
			<div class="x9" id="navigation">
				<ul>
					<?php
					$result = sql_query('select * from cms_channel where (c_nav <> 0 and c_nav <> 5 and c_parent = 0) or c_nav = 2 or c_nav = 3 order by c_order desc , id desc');
					while ($row = sql_fetch_array($result)){
					?>
					<li class="main"><a<?php echo ($row['id'] == $c_main ? ' class="current"' : '') ?> href="<?php echo c_url($row['id']); ?>" target="<?php echo $row['c_target'];?>">
					<div class="name"><?php echo $row['c_nname'];?></div>
					<div class="aname"><?php echo $row['c_aname'];?></div>
					</a>
						<?php
						if ($row['c_ifsub'] == 1) {
							echo '<ul class="sub">';
							$results = sql_query('select * from cms_channel where (c_nav <> 0 and c_nav <> 5) and c_parent = '.$row['id'].' order by c_order asc , id asc');
							while ($rows = sql_fetch_array($results)){
								echo '<li><a href="'.c_url($rows['id']).'" target="'.$rows['c_target'].'">'.$rows['c_nname'].'</a></li>';
							}
							echo '</ul>';
						}
						?>
					</li>
					<?php
					}
					?>
					<li class="home">
						<a href="index.php">
							<div class="name">首页</div>
							<div class="aname">Home</div>
						</a>
					</li>
				</ul>
			</div>
			<div class="fc"></div>
		</div>
	</div>
</div>