<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="renderer" content="webkit" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<title><?php echo $d_title?></title>
<meta name="keywords" content="<?php echo $d_keywords;?>" />
<meta name="description" content="<?php echo $d_description;?>" />
<?php include($dir.$t_path.'inc_head.php');?>
</head>
<body>
<?php include($dir.$t_path.'inc_header.php');?>
<div id="content">
	<div class="container">
		<div class="l20">
			<div class="x3">
				<div class="hd1"><?php echo $c_name?> <span><?php echo $c_aname?></span></div>
				<div class="bd1">
					<ul class="channel_list">
						<?php echo $channel_list?>
					</ul>
				</div>
				<?php if ($c_rh == 1) { ?>
				<div class="hd1">推荐<?php echo $c_sname;?></div>
				<div class="bd1">
					<ul class="list-group">
					<?php
					$result = sql_query('select id,d_name,d_picture,d_scontent,d_date from cms_detail where d_parent in ('.$c_sub.') and d_rec = 1 order by d_order desc , id desc limit 0 , 10');
					while ($row = sql_fetch_array($result)){
					?>
					<li class="cut"><a href="<?php echo d_url($row['id'])?>" target="_blank" title="<?php echo $row['d_name'];?>"><?php echo $row['d_name'];?></a></li>
					<?php
					}
					?>
					</ul>
				</div>
				<div class="hd1">热门<?php echo $c_sname;?></div>
				<div class="bd1">
					<ul class="list-group">
					<?php
					$result = sql_query('select id,d_name,d_picture,d_scontent,d_date from cms_detail where d_parent in ('.$c_sub.') and d_hot = 1 order by d_order desc , id desc limit 0 , 10');
					while ($row = sql_fetch_array($result)){
					?>
					<li class="cut"><a href="<?php echo d_url($row['id'])?>" target="_blank" title="<?php echo $row['d_name'];?>"><?php echo $row['d_name'];?></a></li>
					<?php
					}
					?>
					</ul>
				</div>
				<?php } ?>
			</div>
			<div class="x9">
				<div id="current_location">当前位置：<a href="index.php">首页</a> > <?php echo $current_location?></div>
				<h1 id="detail_name"><?php echo $d_name?></h1>
				<div id="detail_intro" class="quote">来源：<?php echo $d_source?> 作者：<?php echo $d_author?> 发布日期：<?php echo date('Y-m-d',$d_date)?> 访问次数：<?php echo $d_hits?></div>
				<div class="l20 mt20">
					<div class="x3"></div>
					<div class="x6">
						<?php if($d_picture != '' && $d_slideshow == ''){ ?>
						<div id="detail_picture"><a href="<?php echo $d_picture ?>" target="_blank"><img src="<?php echo $d_picture?>" alt="<?php echo $d_name?>" title="<?php echo $d_name?>"></a></div>
						<?php } ?>
						<?php if($d_slideshow != ''){ ?>
						<div id="detail_slideshow">
							<script type="text/javascript">
							$(function(){
								$('#detail_slideshow').slide({
									trigger : 'click',
									effect : 'fade'
								});
							});
							</script>
							<ul class="bd">
							<?php
							$arr_slideshow = explode('|',$d_slideshow);
							foreach($arr_slideshow as $value){
								echo '<li><img src="'.$value.'"></li>';
							}
							?>
							</ul>
							<ul class="hd l10">
							<?php
							foreach($arr_slideshow as $value){
								echo '<li class="x2"><img class="mb10" src="'.$value.'" width="64" height="64"></li>';
							}
							?>
							</ul>
						</div>
						<?php } ?>
					</div>
				</div>
				<div id="detail_content"><?php echo $d_content;?></div>
				<?php if ( $d_file != '' ) { ?>
				<div id="detail_attachment"><a class="btn bg-main" href="<?php echo $d_file ?>">点击下载</a></div>
				<?php } ?>
				<div id="detail_around" class="quote">
					<p>上一<?php echo $c_sname?>：<?php echo $d_previous?></p>
					<p>下一<?php echo $c_sname?>：<?php echo $d_next?></p>
				</div>
			</div>
		</div>
	</div>
</div>
<?php include($dir.$t_path.'inc_footer.php');?>
</body>
</html>
