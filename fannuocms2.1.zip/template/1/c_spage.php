<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="renderer" content="webkit" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<title><?php echo $c_title;?></title>
<meta name="keywords" content="<?php echo $c_keywords;?>" />
<meta name="description" content="<?php echo $c_description;?>" />
<?php include($dir.$t_path.'inc_head.php');?>
</head>
<body>
<?php include($dir.$t_path.'inc_header.php');?>
<div id="content">
	<div class="container">
		<?php if ($c_cover != ''){ ?>
		<div id="channel_cover">
			<img src="<?php echo $c_cover;?>" alt="<?php echo $c_title;?>">
		</div>
		<?php } ?>
		<div class="l20">
			<div class="x3">
				<div class="hd1"><?php echo (($c_ifsub == 1) ? $c_name : $cp_name);?> <span><?php echo (($c_ifsub == 1) ? $c_aname : $cp_aname);?></div>
				<div class="bd1">
					<ul class="channel_list">
						<?php echo $channel_list?>
					</ul>
				</div>
			</div>
			<div class="x9">
				<div id="current_location">当前位置：<a href="index.php">首页</a> > <?php echo $current_location?></div>
				<div id="channel_content"><?php echo $c_content?></div>
			</div>
		</div>
	</div>
</div>
<?php include($dir.$t_path.'inc_footer.php');?>
</body>
</html>
