<link href="<?php echo $s_path;?>/plus/ui/ui.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $s_path;?>/plus/ui/font.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $s_path.$t_path?>style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo $s_path;?>/plus/jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="<?php echo $s_path;?>/plus/jquery.SuperSlide.2.1.js"></script>
<script type="text/javascript" src="<?php echo $s_path;?>/plus/ui/ui.js"></script>
<script type="text/javascript" src="<?php echo $s_path;?>/plus/jqthumb.min.js"></script>
<script type="text/javascript" src="<?php echo $s_path.$t_path?>js/custom.js"></script>