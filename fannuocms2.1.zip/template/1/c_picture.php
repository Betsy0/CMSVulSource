<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="renderer" content="webkit" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<title><?php echo $c_title;?></title>
<meta name="keywords" content="<?php echo $c_keywords;?>" />
<meta name="description" content="<?php echo $c_description;?>" />
<?php include($dir.$t_path.'inc_head.php');?>
</head>
<body>
<?php include($dir.$t_path.'inc_header.php');?>
<div id="content">
	<div class="container">
		<?php if ($c_cover != ''){ ?>
		<div id="channel_cover">
			<img src="<?php echo $c_cover;?>" alt="<?php echo $c_title;?>">
		</div>
		<?php } ?>
		<div class="l20">
			<div class="x3">
				<div class="hd1"><?php echo (($c_ifsub == 1) ? $c_name : $cp_name);?> <span><?php echo (($c_ifsub == 1) ? $c_aname : $cp_aname);?></div>
				<div class="bd1">
					<ul class="channel_list">
						<?php echo $channel_list?>
					</ul>
				</div>
				<?php if ($c_rh == 1) { ?>
				<div class="hd1">推荐<?php echo $c_sname;?></div>
				<div class="bd1">
					<div class="l10 plist">
					<?php
					$result = sql_query('select id,d_name,d_picture,d_scontent,d_date from cms_detail where d_parent in ('.$c_sub.') and d_rec = 1 order by d_order desc , id desc limit 0 , 10');
					while ($row = sql_fetch_array($result)){
					?>
					<div class="x6">
						<div class="wrap mb10">
							<div class="square_img2"><a href="<?php echo d_url($row['id'])?>" target="_blank"><img src="<?php echo $row['d_picture'];?>" title="<?php echo $row['d_name'];?>" alt="<?php echo $row['d_name'];?>"/></a></div>
							<div class="ac cut"><a href="<?php echo d_url($row['id'])?>" target="_blank" title="<?php echo $row['d_name'];?>"><?php echo $row['d_name'];?></a></div>
						</div>
					</div>
					<?php
					}
					?>
					</div>
				</div>
				<div class="hd1">热门<?php echo $c_sname;?></div>
				<div class="bd1">
					<div class="l10 plist">
					<?php
					$result = sql_query('select id,d_name,d_picture,d_scontent,d_date from cms_detail where d_parent in ('.$c_sub.') and d_hot = 1 order by d_order desc , id desc limit 0 , 12');
					while ($row = sql_fetch_array($result)){
					?>
					<div class="x4">
						<div class="wrap mb10 p4">
							<div class="square_img3"><a href="<?php echo d_url($row['id'])?>" target="_blank"><img src="<?php echo $row['d_picture'];?>" title="<?php echo $row['d_name'];?>" alt="<?php echo $row['d_name'];?>"/></a></div>
							<div class="ac cut"><a href="<?php echo d_url($row['id'])?>" target="_blank" title="<?php echo $row['d_name'];?>"><?php echo $row['d_name'];?></a></div>
						</div>
					</div>
					<?php
					}
					?>
					</div>
				</div>
				<?php } ?>
			</div>
			<div class="x9">
				<div id="current_location">当前位置：<a href="index.php">首页</a> > <?php echo $current_location?></div>
				<div id="channel_content"><?php echo $c_content?></div>
				<div class="l20 plist">
					<?php
					$sql = 'select id,d_name,d_picture,d_scontent,d_date from cms_detail where d_parent in ('.$c_sub.') order by d_order desc , id desc';
					$pager = page_handle('page',$c_page,sql_num_rows(sql_query($sql)));
					$result = sql_query($sql.' limit '.$pager[0].','.$pager[1].'');
					while($row = sql_fetch_array($result)){
					?>
					<div class="x3">
						<div class="wrap mb20">
							<div class="square_img"><a href="<?php echo d_url($row['id'])?>" target="_blank"><img src="<?php echo $row['d_picture'];?>" title="<?php echo $row['d_name'];?>" alt="<?php echo $row['d_name'];?>"/></a></div>
							<div class="title cut"><a href="<?php echo d_url($row['id'])?>" target="_blank" title="<?php echo $row['d_name'];?>"><?php echo $row['d_name'];?></a></div>
						</div>
					</div>
					<?php
					}
					?>
				</div>
				<div class="page_show"><?php echo (($system_mode == 2 ) ? page_shows($pager[2],$pager[3],$page,2) : page_show($pager[2],$pager[3],$pager[4],2));?> </div>
			</div>
		</div>
	</div>
</div>
<?php include($dir.$t_path.'inc_footer.php');?>
</body>
</html>
