// 后台js
function check_all(cname) {
	$('input[name="'+cname+'"]:checkbox').each(function(){
		this.checked = !this.checked;
	});
}
$(function(){
	$('#left').waypoint({
		handler: function(direction) {
			if (direction == 'down') {
				$(this.element).addClass('leftfixed');
			} else {
				$(this.element).removeClass('leftfixed');
			}
		}
	});
});