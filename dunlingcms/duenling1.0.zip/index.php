<?php
require 'template/default/new.php';
require 'template/default/nbottom.php';
?>