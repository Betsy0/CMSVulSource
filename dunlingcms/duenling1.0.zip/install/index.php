<title>����Ͷ��ϵͳ - ϵͳ��װ</title>
<meta http-equiv="Content-Type" content="text/html; charset=gbk" />
<link href="../style/install.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="../js/install.js"></script>
<div id="main_title"><span style="padding-left: 15px;font-size: 18px;">&raquo;</span><span style="padding-left: 5px;font-size:14px;font-weight:bold;color: #4F4F4F;">����Ͷ��ϵͳ-��װ��</span><span style="padding-left:430px;">AXPHP Version:5.1</span></div>
<div id="main">
<?php
error_reporting(0);
@$lock = file_exists("../config.php");
if($lock){$disabled = "disabled";}

?>
<form method="post" action="install2.php"  onsubmit="return install(this)">
<table cellpadding="1" cellspacing="5" align="center" width="735">
<tr>
<td colspan="3" height="50" valign="bottom" align="left" style="font-size:16px;font-weight: bold;color: gray;">
&equiv; ���ݿⰲװ����
<hr />
</td>
</tr>

<tr>
<td align="right" width="100">������:</td>
<td align="left" width="300">
<input type="text" class="text" name="server" onkeyup="value=value.replace(/[^\w\.\/]/ig,'')" value="localhost"  /></td>
<td align="left">&nbsp;<span style="font-size: 12px;text-align:left;color: #696969;">��д������IP��ַ,Ĭ��Ϊlocalhost</span></td>
</tr>

<tr>
<td align="right" width="100">�û���:</td>
<td align="left" width="300">
<input type="text" class="text" name="mysqlname" /></td>
<td align="left">&nbsp;<span style="font-size: 12px;text-align:left;color: #696969;">��д MYSQL �û���</span></td>
</tr>

<tr>
<td align="right" width="100">��&nbsp;&nbsp;��:</td>
<td align="left" width="300">
<input type="text" class="text" name="mysqlpass" /></td>
<td align="left">&nbsp;<span style="font-size: 12px;text-align:left;color: #696969;">��д MYSQL ����</span></td>
</tr>

<tr>
<td align="right" width="100">���ݿ�:</td>
<td align="left" width="300">
<input type="text" class="text" name="mysqldb" /></td>
<td align="left">&nbsp;<span style="font-size: 12px;text-align:left;color: #696969;">��д MYSQL ����</span></td>
</tr>

<tr>
<td align="right" width="100">�ַ���:</td>
<td align="left" width="300">
<select name="charset"><option value="GBK">��������</option></select></td>
<td align="left">&nbsp;<span style="font-size: 12px;text-align:left;color: #696969;">Ĭ��Ϊ��������</span></td>
</tr>

<tr>
<td colspan="3" height="50" valign="bottom" align="left" style="font-size:16px;font-weight: bold;color: gray;">
&equiv; ��������
<hr />
</td>
</tr>

<tr>
<td align="right" width="100">��̨�˺�:</td>
<td align="left" width="300">
<input type="text" class="text" name="adminname" /></td>
<td align="left">&nbsp;<span style="font-size: 12px;text-align:left;color: #696969;">��д��̨��¼�˺�</span></td>
</tr>

<tr>
<td align="right" width="100">��̨����:</td>
<td align="left" width="300">
<input class="text" name="adminpass" type="password" /></td>
<td align="left">&nbsp;<span style="font-size: 12px;text-align:left;color: #696969;">��д��̨��¼����</span></td>
</tr>

<input type="hidden" name="key" value="<?php echo time().rand(10000000,99999999);?>"  />

<tr>
<td colspan="3" align="left" height="30" style="padding-left: 125px;">
<input type="submit" class="submit" value="��ʼ��װ" <?php echo $disabled; ?> /></td>
</tr>

</table>
</form>
</div>