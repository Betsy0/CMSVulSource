<?php
require 'template/default/head.php';
require 'template/default/gonggao.php';
require 'template/default/bottom.php';


?>