<?php
require 'template/default/head.php';
require 'template/default/regs.php';
require 'template/default/bottom.php';
?>