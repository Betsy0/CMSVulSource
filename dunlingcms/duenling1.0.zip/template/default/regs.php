<link href="style/reg_main.css" rel="stylesheet" type="text/css" />
<div id="main_title"><span style="padding-left: 15px;font-size: 18px;">&raquo;</span><span style="padding-left: 5px;font-size:14px;font-weight:bold;color: #4F4F4F;">���˻�Աע��</span></div>
<div id="main">
<form method="post" action="regs.php" onsubmit="return MyCPSSubmit()">
<table cellpadding="1" cellspacing="5" align="center" width="735">
<tr>
<td height="50" valign="bottom" align="left" style="font-size:16px;font-weight: bold;color: gray;">
&equiv; ע����Ϣ
<hr />
</td>
</tr>
<tr>
<td align="left" >
<?php
error_reporting(0);
include 'config.php';
$username = $_POST['username'];
$username = strtolower($username);
$username = trim($username);
$userpass = $_POST['userpass1'];
$userpass = $userpass . "Axphp";
$userpass = md5(md5(md5($userpass)));
$qq = $_POST['qq'];
$pay = $_POST['pay'];
$payname = $_POST['payname'];
$payid = $_POST['payid'];
$ip = $_SERVER['REMOTE_ADDR'];
$regchecksql = "select * from axphp_user where username='$username'";
$regcheck = mysql_query($regchecksql, $config);
$regnum = mysql_num_rows($regcheck);
ini_set("date.timezone", "PRC");
$regtime = date("Y-m-d H:i:s");
//�Ƽ����û�����UID
$unions = $_POST['u'];
if ($regnum == 0) {
    $regsql = "insert into axphp_user (username,userpass,qq,pay_name,pay_username,pay_id,unions,regtime,ip) values ('$username','$userpass','$qq','$pay','$payname','$payid','$unions','$regtime','$ip')";
    $xxsql = "update axphp_user set ticheng=ticheng+0.2,money=money+0.2,payn=payn+0.2 where uid='$unions'";
    mysql_query($xxsql,$config);
    mysql_query($regsql, $config);
    print <<< REG
<img src=images/reg1.gif style="float:left;padding-right:20px;"> <span style="clear:right;line-height: 30px;">��ϲ,���ѳɹ�ע���Ϊ���˻�Ա!<br />
3���Ϊ����ת����¼����,�粻����ת,����<a href="login.php" style="text-decoration:none;color:#FF0000;">��¼</a></span>
REG;
    HEADER("refresh:3;url=login.php");
} elseif ($regnum >= 1) {
    print <<< REG
<img src=images/reg0.gif style="float:left;padding-right:20px;"> <span style="clear:right;line-height: 50px;font-size:14px;">��Ǹ,�����˺��Ѿ���ע��,�뷵������ע��!<br />
<script>
window.onload=function a(){
    alert('�Բ���,����û����ѱ�ע��,������ѡ���û�������ע��');history.back();
    }
    </script>
REG;
}
?>
</td>
</tr>
</table>
</form>
</div>