<div id="bottom"><div class="txt"><?php echo $axphp['bottom'];?></div>
<img src="images/cx.png" style="margin-top: 15px;" /><img src="images/sign.png" style="margin-top: 15px;margin-left:20px;" /><img src="images/v.png" style="margin-top: 15px;margin-left:20px;" />
</div>
</body>