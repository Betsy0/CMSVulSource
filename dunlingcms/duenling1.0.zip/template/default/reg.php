<link href="style/reg_main.css" rel="stylesheet" type="text/css" />
<script language="javascript" src="js/reg.js"></script>
<div id="main_title"><span style="padding-left: 15px;font-size: 18px;">&raquo;</span><span style="padding-left: 5px;font-size:14px;font-weight:bold;color: #4F4F4F;">���˻�Աע��</span></div>
<div id="main">

<?php
isset($_GET['u'])?$u=$_GET['u']:$u=0;
?>
<form method="post" action="regs.php"  onsubmit="return checksearch(this)">
<table cellpadding="1" cellspacing="5" align="center" width="735">
<tr>
<td colspan="3" height="50" valign="bottom" align="left" style="font-size:16px;font-weight: bold;color: gray;">
&equiv; �˻���Ϣ
<hr />
</td>
</tr>

<tr>
<td align="right" width="100">��¼�˺�:</td>
<td align="left" width="300">
<input class="text" name="username" onkeyup="value=value.replace(/[^\w\.\/]/ig,'')" maxlength="16" onmouseover="this.style.backgroundColor='#F0F8FF';this.style.border='1px solid #7F9DB9';this.style.width='252px';this.style.height='27px'" 
onmouseout="this.style.backgroundColor='#FFFFFF';this.style.border='1px solid';" /></td>
<td align="left"><span style="font-size: 12px;text-align:left;color: #FF0000;">* ����</span>&nbsp;<span style="font-size: 12px;text-align:left;color: #696969;">���ȴ���4λ��С��16λ��ֻ������ĸ���������</span></td>
</tr>

<tr>
<td align="right" width="100">��¼����:</td>
<td align="left"><input class="text" type="password" name="userpass1"  maxlength="16" onmouseover="this.style.backgroundColor='#F0F8FF';this.style.border='1px solid #7F9DB9';this.style.width='252px';this.style.height='27px'" 
onmouseout="this.style.backgroundColor='#FFFFFF';this.style.border='1px solid';" /></td>
<td align="left"><span style="font-size: 12px;text-align:left;color: #FF0000;">* ����</span>&nbsp;<span style="font-size: 12px;text-align:left;color: #696969;">���ȴ���4λ��С��16λ</td>
</tr>

<tr>
<td align="right" width="100">�ظ�����:</td>
<td align="left"><input class="text" type="password" name="userpass2"  maxlength="16" onmouseover="this.style.backgroundColor='#F0F8FF';this.style.border='1px solid #7F9DB9';this.style.width='252px';this.style.height='27px'" 
onmouseout="this.style.backgroundColor='#FFFFFF';this.style.border='1px solid';" /></td>
<td align="left"><span style="font-size: 12px;text-align:left;color: #FF0000;">* ����</span>&nbsp;<span style="font-size: 12px;text-align:left;color: #696969;">���ٴ���������</td>

</tr>

<tr>
<td align="right" width="100">QQ����:</td>
<td align="left"><input class="text" name="qq" onkeyup="value=value.replace(/[^\d]/g,'') " onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))" maxlength="10" onmouseover="this.style.backgroundColor='#F0F8FF';this.style.border='1px solid #7F9DB9';this.style.width='252px';this.style.height='27px'" 
onmouseout="this.style.backgroundColor='#FFFFFF';this.style.border='1px solid';" /></td>
<td align="left"><span style="font-size: 12px;text-align:left;color: #FF0000;">* ����</span>&nbsp;<span style="font-size: 12px;text-align:left;color: #696969;">�����볣��QQ����,���ȴ���5λ,С��10λ</td>

</tr>

<tr>
<td colspan="3" height="50" valign="bottom" align="left" style="font-size:16px;font-weight: bold;color: gray;">
&equiv; �տ���Ϣ
<hr />
</td>
</tr>

<tr>
<td align="right" width="100">�տʽ:</td>
<td align="left">

<select name="pay" >
<?php
require("config.php");
$paynamessql = "select pay from axphp_paynames";
$payery = mysql_query($paynamessql,$config);
while($payar = mysql_fetch_array($payery))
{
    echo "<option value=\"$payar[0]\">";
    echo $payar['pay'];
    echo "</option>";
   
}
?>

</select>

</td>
<td style="font-size: 12px;text-align:left;color: #696969;">
��ѡ���ʺ������տʽ,�Ƽ�ʹ��֧������Ƹ�ͨ</td>
</tr>

<tr>
<td align="right" width="100">�տ�����:</td>
<td align="left"><input class="text" name="payname" onkeyup="value=value.replace(/[^\u4E00-\u9FA5]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\u4E00-\u9FA5]/g,''))" onmouseover="this.style.backgroundColor='#F0F8FF';this.style.border='1px solid #7F9DB9';this.style.width='252px';this.style.height='27px'" 
onmouseout="this.style.backgroundColor='#FFFFFF';this.style.border='1px solid';" /></td>
<td style="font-size: 12px;text-align:left;color: #696969;">
����ȷ��д�տ�������,��д���󽫿��ܵ����޷�֧��
</td>
</tr>

<tr>
<td align="right" width="100">�տ��˺�:</td>
<td align="left"><input class="text" name="payid" onmouseover="this.style.backgroundColor='#F0F8FF';this.style.border='1px solid #7F9DB9';this.style.width='252px';this.style.height='27px'" 
onmouseout="this.style.backgroundColor='#FFFFFF';this.style.border='1px solid';" /></td>
<td style="font-size: 12px;text-align:left;color: #696969;">
����ȷ��д�տ��˺�
</td>
</tr>

<tr>
<td colspan="3" align="left" height="30" style="padding-left: 125px;">
<input name="axphp" type="checkbox" checked="" disabled="" />�����Ķ�����ͬ����վ���˺���Э��</td>
</tr>


<tr>
<td colspan="3" align="left" height="30" style="padding-left: 125px;">
<input type="hidden" value="<?php echo $u;?>" name="u" />
<input type="submit" class="submit" value="�ύע��" /></td>
</tr>

</table>

</form>
</div>