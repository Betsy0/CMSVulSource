<div id="bottom"><div class="txt"><?php echo $axphp['bottom'];?></div>
</div>
</body>