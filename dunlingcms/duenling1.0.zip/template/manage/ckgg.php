<div id="user_main">
<div id="left">
<?php require 'left.php'; ?>
</div>
<div id="right">
<div id="right_top"><div style="padding-top:5px;padding-left:10px;"><a href="user.php">��Ա����</a> - <a href="gonggao.php">ϵͳ����</a> - �鿴����</div></div>
<div id="urltop" style="text-align: left;">
</div>
<div id="right_main" style="color: #000000;overflow: scroll;overflow-x: hidden;">
<?php
isset($_GET['id'])?$id=$_GET['id']:$id=null;

$ggsql = "select * from axphp_gonggao where id = '$id'";
$query = mysql_query($ggsql, $config);
$gg = mysql_fetch_array($query);
?>
<table width="760" cellpadding="5" cellspacing="1" bgcolor="silver">
<tr bgcolor="#F3F3F3">
<td width="100">�������:</td>
<td align="left"><span style="color: #1766E8;font-size:14px;"><?php echo $gg['title']; ?></span></td>
</tr>

<tr bgcolor="#F3F3F3">
<td width="100">����ʱ��:</td>
<td align="left"><span style="color: #1766E8;font-size:14px;"><?php echo $gg['datetime']; ?></span></td>
</tr>

<tr bgcolor="#F3F3F3">
<td width="100">��������:</td>
<td align="left"><span style="color: #1766E8;font-size:14px;"><?php echo $gg['content']; ?></span></td>
</tr>

<tr bgcolor="#F3F3F3">
<td width="100">����:</td>
<td align="left">
<button onclick="location.href='gonggao.php'">����</button>
</td>
</tr>
</table></form>
<br />

</div></div></div>