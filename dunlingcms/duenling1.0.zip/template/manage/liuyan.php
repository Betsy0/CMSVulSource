<div id="user_main">
<div id="left">
<?php require 'left.php'; ?>
</div>
<div id="right">
<div id="right_top"><div style="padding-top:5px;padding-left:10px;"><a href="user.php">��Ա����</a> - վ�ڶ�������ϵͳ</div></div>
<div id="urltop" style="text-align: left;">
</div>
<div id="right_main" style="color: #000000;overflow: scroll;overflow-x: hidden;">
<script src="../js/liuyan.js"></script>
<?php
$jiu_userpass = "select * from axphp_user where username = '$user'";
$query = mysql_query($jiu_userpass, $config);
$ulsghgvo = mysql_fetch_array($query);
$u_qq = $ulsghgvo['qq'];
$u_dizhi = $ulsghgvo['dizhi'];
$u_youbian = $ulsghgvo['youbian'];
$u_dianhua = $ulsghgvo['dianhua'];
$u_shenfenzheng = $ulsghgvo['shenfenzheng'];
isset($_SERVER['QUERY_STRING'])?$post=$_SERVER['QUERY_STRING']:null;

?>
<table width="760" cellpadding="5" cellspacing="0">
<form method="post" action="?post" onsubmit="return liuyan(this);" >
<tr>
<td width="100">���Ͷ���:</td>
<td align="left"><select style="width: 150px;"><option>����Ա</option></select> </td>
</tr>

<tr>
<td width="100">��������:</td>
<td align="left"><select name="dxlx" style="width: 150px;"><option value="��ѯ">��ѯ</option><option value="����">����</option><option value="����">����</option></select> </td>
</tr>

<tr>
<td width="100">���ű���:</td>
<td align="left"><input type="text" name="title" style="width: 500px;height:20px;color: #FF0000;line-height: 20px;"  maxlength="30" /> </td>
</tr>


<tr>
<td width="100">��������:</td>
<td align="left"><textarea name="content" style="width: 500px;height:220px"></textarea> </td>
</tr>

<tr>
<td width="100">��������:</td>
<td align="left"><input type="radio" name="lx" value="��ͨ" checked="" />��ͨ  <input type="radio" name="lx" value="����" /><span style="color: #FF0000;">����</span></td>
</tr>

<tr>
<td width="100"></td>
<td align="left"><input  type="submit" value="��������" style="width:120px;height:30px;font-size:14px;color: #004182;" /></td>
</tr>
</table></form>

<br />
<?php
if($post=="post") 
{
$title=$_POST['title'];
$dxlx = $_POST['dxlx'];
$content = $_POST['content'];
$lx = $_POST['lx'];
ini_set("date.timezone","PRC");
$datetime=date("Y-m-d H:i:s");
$dxsql = "insert into axphp_liuyan (username,title,content,datetime,leixing,jinji) values ('$user','$title','$content','$datetime','$dxlx','$lx')";
$ok = mysql_query($dxsql,$config);
mysql_close($config);
if($ok)
{
    echo "<script>window.onload=function upinfo(){alert('��л��������,���ǽ���һ���������ڽ��лظ�!');location.href='my_liuyan.php'}</script>";
}
else
{
    echo "<script>window.onload=function upinfo(){alert('ϵͳ����,����ϵ����Ա!');location.href='liuyan.php';}</script>";
}
}
?>
</div></div></div>