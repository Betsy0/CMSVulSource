<div id="user_main">
<div id="left">
<?php require 'left.php'; ?>
</div>
<div id="right">
<div id="right_top"><div style="padding-top:5px;padding-left:10px;"><a href="user.php">��Ա����</a> - ��������</div></div>
<div id="urltop" style="text-align: left;">
</div>
<div id="right_main" style="color: #000000;overflow: scroll;overflow-x: hidden;">
<?php

$id = $_GET['id'];
$sql = "select * from axphp_text where username = '$user' and id='$id'";
$ery = mysql_query($sql,$config);
$row = mysql_fetch_array($ery);
$num = mysql_num_rows($ery);
if($num<"1"){
     echo "<script>window.onload=function uppass(){alert('�Ƿ�����');location.href='urls.php';}</script>";
}

?>
<table width="750" cellpadding="5" cellspacing="1" bgcolor="silver"  style ="table-layout:fixed;">
<tr bgcolor="#F3F3F3">
<td width="100">�������:</td>
<td align="left" width="650"><?php echo $row['title'];?></a></td>
</tr>

<tr bgcolor="#F3F3F3">
<td width="100">�������:</td>
<td align="left" width="650"><?php echo $row['texts'];?></td>
</tr>
<tr>
<td></td>
<td><button onclick="javascript:history.go(-1);">����</button></td>
</tr>
</table>
</div></div></div>