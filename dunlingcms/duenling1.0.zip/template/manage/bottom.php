<div id="bottom">
<div style="padding-top: 20px;">
Copyright &copy; 2008-2012 <?php echo $_SERVER['HTTP_HOST'];?>
</div>
</div>