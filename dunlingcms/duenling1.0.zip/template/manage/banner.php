<div id="banner">
<div style="padding-left:12px;line-height: 40px;">
<?php
require '../config.php';
require '../setting.php';
$jifensql = "select * from axphp_user where username='$user'";
$jifenery = mysql_query($jifensql,$config);
$jifenrow = mysql_fetch_array($jifenery);
$jifen = $jifenrow['jifen'];
$lock = $jifenrow['userlock'];
$yue = $jifenrow['payn'];
if($lock=="1")
{
    $locks='<span style="color: #00A82B;">�Ѽ���</span>';
}
else
{
    $locks='<span style="color: #FF0000;">������</span>';
}?>
��¼�û�:<span style="color: #FF0000;"><?php echo $user;?></span> | �˺�״̬:<?php echo $locks;?></span> |  �ҵ����: <span style="color: #FF0000;"><?php echo $yue;?></span>&nbsp;<?php echo $axphp['moneyname']?> </span>

</div>
</div>