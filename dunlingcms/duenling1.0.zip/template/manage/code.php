<div id="user_main">
<div id="left">
<?php require 'left.php'; ?>
</div>
<script type="text/javascript" src="../js/codecopy.js"></script>

<div id="right">
<div id="right_top"><div style="padding-top:5px;padding-left:10px;"><a href="user.php">��Ա����</a> - ��ȡ������</div></div>
<div id="urltop" style="text-align: left;">
<button style="width: 200px;height:20px;border: 1px solid  #2A2A2A;background-color:#FFFFFF;font-size:12px;" onclick="location.href='?price=order+by+prices+desc'">�۸��ɸ�����</button>&nbsp;<button style="width: 200px;height:20px;border: 1px solid  #2A2A2A;background-color:#FFFFFF;font-size:12px;" onclick="location.href='?price=order+by+prices+asc'">�۸��ɵ�����</button>
</div>
<div id="right_main" style="color: #000000;overflow: scroll;overflow-x: hidden;">

<?php
isset($_GET['price'])?$desc=$_GET['price']:$desc=null;
$useridsql = "select * from axphp_user where username = '$user'";
$query = mysql_query($useridsql, $config);
$ulsghgvo = mysql_fetch_array($query);
$uid = $ulsghgvo['uid'];//��ȡ�û���UID��.

$adsql = "select * from axphp_ad where open = '1' and consumption < zonge $desc";
$adery = mysql_query($adsql,$config);
$adnum = mysql_num_rows($adery);
if($adnum=="0")
{
    echo  "��ʱû�й���ϼܣ�";
}
while($ad = mysql_fetch_array($adery))
{
    ?>
<table width="680" cellpadding="5" cellspacing="1" bgcolor="silver"  style="margin-top: 2px;">
<tr bgcolor="#F3F3F3">
<td width="70">�����:</td>
<td align="left"><?php echo $ad['id'];?></td>
</tr>

<tr bgcolor="#F3F3F3">
<td width="70">��浥��:</td>
<td align="left"><span style="color: #FF0000;"><?php echo $ad['prices'];?></span> Ԫ</td>
</tr>

<tr bgcolor="#F3F3F3">
<td width="70">������:</td>
<td align="left"><textarea style="width:580px;height:30px;" onclick="oCopy(this)">
<a href="<?php echo $axphp['domain'];?>/ax?uid=<?php echo $uid;?>&ad=<?php echo $ad['id'];?>" target="_blank"><?php echo $ad['title'];?></a></textarea></td>
</tr>
</table>
<?php
}
?>
</div></div></div>