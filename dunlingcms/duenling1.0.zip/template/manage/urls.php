<div id="user_main">
<div id="left">
<?php require 'left.php'; ?>
</div>


<div id="right">
<div id="right_top"><div style="padding-top:5px;padding-left:10px;"><a href="user.php">��Ա����</a> - �ҵĸ��</div></div>
<div id="urltop" style="text-align: left;">
</div>
<div id="right_main" style="color: #000000;overflow: hidden;overflow-x: hidden;">

<?php
$m = "16"; //ÿҳ��ʾ�ļ�¼��
$numsql = "select * from axphp_text where username ='$user'";
$numery = mysql_query($numsql, $config);
$lognum = mysql_num_rows($numery); //�ܼ�¼��
$zy = (int)(($lognum - 1) / $m) + 1; //��ҳ��
isset($_GET['page']) ? $page = $_GET['page'] : $page = "1"; //��ǰҳ��
$one = (int)($page - 1) * $m; //��ǰҳ��������¼


$logsql = "select * from axphp_text where username ='$user' order by id asc limit $one,$m ";
$logery = mysql_query($logsql, $config);
echo '<table cellpadding="5" cellspacing="1" width="780"  bgcolor="#3573AB"><tr bgcolor="#E0ECF5" style="color:#173046"; ><th align="left">�������</th><th align="left">�ύʱ��</th><th align="left">������</th><th align="left">���״̬</th></tr>';
while ($log = mysql_fetch_array($logery)) {
    $titles = $log['title'];
    $uid = $log['id'];
    echo '<tr bgcolor="#E7E7E7" >';
    echo '<td>';
    echo "<a href=gaojian.php?id=$uid>";
    echo mb_substr($titles, 0, 30, 'GBK');
    echo '</a></td>';
    echo '<td>' . $log['datetime'] . '</td>';

    echo '<td>' . $log['money'] . '</td>';
    echo '<td>';


    if ($log['shenhe'] == "0") {
        echo "<span style=color:#00458A;>�����</span>";
    } elseif($log['shenhe'] == "1") {
        echo "<span style=color:#FF0000;>��ͨ��</span>";
    }else{
        echo "<span style=color:#000000;>δͨ��</span>";
    }

    echo '</td>';
    echo '</tr>';
}

?>
</table>
<?php
if ($lognum == "0") {
    echo "<p>����ʱû���ύ�κθ����</p>";
}
?>

 <style type="text/css">
 .pagelink
 {
float: right;
width:555px;
 
 }
.pagelink a
{
 color: #18344E;
}
.pagelink a:hover
{
 color: #BF0000;

}
 </style>
 <div style="padding-top: 10px;">
 <div style="float: left;">Page:<span style="color: #FF0000;"><?php echo $page; ?></span>/<span style="color: #FF0000;"><?php echo
$zy; ?></span> | Record:<span style="color: #FF0000;"><?php echo
$lognum; ?></span></div>
 <div class="pagelink">
<?php
if ($page > "1") {
    echo '<a href=?page=1>��ҳ</a>';
    echo "&nbsp;";
    echo '<a href=?page=' . ($page - 1) . '>��һҳ</a>';
}

if ($zy > $page) {
    echo "&nbsp;";
    echo '<a href=?page=' . ($page + 1) . '>��һҳ</a>';
    echo "&nbsp;";
    echo '<a href=?page=' . ($zy) . '>βҳ</a>';
}


?>

</div>
 </div>

</div></div></div>