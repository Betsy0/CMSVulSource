<div id="user_main">
<div id="left">
<?php require 'left.php'; ?>
</div>
<div id="right">
<div id="right_top"><div style="padding-top:5px;padding-left:10px;"><a href="user.php">��Ա����</a> - <a href="my_liuyan.php">��������</a> - �鿴�ظ�</div></div>
<div id="urltop" style="text-align: left;">
</div>
<div id="right_main" style="color: #000000;overflow: scroll;overflow-x: hidden;">
<script src="../js/pay.js"></script>
<script src="../js/delhf.js"></script>
<?php
isset($_GET['id'])?$id=$_GET['id']:$id=0;
isset($_GET['del'])?$del=$_GET['del']:$del=null;
$hfsql = "select * from axphp_liuyan where username = '$user' and id='$id'";
$query = mysql_query($hfsql, $config);
$hf = mysql_fetch_array($query);



if($del!==null)
{
    $delsql = "delete from axphp_liuyan where username='$user' and id='$del'";
    $delok = mysql_query($delsql,$config);
    if($delok)
    {
    echo "<script>window.onload=function uppass(){alert('ɾ���ɹ�!');location.href='my_liuyan.php';}</script>";
    }
    else
    {
    echo "<script>window.onload=function uppass(){alert('�������,����ϵ����Ա!');location.href='my_liuyan.php';}</script>";
    }
    
}

?>
<table width="760" cellpadding="5" cellspacing="1" bgcolor="silver">
<tr bgcolor="#F3F3F3">
<td width="100">���ű���:</td>
<td align="left"><span style="color: #1766E8;font-size:14px;"><?php echo $hf['title']; ?></span></td>
</tr>

<tr bgcolor="#F3F3F3">
<td width="100">��������:</td>
<td align="left"><span style="color: #1766E8;font-size:14px;"><?php echo $hf['content']; ?></span></td>
</tr>

<tr bgcolor="#F3F3F3">
<td width="100">��������:</td>
<td align="left"><span style="color: #1766E8;font-size:14px;"><?php echo $hf['leixing']; ?></span></td>
</tr>

<tr bgcolor="#F3F3F3">
<td width="100">����ʱ��:</td>
<td align="left"><span style="color: #1766E8;font-size:14px;"><?php echo $hf['datetime']; ?></span></td>
</tr>


<tr bgcolor="#F3F3F3">
<td width="100">�ظ�ʱ��:</td>
<td align="left"><span style="color: #1766E8;font-size:14px;"><?php echo $hf['hfdatetime']; ?></span></td>
</tr>


<tr bgcolor="#F3F3F3">
<td width="100">����Ա�ظ�:</td>
<td align="left"><span style="color: #008421;font-size:14px;"><?php echo $hf['hfcontent']; ?></span></td>
</tr>


<tr bgcolor="#F3F3F3">
<td width="100">����:</td>
<td align="left">
<button onclick="location.href='my_liuyan.php'">����</button>

<button onclick="location.href='?id=<?php echo $_GET['id'];?>&del=<?php echo $_GET['id'];?>';return del();">ɾ��</button>

</td>
</tr>
</table></form>
<br />

</div></div></div>