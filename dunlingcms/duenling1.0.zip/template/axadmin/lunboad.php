<div id="user_main">
<div id="left">
<?php require 'left.php'; require '../setting.php'; require '../config.php'; ?>
</div>
<div id="right">
<div id="right_top"><div style="padding-top:5px;padding-left:10px;">��̨���� - �ֲ�������</div></div>
<div id="right_main" style="color: #000000;overflow: hidden;overflow-x: hidden;">
<script type="text/javascript" src="../lhgdialog/lhgcore.min.js"></script> 
<script type="text/javascript" src="../lhgdialog/lhgdialog.min.js"></script>
<script type="text/javascript">

function opdg(id)
{
    var DG = new J.dialog({
		page:'lunboupdatead.php?id=' + id,
        title:'�޸Ĺ������',
        height:'350',
        width:'550',
        cancelBtn:false,
        resize:false,
        iconTitle:false,
        maxBtn:false,
        btnBar:false,
        onXclick:axoutauto,
        cover:true
	});
	DG.ShowDialog();
}

function delad(id)
{
    var DG = new J.dialog({
		page:'dellunbo.php?id=' + id,
        title:'ɾ�����',  
        height:'150',
        width:'350',
        cancelBtn:false,
        resize:false,
        iconTitle:false,
        maxBtn:false,
        cover:true,
        onXclick:axoutauto
	});
	DG.ShowDialog();
}

function adxj(id)
{
    var DG = new J.dialog({
		page:'lunboxj.php?id=' + id,
        title:'����¼�',  
        height:'150',
        width:'350',
        cancelBtn:false,
        resize:false,
        iconTitle:false,
        maxBtn:false,
        cover:true,
        onXclick:axoutauto
	});
	DG.ShowDialog();
}

function adsj(id)
{
    var DG = new J.dialog({
		page:'lunbosj.php?id=' + id,
        title:'����ϼ�',  
        height:'150',
        width:'350',
        cancelBtn:false,
        resize:false,
        iconTitle:false,
        maxBtn:false,
        cover:true,
        onXclick:axoutauto
	});
	DG.ShowDialog();
}

function axoutauto(){
history.go(0);
location.href='lunboad.php';
}
</script>

<?php
$m="13";//ÿҳ��ʾ�ļ�¼��
$numsql = "select * from axphp_lunbo";
$numery = mysql_query($numsql,$config);
$lognum = mysql_num_rows($numery);//�ܼ�¼��
$zy = (int)(($lognum-1)/$m)+1;//��ҳ��
isset($_GET['page'])?$page=$_GET['page']:$page="1";//��ǰҳ��
$one = (int)($page-1)*$m;//��ǰҳ��������¼


$adsql = "select * from axphp_lunbo order by id asc limit $one,$m ";
$adery = mysql_query($adsql,$config);
echo '<table cellpadding="5" cellspacing="1" width="780"  bgcolor="#3573AB"><tr bgcolor="#E0ECF5" style="color:#173046"; ><th align="left" width="70">�����</th><th align="center">���״̬</th><th align="left">��浥��</th><th align="left">�������</th><th align="left">���Ľ��</th><th align="left">����޶�</th><th width="220" align="center">��������</th></tr>';
while($ad=mysql_fetch_array($adery))
{
echo '<tr bgcolor="#E7E7E7" >';
echo '<td>'.$ad['id'].'</td>';
echo '<td align="center">';

if($ad['open']=="1"){
    echo "<span style='color:#009726;'>�ƹ���</span>";
    }
    elseif($ad['open']=="0")
    {
    echo "<span style='color:#FF0000;'>���¼�</span>";
    }

echo '</td>';
echo '<td>'.$ad['prices']."&nbsp;".$axphp['moneyname'].'</td>';
echo '<td>'.$ad['ipnumber'].'</td>';
echo '<td>'.$ad['consumption']."&nbsp;".$axphp['moneyname'].'</td>';
echo '<td>'.$ad['zonge']."&nbsp;".$axphp['moneyname'].'</td>';
echo '<td width="220" align="center"><button style="line-height: 22px;width: 60px;height:23px;background-color: #FFFFFF;border:#004A6F solid 1px;font-size:12px;color: #005279;" class="runcode" value="1" id="'.$ad['id'].'"onclick="opdg(this.id);">�޸�</button>'.'&nbsp;';
if($ad['open']=="1")
{
echo '<button style="line-height: 22px;width: 60px;height:23px;background-color: #FFFFFF;border:#004A6F solid 1px;font-size:12px;color: #FF0000;" class="runcode" value="1" id="'.$ad['id'].'" onclick="if(confirm(\'�Ƿ�ȷ���¼�?\'))adxj(this.id);">�¼�</button>'.'&nbsp;';
}
else
{
echo '<button style="line-height: 22px;width: 60px;height:23px;background-color: #FFFFFF;border:#004A6F solid 1px;font-size:12px;color: #006A1B;" class="runcode" value="1" id="'.$ad['id'].'" onclick="if(confirm(\'�Ƿ�ȷ���ϼ�?\'))adsj(this.id);">�ϼ�</button>'.'&nbsp;';
}
echo '<button style="line-height: 22px;width: 60px;height:23px;background-color: #FFFFFF;border:#004A6F solid 1px;font-size:12px;color: #004A6F;" class="runcode" value="1" id="'.$ad['id'].'" onclick="if(window.confirm(\'�Ƿ�ȷ��ɾ��?\'))delad(this.id);">ɾ��</button>'.'</td>';

echo '</tr>';
}

?>
</table>
<?php
if($lognum=="0")
{
    echo "<p>��ʱû�й���¼��</p>";
}
?>

 <style type="text/css">
 .pagelink
 {
float: right;
width:555px;
 
 }
.pagelink a
{
 color: #18344E;
}
.pagelink a:hover
{
 color: #BF0000;

}
 </style>
 <div style="padding-top: 10px;">
 <div style="float: left;">Page:<span style="color: #FF0000;"><?php echo $page;?></span>/<span style="color: #FF0000;"><?php echo $zy;?></span> | Record:<span style="color: #FF0000;"><?php echo $lognum;?></span></div>
 <div class="pagelink">
<?php
if($page > "1")
{
    echo '<a href=?page=1>��ҳ</a>';
    echo "&nbsp;";
    echo '<a href=?page='.($page-1).'>��һҳ</a>';
}

if($zy>$page)
{
    echo "&nbsp;";
    echo '<a href=?page='.($page+1).'>��һҳ</a>';
    echo "&nbsp;";
    echo '<a href=?page='.($zy).'>βҳ</a>';
}


?>

</div>

 
 </div>

</div></div></div>