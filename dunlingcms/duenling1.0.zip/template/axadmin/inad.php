<div id="user_main">
<div id="left">
<?php require 'left.php'; require '../setting.php'; ?>
</div>


<div id="right">
<div id="right_top"><div style="padding-top:5px;padding-left:10px;">��̨���� - �������</div></div>
<div id="right_main">

<?php
isset($_SERVER['QUERY_STRING'])?$post=$_SERVER['QUERY_STRING']:null;
require '../config.php';
if ($keya1 != $keyb)
{
    $lbadlock = "disabled=\"\"";
}else{
    $lbadlock = null;
}
if($post=="post")
{
$title = $_POST['title'];
$prices = $_POST['prices'];
$url = $_POST['url'];
$zonge = $_POST['zonge'];
$lunbo = $_POST['lunbo'];
if($lunbo=="1"){
    $bm = "axphp_lunbo";
    $headergo = "lunboad.php";
}
else{
    $bm = "axphp_ad";
    $headergo = "upad.php";
}
$inadsql = "insert into $bm (title,url,prices,zonge) values ('$title','$url','$prices','$zonge')";
$inadok = mysql_query($inadsql,$config);
if($inadok)
{
echo "<script>window.onload=function inadokjs(){alert('���ѳɹ�����һ�����');location.href='".$headergo."'}</script>";
}
else
{
echo "<script>window.onload=function inadokjs(){alert('���ݿ��������!');}</script>";
}

}
?>


<script src="../js/inad.js"></script>
<table width="780" cellpadding="8" cellspacing="1" bgcolor="silver">
<form method="post" action="?post" onsubmit="return inad(this);" >
<tr bgcolor="#ffffff">
<td width="100"  align="right">������:</td>
<td align="left"><input name="title" style="width: 300px;height:20px;background-color: #F0F8FF;border: #7F9DB9 solid 1px;line-height: 20px;" /></td>
</tr>

<tr bgcolor="#ffffff">
<td align="right">��浥��:</td>

<td align="left"><input onkeyup="value=value.replace(/[^\d.]/g,'')"  name="prices" style="color:#FF0000;width: 60px;height:20px;background-color: #F0F8FF;border: #7F9DB9 solid 1px;line-height: 20px;" />&nbsp;<?php echo $axphp['moneyname']?></td>

</tr>

<tr bgcolor="#ffffff">
<td align="right">�ƹ���ַ: </td>

<td align="left"><input name="url" value="http://" style="width: 300px;height:20px;background-color: #F0F8FF;border: #7F9DB9 solid 1px;line-height: 20px;" />&nbsp; ��ʾ: ��ַǰ������ http://</td>
</tr>
<tr bgcolor="#ffffff">
<td align="right">����޶�: </td>
<td align="left"><input onkeyup="value=value.replace(/[^\d.]/g,'')"  name="zonge" style="color:#FF0000;width: 60px;height:20px;background-color: #F0F8FF;border: #7F9DB9 solid 1px;line-height: 20px;" />&nbsp;<?php echo $axphp['moneyname']?></td>
</tr>
<tr bgcolor="#ffffff">
<td align="right">�����ֲ�:</td>

<td align="left"><input type="radio" name="lunbo" value="1" <?php echo $lbadlock;?>  />��&nbsp;&nbsp;&nbsp;<input type="radio" name="lunbo" value="0" checked=""  />��<?php if($keya1!=$keyb){echo '<span style="padding-left: 30px;color:red;font-size:12px;">��ʽ��������ֲ�����</span>';}?></td>

</tr>

<tr bgcolor="#ffffff">
<td align="left" colspan="2" style="padding-left: 120px;" >
<button type="submit" style="width: 100px;height:28px;background-color: #FFFFFF;border:#004D00 solid 1px;font-size:14px;color: #004D00;" ><img src="../images/inad.gif"  />&nbsp;�������</button>
</td>

</tr>

</form>

</table>

</div>





</div>
</div>