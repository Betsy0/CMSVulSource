<div id="user_main">
<div id="left">
<?php require 'left.php'; require '../setting.php'; require '../config.php'; ?>
</div>
<div id="right">
<div id="right_top"><div style="padding-top:5px;padding-left:10px;">��̨���� - ��ԱͶ�����</div></div>
<div id="right_main" style="color: #000000;overflow: hidden;overflow-x: hidden;">
<script type="text/javascript" src="../lhgdialog/lhgcore.min.js"></script> 
<script type="text/javascript" src="../lhgdialog/lhgdialog.min.js"></script>
<script type="text/javascript">

function shenhe(id)
{
    var DG = new J.dialog({
		page:'shenhe.php?id=' + id,
        title:'������',
        height:'620',
        width:'780',
        cancelBtn:false,
        resize:false,
        iconTitle:false,
        maxBtn:false,
        btnBar:false,
        onXclick:axoutauto,
        cover:true
	});
	DG.ShowDialog();
}


function caina(id)
{
    var DG = new J.dialog({
		page:'caina.php?id=' + id,
        title:'���ɸ��',  
        height:'150',
        width:'350',
        cancelBtn:false,
        resize:false,
        iconTitle:false,
        maxBtn:false,
        cover:true,
        onXclick:axoutauto
	});
	DG.ShowDialog();
}

function delad(id)
{
    var DG = new J.dialog({
		page:'delgaojian.php?id=' + id,
        title:'ɾ�����',  
        height:'150',
        width:'350',
        cancelBtn:false,
        resize:false,
        iconTitle:false,
        maxBtn:false,
        cover:true,
        onXclick:axoutauto
	});
	DG.ShowDialog();
}

function axoutauto(){
history.go(0);
location.href='upad.php';
}
</script>

<?php
$m="13";//ÿҳ��ʾ�ļ�¼��
$numsql = "select * from axphp_text";
$numery = mysql_query($numsql,$config);
$lognum = mysql_num_rows($numery);//�ܼ�¼��
$zy = (int)(($lognum-1)/$m)+1;//��ҳ��
isset($_GET['page'])?$page=$_GET['page']:$page="1";//��ǰҳ��
$one = (int)($page-1)*$m;//��ǰҳ��������¼


$adsql = "select * from axphp_text order by id desc limit $one,$m ";
$adery = mysql_query($adsql,$config);
echo '<table cellpadding="5" cellspacing="1" width="780"  bgcolor="#3573AB"><tr bgcolor="#E0ECF5" style="color:#173046"; ><th align="center" width="300">�������</th><th align="center">�ύʱ��</th><th align="center">���Ž��</th><th align="center">���״̬</th><th align="center">����״̬</th></tr>';
while($ad=mysql_fetch_array($adery))
{
    $title = $ad['title'];
    $title =  mb_substr($title, 0, 20, 'GBK');
echo '<tr bgcolor="#E7E7E7" >';
echo '<td>';

echo '<a onclick="shenhe(this.id);" id="'.$ad['id'].'" >';;
echo $title;
echo '</a></td>';
echo '<td align="center">'.$ad['datetime'].'</td>';

echo '<td align="center">'.$ad['money'].'</td>';
echo '<td align="center">';

if($ad['shenhe']=="0"){
    echo "<span style='color:#009726;'>�����</span>";
    }
    elseif($ad['shenhe']=="1")
    {
    echo "<span style='color:#FF0000;'>��ͨ��</span>";
    }else{
    echo "<span style='color:#000000;'>δͨ��</span>";
    }

echo '</td>';
echo '<td align="center">';

if($ad['caina']=="0")
{
echo '<button style="line-height: 22px;width: 45px;height:23px;background-color: #FFFFFF;border:#004A6F solid 1px;font-size:12px;color: #FF0000;" class="runcode" value="1" 

id="'.$ad['id'].'" onclick="if(confirm(\'�Ƿ�ȷ������?\'))caina(this.id);">����</button>'.'&nbsp;';

echo '<button style="line-height: 22px;width: 45px;height:23px;background-color: #FFFFFF;border:#004A6F solid 1px;font-size:12px;color: #004A6F;" class="runcode" value="1" id="'.$ad['id'].'" onclick="if(window.confirm(\'ɾ���󲻿ɻָ�,�Ƿ�ȷ��ɾ��?\'))delad(this.id);">ɾ��</button>';
}
else
{
    echo "<span style='color:blue;font-size:12px;'>�Ѳ���</span>";
}

echo '</td>';


echo '</tr>';
}

?>
</table>
<?php
if($lognum=="0")
{
    echo "<p>��ʱû�л�ԱͶ���¼��</p>";
}
?>

 <style type="text/css">
 .pagelink
 {
float: right;
width:555px;
 
 }
.pagelink a
{
 color: #18344E;
}
.pagelink a:hover
{
 color: #BF0000;

}
 </style>
 <div style="padding-top: 10px;">
 <div style="float: left;">Page:<span style="color: #FF0000;"><?php echo $page;?></span>/<span style="color: #FF0000;"><?php echo $zy;?></span> | Record:<span style="color: #FF0000;"><?php echo $lognum;?></span></div>
 <div class="pagelink">
<?php
if($page > "1")
{
    echo '<a href=?page=1>��ҳ</a>';
    echo "&nbsp;";
    echo '<a href=?page='.($page-1).'>��һҳ</a>';
}

if($zy>$page)
{
    echo "&nbsp;";
    echo '<a href=?page='.($page+1).'>��һҳ</a>';
    echo "&nbsp;";
    echo '<a href=?page='.($zy).'>βҳ</a>';
}


?>

</div>

 
 </div>

</div></div></div>