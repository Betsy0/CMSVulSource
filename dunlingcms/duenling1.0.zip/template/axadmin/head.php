<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="Shortcut Icon" href="favicon.ico" type="image/x-icon" />
<link rel="Bookmark"  href="favicon.ico" type="image/x-icon" />
<meta http-equiv="Content-Type" content="text/html; charset=gbk" />
<title>��̨����ϵͳ �ٷ���վ��www.dunling.com</title>
<meta name="copyright" content="Copyright 2010-2012 - axphp_Inc" />
<link href="../style/user.css" rel="stylesheet" type="text/css" />
<link href="../style/user_main.css" rel="stylesheet" type="text/css" />
<script src="../js/out.js"></script>
</head>
<body>
<div id="logo"><img src="../images/logo.gif"/></div>
<div id="menu">
<div id="menu_s">
<ul>
<li><a href="axadmin.php">������ҳ</a></li>
<li class="left"><a href="income.php">��Ա����</a></li>
<li class="left"><a href="payadmin.php">�������</a></li>
<li class="left"><a href="upad.php">������</a></li>
<li class="left"><a href="gonggao.php">��������</a></li>
<li class="left"><a href="out.php" onclick = 'return out();'>�˳���̨</a></li>
</ul>
</div>
</div>