<div id="user_main">
<div id="left">
<?php require 'left.php'; require '../setting.php'; ?>
<script src="../js/system.js"></script>
</div>
<div id="right">
<div id="right_top"><div style="padding-top:5px;padding-left:10px;">��̨���� - ϵͳ����</div></div>
<div id="right_main">
<?php
isset($_SERVER['QUERY_STRING'])?$post=$_SERVER['QUERY_STRING']:null;
isset($_GET['post'])?$post=$_GET['post']:null;
if($post=="post")
{
$title = $_POST['title'];
$keywords = $_POST['keywords'];
$description = $_POST['description'];
$domain = $_POST['domain'];
$ticheng = $_POST['ticheng'];
$paynum = $_POST['paynum'];
$xxopen = $_POST['xxopen'];
$bottom = stripslashes($_POST['bottom']);
$system = file_get_contents("../plug-in/axphp.setting");
$setting_a = array("@title@","@ticheng@","@domain@","@paynum@","@xxopen@","@bottom@","@keywords@","@description@");
$setting_b = array("$title","$ticheng","$domain","$paynum","$xxopen","$bottom","$keywords","$description");
$systemconfig = str_replace($setting_a,$setting_b,$system);
$fok = file_put_contents('../setting.php',$systemconfig);
if($fok)
{
header("location:system.php");
}
}
switch($axphp['xxopen'])
{
    case 1:
    $xxopen1="selected";
    break;
    case 0:
    $xxopen0="selected";
    break;
}
switch($axphp['alert'])
{
    case 1:
    $alert1="selected";
    break;
    case 0:
    $alert0="selected";
    break;
}

?>



<table width="780" cellpadding="8" cellspacing="1" bgcolor="silver">
<form method="post" action="?post=post" onsubmit="return system(this);" >
<tr bgcolor="#ffffff">
<td width="100"  align="right">��վ����:</td>
<td align="left"><input value="<?php echo $axphp['title'];?>" name="title" style="width: 300px;height:20px;background-color: #F0F8FF;border: #7F9DB9 solid 1px;line-height: 20px;" /></td>
</tr>

<tr bgcolor="#ffffff">
<td width="100"  align="right">�ؼ���:</td>
<td align="left"><input value="<?php echo $axphp['keywords'];?>" name="keywords" style="width: 300px;height:20px;background-color: #F0F8FF;border: #7F9DB9 solid 1px;line-height: 20px;" /> ÿ���ؼ������ð�Ƕ���(,)����</td>
</tr>

<tr bgcolor="#ffffff">
<td width="100"  align="right">��վ����:</td>
<td align="left"><input value="<?php echo $axphp['description'];?>" name="description" style="width: 300px;height:20px;background-color: #F0F8FF;border: #7F9DB9 solid 1px;line-height: 20px;" /></td>
</tr>

<tr bgcolor="#ffffff">
<td width="100"  align="right">��ҳ��ַ:</td>
<td align="left"><input value="<?php echo $axphp['domain']?>" name="domain" style="color: #005515;width: 300px;height:20px;background-color: #F0F8FF;border: #7F9DB9 solid 1px;line-height: 20px;" /> ������ http:// ��ͷ</td>
</tr>

<tr bgcolor="#ffffff">
<td width="100"  align="right">��������:</td>
<td align="left"><select name="xxopen" style="width: 304px;height:25px;background-color: #F0F8FF;border: #7F9DB9 solid 1px;line-height: 20px;" ><option <?php echo $xxopen1;?> value="1" style="color: #00661A;">����</option><option <?php echo $xxopen0;?> value="0" style="color: #FF0000;">�ر�</option></select> ���߿���</td>
</tr>

<tr bgcolor="#ffffff">
<td width="100"  align="right">�������:</td>
<td align="left"><input name="ticheng" onkeyup="value=value.replace(/[^\d]/g,'') " value="<?php echo $axphp['ticheng'];?>"  style="width: 300px;height:20px;background-color: #F0F8FF;border: #7F9DB9 solid 1px;line-height: 20px;" /> ֱ����д�������</td>
</tr>


<tr bgcolor="#ffffff">
<td width="100"  align="right">���ֵ���:</td>
<td align="left"><input value="<?php echo $axphp['paynum'];?>" name="paynum" style="width: 300px;height:20px;background-color: #F0F8FF;border: #7F9DB9 solid 1px;line-height: 20px;" /> ����������ֽ��</td>
</tr>

<tr bgcolor="#ffffff">
<td width="100"  align="right" valign="top">ҳβ��Ȩ:</td>
<td align="left"><textarea name="bottom" style="width: 600px;height:60px;background-color: #F0F8FF;border: #7F9DB9 solid 1px;line-height: 20px;" ><?php echo $axphp['bottom'];?></textarea> </td>
</tr>

<tr bgcolor="#ffffff">
<td align="left" colspan="2" style="padding-left: 120px;" >
<button type="submit" style="width: 100px;height:28px;background-color: #FFFFFF;border:#004D00 solid 1px;font-size:14px;color: #004D00;" >��������</button>
</td>

</tr>

</form>

</table>

</div>





</div>
</div>