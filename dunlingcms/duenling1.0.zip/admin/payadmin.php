<?php
require 'check.php';
require '../template/axadmin/head.php';
require '../template/axadmin/banner.php';
require '../template/axadmin/payadmin.php';
require '../template/axadmin/bottom.php'
?>