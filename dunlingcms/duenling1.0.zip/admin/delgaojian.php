<?php
error_reporting(0);
$id = $_GET['id'];
require_once("../config.php");
$sql = "delete from axphp_text where id = '$id'";
mysql_query($sql,$config);
echo "��ɾ��!";
?>