<?php
require '../config.php';
$adminname = $_POST['adminname'];
$adminpass = $_POST['adminpass'];
$adminpass .= "Axphp.com";
$adminpass = md5($adminpass);
$adminsql = "select * from axphp_admin where adminname='$adminname' and adminpass='$adminpass'";
$adminery = mysql_query($adminsql, $config);
$adminnum = mysql_num_rows($adminery);
if ($adminnum == "1") {
setcookie("admin", "Y", time() + 3600, '/');
setcookie("admin_name", $adminname, time() + 3600, '/');
header("location:axadmin.php");
} else {
header("location:axphp.php");
}
?>