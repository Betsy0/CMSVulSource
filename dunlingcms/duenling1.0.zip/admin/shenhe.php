<?php
error_reporting(0);
$id = $_GET['id'];
require_once("../config.php");
$sql = "select * from axphp_text where id='$id'";
$ery = mysql_query($sql,$config);
$row = mysql_fetch_array($ery);
$title = $row['title'];
$text = $row['texts'];
$moeny99 = $row['money'];
$username2 =$row['username'];

$shenhe2 = $row['shenhe'];

if($shenhe2!="0")
{
    $lock = 'disabled=""';
}
else{
    $lock = null;
}
?>
<table cellpadding="5" cellspacing="1">
<tr>
<td>
����:
</td>
<td>
<input value="<?php echo $title;?>" style="width:650px;height:30px;line-height: 28px;" />
</td>
</tr>
<tr>
<td>����:</td>
<td>
<textarea name="texts" style="width: 650px;height:350px;resize:none;"><?php echo strip_tags($text);?></textarea>
</td>
</tr>
<tr>
<td>
Ͷ����:
</td><td>
<?php echo $username2;?>
</td>
</tr>
</td>
<tr>
<td>
���:
<td>
<form method="post">
<select name="shenhe" <?php echo $lock;?>><option value="1">���ͨ��</option><option value="2">δͨ��</option></select>
����:<input <?php echo $lock;?> type="text" name="money" value="<?php echo $moeny99;?>" /><input type="submit" value="���" <?php echo $lock;?> />
</form>
</td>
</tr>
</table>
<?php
$shenhe = $_POST['shenhe'];
$money = $_POST['money'];
if($shenhe!=null){
$upsql = "update axphp_text set shenhe='$shenhe',money='$money' where id='$id'";
$upusersql = "update axphp_user set money=money+'$money',payn=payn+'$money' where username = '$username2'";
mysql_query($upsql,$config);
mysql_query($upusersql,$config);
header("refresh:1;url=shenhe.php?id=$id");
}

?>