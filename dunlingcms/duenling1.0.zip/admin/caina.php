<?php
error_reporting(0);
$id = $_GET['id'];
require_once("../config.php");
$sql = "update axphp_text set caina = '1' where id = '$id'";
mysql_query($sql,$config);
echo "�Ѳ���!";
?>