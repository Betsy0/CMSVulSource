<?php
require 'template/default/head.php';
require 'template/default/reg.php';
require 'template/default/bottom.php';
?>