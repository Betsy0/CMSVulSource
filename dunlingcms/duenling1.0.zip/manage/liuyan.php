<?php
require 'check.php';
require '../template/manage/head.php';
require '../template/manage/banner.php';
require '../template/manage/liuyan.php';
require '../template/manage/bottom.php'
?>