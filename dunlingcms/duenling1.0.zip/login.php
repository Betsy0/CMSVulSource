<?php
require 'template/default/head.php';
require 'template/default/login.php';
require 'template/default/bottom.php';
?>