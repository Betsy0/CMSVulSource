<?php
class Link extends Article {
}
?>