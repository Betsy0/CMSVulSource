<script>
window.location.href='admin.php?action=frame&ctrl=login'
</script>