<?php
define('WEBNAME',	'taoCMS演示');
define('WEBURL',	'./');
define('WEBINFO',	'taoCMS演示系统，taoCMS是基于php+Mysql/Sqlite的国内最小的CMS网站内容管理系统！');
define('ANNOUNCE',	'taoCMS演示系统，taoCMS是基于php+mysql/sqlite的国内最小的CMS网站内容管理系统！');
define('ADMINDIR',	'admin/');
define('TIMEMOD',	'8');
define('EACHPAGE',	'10');
define('TAOEDITOR',	'2');
define('TAODEBUG',	'0');
define('SYS_ROOT',	str_replace("\\", '/',dirname(__FILE__))."/");
define('CACHE',	'data/');
define('CACHELAST',	'1');
define('INC',	'include/');
define('DB',	'Mysql');
define('DB_NAME',	'data/blog.db');
define('MEMCACHE',	'');
define('TB',	'cms_');
define('CREATHTML',	'0');
define('VIEWSCOUNT',	'1');
define('CATURL',	'?cat={id}');
define('ATLURL',	'?id={id}');
define('THEME',	'taoCMS/');
?>