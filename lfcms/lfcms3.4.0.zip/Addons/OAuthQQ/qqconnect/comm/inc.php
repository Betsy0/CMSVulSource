<?php die('forbidden'); ?>
{"scope":"get_user_info,add_pic_t","errorReport":true,"storageType":"file","host":"localhost","user":"root","password":"root","database":"test"}