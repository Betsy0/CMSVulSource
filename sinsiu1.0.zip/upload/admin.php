<?php
include('include/common.php');
include('admin/basic.func.php');
	
main();
	
//新秀
?>
