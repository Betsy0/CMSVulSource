<?php
header('location:../safe.html');
	//新秀 
?>