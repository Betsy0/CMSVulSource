<?php
function module_login()
{
}
//新秀
?>