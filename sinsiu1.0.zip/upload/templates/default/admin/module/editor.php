{*<?php exit();?>*}
<script type="text/javascript" charset="utf-8" src="ueditor/editor_config.js"></script>
<script type="text/javascript" charset="utf-8" src="ueditor/editor_all.js"></script>
<script id="editor" name="editor" type="text/plain">{$editor_text}</script>
{literal}
<script type="text/javascript">
	var ue = UE.getEditor('editor');
</script>
{/literal}
<!-- 新秀 -->