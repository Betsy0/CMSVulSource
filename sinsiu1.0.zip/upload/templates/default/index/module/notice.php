{*<?php exit();?>*}
<div class="box" id="notice">
	<div class="head"><span>{$lang.notice}</span></div>
	<div class="main">
		{$notice}
	</div>
</div>
<!-- 新秀 -->
