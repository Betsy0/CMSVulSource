{*<?php exit();?>*}
<div class="box tree">
	<div class="head"><span>{$lang.about_menu}</span></div>
	<div class="main">
		{foreach from=$menu name=menu item=item}
		<div class="cat1"><a href="{$item.men_url}">{$item.men_name}</a></div>
		{/foreach}
	</div>
</div>
<!-- 新秀 -->
