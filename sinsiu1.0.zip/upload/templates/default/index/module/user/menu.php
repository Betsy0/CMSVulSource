{*<?php exit();?>*}
<div class="box tree" id="user_menu">
	<div class="head"><span>{$lang.user_center}</span></div>
	<ul class="main">
		<li class="cat1"><a href="{url entrance=$global.entrance channel='user' mod='profile'}">{$lang.user_info}</a></li>
		<li class="cat1"><a href="{url entrance=$global.entrance channel='user' mod='message_sheet'}">{$lang.my_message}</a></li>
		<li class="cat1"><a href="{url entrance=$global.entrance channel='user' mod='comment_sheet'}">{$lang.my_comments}</a></li>
		<li class="cat1"><a href="{url entrance=$global.entrance channel='user' mod='booking_sheet'}">{$lang.my_booking}</a></li>
		<li class="cat1"><a href="{url entrance=$global.entrance channel='user' mod='logout'}">{$lang.log_out}</a></li>
	</ul>
</div>