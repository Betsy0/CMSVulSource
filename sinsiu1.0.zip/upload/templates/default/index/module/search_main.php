{*<?php exit();?>*}
<div class="img_sheet">
	{foreach from=$search name=search item=item}
	<div class="unit">
		<div class="in">
		<table>
			<tr>
				<td class="img">
					<a href="{url channel='goods' id=$item.goo_id}" target="_blank"><img src="{$S_ROOT}{$item.goo_x_img}" onload="picresize(this,150,150)" /></a>
				</td>
			</tr>
			<tr>
				<td class="title">
					<a href="{url channel='goods' id=$item.goo_id}" target="_blank">{$item.short_title}</a>
				</td>
			</tr>
		</table>
		</div>
	</div>
	{/foreach}
	{if !$search}<div class="not_found">{$lang.not_found}</div>{/if}
	<div class="clear"></div>
</div>
{$prefix = 'search/key-'|cat:$global.key}
{include file="module/page_link.php" page=$global.page}
<!-- 新秀 -->
