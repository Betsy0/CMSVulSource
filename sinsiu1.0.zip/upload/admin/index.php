<?php
header('location:../admin.php');
	//新秀 
?>