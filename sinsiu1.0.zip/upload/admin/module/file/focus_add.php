<?php
function module_focus_add()
{
}
//新秀
?>