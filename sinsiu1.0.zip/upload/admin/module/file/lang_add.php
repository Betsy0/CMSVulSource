<?php
function module_lang_add()
{
}
//新秀
?>