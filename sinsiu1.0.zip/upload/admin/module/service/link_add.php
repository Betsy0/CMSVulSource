<?php
function module_link_add()
{
}
//新秀
?>