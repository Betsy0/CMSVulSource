<?php
function module_question_add()
{
}
//新秀
?>