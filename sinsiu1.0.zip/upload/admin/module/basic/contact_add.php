<?php
function module_contact_add()
{
}
//新秀
?>