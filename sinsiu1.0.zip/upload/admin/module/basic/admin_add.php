<?php
function module_admin_add()
{
}
//新秀
?>