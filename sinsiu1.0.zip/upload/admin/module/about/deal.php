<?php
include('admin/module/article/deal.php');
//新秀
?>