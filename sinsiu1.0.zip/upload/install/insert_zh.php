<?php
//sql_query("insert into () values ('')");
sql_query("insert into ".$db_prefix."admin (adm_username,adm_password,adm_grade,adm_power) values ('$admin_name','".md5($admin_pwd)."','1','all')");
	
sql_query("insert into ".$db_prefix."article (art_lang,art_channel_id,art_title,art_text,art_top) values ('zh-cn','3','公司简介','公司简介','1')");
sql_query("insert into ".$db_prefix."article (art_lang,art_channel_id,art_title,art_text) values ('zh-cn','3','企业文化','企业文化')");
sql_query("insert into ".$db_prefix."article (art_lang,art_channel_id,art_title,art_text) values ('zh-cn','3','成功案例','成功案例')");
	
sql_query("insert into ".$db_prefix."att_art (att_channel_id,att_code,att_name) values ('5','file_path','下载链接')");
	
sql_query("insert into ".$db_prefix."cat_art (cat_lang,cat_channel_id,cat_parent_id,cat_name,cat_best) values ('zh-cn','2','0','文章一类','1')");
sql_query("insert into ".$db_prefix."cat_art (cat_lang,cat_channel_id,cat_parent_id,cat_name,cat_best) values ('zh-cn','2','0','文章二类','1')");
sql_query("insert into ".$db_prefix."cat_art (cat_lang,cat_channel_id,cat_parent_id,cat_name,cat_best) values ('zh-cn','2','1','文章三类','0')");
sql_query("insert into ".$db_prefix."cat_goo (cat_lang,cat_channel_id,cat_parent_id,cat_name,cat_best) values ('zh-cn','1','0','产品一类','1')");
sql_query("insert into ".$db_prefix."cat_goo (cat_lang,cat_channel_id,cat_parent_id,cat_name,cat_best) values ('zh-cn','1','0','产品二类','0')");
sql_query("insert into ".$db_prefix."cat_goo (cat_lang,cat_channel_id,cat_parent_id,cat_name,cat_best) values ('zh-cn','1','1','产品三类','0')");
	
sql_query("insert into ".$db_prefix."channel (cha_lang,cha_code,cha_name,cha_original) values ('zh-cn','goods','产品展示','0')");
sql_query("insert into ".$db_prefix."channel (cha_lang,cha_code,cha_name,cha_original) values ('zh-cn','article','资讯中心','0')");
sql_query("insert into ".$db_prefix."channel (cha_lang,cha_code,cha_name,cha_original) values ('zh-cn','about','关于我们','0')");
sql_query("insert into ".$db_prefix."channel (cha_lang,cha_code,cha_name,cha_original) values ('zh-cn','recruit','人才招聘','0')");
sql_query("insert into ".$db_prefix."channel (cha_lang,cha_code,cha_name,cha_original) values ('zh-cn','download','下载中心','0')");
	
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('zh-cn','header','首页','index/')");
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('zh-cn','header','关于我们','about/')");
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('zh-cn','header','产品展示','goods/')");
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('zh-cn','header','资讯中心','article/')");
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('zh-cn','header','人才招聘','recruit/')");
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('zh-cn','header','下载中心','download/')");
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('zh-cn','header','在线留言','message/')");
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('zh-cn','header','用户中心','./?/user/')");
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('zh-cn','header','新秀官网','http://www.sinsiu.com')");
	
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('zh-cn','footer','首页','index/')");
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('zh-cn','footer','关于我们','about/')");
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('zh-cn','footer','产品展示','goods/')");
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('zh-cn','footer','资讯中心','article/')");
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('zh-cn','footer','人才招聘','recruit/')");
	
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('zh-cn','about','公司简介','about/id-1/')");
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('zh-cn','about','企业文化','about/id-2/')");
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('zh-cn','about','成功案例','about/id-3/')");
	
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_header','基本设置','basic/mod-basic_info/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_header','产品管理','goods/mod-sheet/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_header','文章管理','article/mod-sheet/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_header','用户互动','service/mod-user_sheet/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_header','文件管理','file/mod-tpl_list/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_header','高级应用','super/mod-channel_add/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_basic','基本信息','basic/mod-basic_info/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_basic','联系方式','basic/mod-contact_list/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_basic','网站设置','basic/mod-site_set/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_basic','导航管理','basic/mod-nav_list/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_basic','模块启闭','basic/mod-show_set/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_basic','安全设置','basic/mod-safe_set/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_basic','静态设置','basic/mod-static_set/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_basic','管理员帐号','basic/mod-admin_list/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_basic','数据库管理','basic/mod-db_set/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_basic','其它设置','basic/mod-other/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_goods','产品列表','goods/mod-sheet/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_goods','添加产品','goods/mod-add/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_goods','产品分类','goods/mod-cat_list/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_goods','产品属性','goods/mod-att_list/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_article','文章列表','article/mod-sheet/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_article','添加文章','article/mod-add/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_article','文章分类','article/mod-cat_list/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_article','关于我们列表','about/mod-sheet/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_article','添加关于我们','about/mod-add/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_article','人才招聘列表','recruit/mod-sheet/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_article','添加人才招聘','recruit/mod-add/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_article','下载列表','download/mod-sheet/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_article','添加下载','download/mod-add/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_service','用户管理','service/mod-user_sheet/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_service','留言管理','service/mod-message_sheet/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_service','评论管理','service/mod-comment_sheet/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_service','产品订购','service/mod-booking_sheet/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_service','问卷调查','service/mod-research_sheet/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_service','网站公告','service/mod-notice/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_service','在线客服','service/mod-online/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_service','用户协议','service/mod-agreement/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_service','友情链接','service/mod-link_list/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_file','选择模板','file/mod-tpl_list/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_file','图片管理','file/mod-pic_lists/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_file','焦点图片','file/mod-focus_list/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_file','语言设置','file/mod-lang_lists/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_file','资源管理','file/mod-files_list/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_super','新建频道','super/mod-channel_add/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_super','频道名称','super/mod-channel_name/')");
sql_query("insert into ".$db_prefix."menu (men_type,men_name,men_url) values ('admin_super','后台导航管理','super/mod-nav_list/')");
	
sql_query("insert into ".$db_prefix."picture (pic_lang,pic_type,pic_path,pic_site,pic_title,pic_url) values ('zh-cn','focus','images/focus_2.jpg','default','焦点图片','index.php')");
sql_query("insert into ".$db_prefix."picture (pic_lang,pic_type,pic_path,pic_site,pic_title,pic_url) values ('zh-cn','focus','images/focus_1.jpg','default','焦点图片','index.php')");
	
sql_query("insert into ".$db_prefix."link (lin_lang,lin_word,lin_url,lin_img,lin_title,lin_index) values ('zh-cn','水处理设备','http://www.twbuder.com','none','水处理设备','10')");
sql_query("insert into ".$db_prefix."link (lin_lang,lin_word,lin_url,lin_img,lin_title,lin_index) values ('zh-cn','广州游戏机','http://www.isaogou.com','none','广州游戏机','9')");
	
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('zh-cn','site_title','新秀企业网站系统PHP版 sinsiu PHP 1.0 正式版')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('zh-cn','site_name','新秀工作室')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('none','site_domain','www.sinsiu.com')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('zh-cn','site_record','粤ICP备12345678号')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('none','site_record_url','http://www.sinsiu.com')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('zh-cn','site_tech','新秀工作室')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('none','site_tech_url','http://www.sinsiu.com')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('zh-cn','site_keywords','网站关键字')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('zh-cn','site_description','网站描述')");
	
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('zh-cn','contact','联系人{v}陈湘国')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('zh-cn','contact','电话{v}15975329917')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('zh-cn','contact','手机{v}15975329917')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('zh-cn','contact','传真{v}15975329917')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('zh-cn','contact','邮编{v}510000')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('zh-cn','contact','地址{v}广东省广州市天河区岑村')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('zh-cn','contact','网址{v}www.sinsiu.com')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('zh-cn','contact','QQ/MSN{v}627780354')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('zh-cn','contact','电子邮件{v}$email')");
	
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('zh-cn','research','您是如何知道本网站的？{v}radio{v}广告{v}名片{v}搜索引擎')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('zh-cn','research','您认为本公司产品质量如何？{v}radio{v}很好{v}一般{v}很差')");
	
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_text) values ('none','statistical_code','统计代码')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_text) values ('none','share_code','$share_code')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_text) values ('zh-cn','notice','网站公告')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_text) values ('zh-cn','service_code','在线客服')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_text) values ('zh-cn','user_agreement','用户协议')");
	
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('languages','zh-cn{v}index.php{v}admin.php{v}中文{v}中文')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('languages','en-us{v}en.php{v}en_admin.php{v}英文{v}English')");
	
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('about_filter','1')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('about_len','520')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('index_img_list_len','8')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('index_art_list_len','5')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('img_list_len','12')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('art_list_len','15')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('x_img_width','160')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('x_img_height','160')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('single_page_static','0')");
	
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('safe_admin_login_hours','1')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('safe_admin_login_times','10')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('safe_user_login_hours','1')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('safe_user_login_times','20')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('safe_register_hours','1')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('safe_register_times','3')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('safe_message_hours','1')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('safe_message_times','3')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('safe_comment_hours','1')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('safe_comment_times','20')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('safe_research_hours','1')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('safe_research_times','3')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('safe_booking_hours','1')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('safe_booking_times','20')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('safe_edit_user_hours','1')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('safe_edit_user_times','10')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('safe_edit_pwd_hours','1')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('safe_edit_pwd_times','3')");
	
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('sentmail','0')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('sentmail_smtp','smtp.163.com')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('sentmail_send','sinsiu_1_0_5@163.com')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('sentmail_password','sinsiu105')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('sentmail_receive','$email')");
	
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('nav_stage_header','页头导航')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('nav_stage_footer','页脚导航')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('nav_stage_about','关于我们')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('nav_admin_header','后台主导航')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('nav_admin_basic','基本设置')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('nav_admin_goods','产品管理')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('nav_admin_article','文章管理')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('nav_admin_service','用户互动')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('nav_admin_file','文件管理')");
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('nav_admin_super','高级应用')");
	
sql_query("insert into ".$db_prefix."varia (var_name,var_value) values ('version','sinsiu PHP 1.0 final')");
	
sql_query("insert into ".$db_prefix."channel (cha_lang,cha_code,cha_name,cha_original) values ('en-us','goods','Product','0')");
sql_query("insert into ".$db_prefix."channel (cha_lang,cha_code,cha_name,cha_original) values ('en-us','article','Article','0')");
sql_query("insert into ".$db_prefix."channel (cha_lang,cha_code,cha_name,cha_original) values ('en-us','about','About Us','0')");
sql_query("insert into ".$db_prefix."channel (cha_lang,cha_code,cha_name,cha_original) values ('en-us','recruit','Recruit','0')");
sql_query("insert into ".$db_prefix."channel (cha_lang,cha_code,cha_name,cha_original) values ('en-us','download','Download','0')");
	
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_text) values ('en-us','notice','Notice')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_text) values ('en-us','service_code','Service')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_text) values ('en-us','user_agreement','User Agreement')");
	
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('en-us','site_title','sinsiu PHP 1.0 final')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('en-us','site_name','sinsiu')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('en-us','site_record','粤ICP备12345678号')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('en-us','site_tech','sinsiu')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('en-us','site_keywords','Keywords')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('en-us','site_description','Description')");
	
//新秀
?>