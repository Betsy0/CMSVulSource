<?php
sql_query("insert into ".$db_prefix."article (art_lang,art_channel_id,art_title,art_text,art_top) values ('en-us','8','Company Profile','Company Profile','1')");
sql_query("insert into ".$db_prefix."article (art_lang,art_channel_id,art_title,art_text) values ('en-us','8','Corporate Culture','Corporate Culture')");
sql_query("insert into ".$db_prefix."article (art_lang,art_channel_id,art_title,art_text) values ('en-us','8','Success Stories','Success Stories')");
	
sql_query("insert into ".$db_prefix."cat_art (cat_lang,cat_channel_id,cat_parent_id,cat_name,cat_best) values ('en-us','7','0','Class one','1')");
sql_query("insert into ".$db_prefix."cat_art (cat_lang,cat_channel_id,cat_parent_id,cat_name,cat_best) values ('en-us','7','0','Class two','1')");
sql_query("insert into ".$db_prefix."cat_art (cat_lang,cat_channel_id,cat_parent_id,cat_name,cat_best) values ('en-us','7','4','Class three','0')");
sql_query("insert into ".$db_prefix."cat_goo (cat_lang,cat_channel_id,cat_parent_id,cat_name,cat_best) values ('en-us','6','0','Class one','1')");
sql_query("insert into ".$db_prefix."cat_goo (cat_lang,cat_channel_id,cat_parent_id,cat_name,cat_best) values ('en-us','6','0','Class two','0')");
sql_query("insert into ".$db_prefix."cat_goo (cat_lang,cat_channel_id,cat_parent_id,cat_name,cat_best) values ('en-us','6','4','Class three','0')");
	
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('en-us','header','Home','index/')");
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('en-us','header','About Us','about/')");
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('en-us','header','Product','goods/')");
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('en-us','header','Article','article/')");
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('en-us','header','Recruit','recruit/')");
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('en-us','header','Download','download/')");
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('en-us','header','Message','message/')");
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('en-us','header','User','user/')");
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('en-us','header','sinsiu','http://www.sinsiu.com')");
	
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('en-us','footer','Home','index/')");
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('en-us','footer','About Us','about/')");
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('en-us','footer','Product','goods/')");
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('en-us','footer','Article','article/')");
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('en-us','footer','Recruit','recruit/')");
	
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('en-us','about','Company Profile','about/id-4/')");
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('en-us','about','Corporate Culture','about/id-5/')");
sql_query("insert into ".$db_prefix."menu (men_lang,men_type,men_name,men_url) values ('en-us','about','Success Stories','about/id-6/')");
	
sql_query("insert into ".$db_prefix."picture (pic_lang,pic_type,pic_path,pic_site,pic_title,pic_url) values ('en-us','focus','images/focus_2.jpg','default','Focus Pictures','index.php')");
sql_query("insert into ".$db_prefix."picture (pic_lang,pic_type,pic_path,pic_site,pic_title,pic_url) values ('en-us','focus','images/focus_1.jpg','default','Focus Pictures','index.php')");
	
sql_query("insert into ".$db_prefix."link (lin_lang,lin_word,lin_url,lin_img,lin_title,lin_index) values ('en-us','Twbuder','http://www.twbuder.com','none','Twbuder','10')");
sql_query("insert into ".$db_prefix."link (lin_lang,lin_word,lin_url,lin_img,lin_title,lin_index) values ('en-us','Isaogou','http://www.isaogou.com','none','Isaogou','9')");
	
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('en-us','contact','Linkman{v}XiangGuo Chen')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('en-us','contact','Tel{v}15975329917')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('en-us','contact','Phone{v}15975329917')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('en-us','contact','Fax{v}15975329917')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('en-us','contact','Zip Code{v}510000')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('en-us','contact','Address{v}Tianhe District, Guangzhou City, Guangdong Province Cencun')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('en-us','contact','Website{v}www.sinsiu.com')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('en-us','contact','QQ/MSN{v}627780354')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('en-us','contact','E-mail{v}$email')");
	
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('en-us','research','How do you know this website?{v}radio{v}Advertising{v}Business Card{v}Search Engine')");
sql_query("insert into ".$db_prefix."varia (var_lang,var_name,var_value) values ('en-us','research','Do you think how the quality of our goodss?{v}radio{v}Good{v}General{v}Poor')");
	
//新秀
?>