<?php
include('include/common.php');
include('index/basic.func.php');
	
main();
	
//新秀
?>
