<?php
	if(!isset($_COOKIE['admin_name'])){
		alert_href('请重新登录！','cms_login.php');
	};

?>