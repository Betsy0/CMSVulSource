<?php include('../system/inc.php');
include("smtp.class.php");
$MailServer = $rjcms_smtp; //SMTP服务器
    $MailPort = 465; //SMTP服务器端口
    $smtpMail = $rjcms_muser; //SMTP服务器的用户邮箱
    $smtpuser = $rjcms_muser; //SMTP服务器的用户帐号
    $smtppass = $rjcms_mpwd; //SMTP服务器的用户密码
   

?>
