﻿        <div class="col-md-3">
           <div class="sidenav">
             <ul class="list-group">
               <li class="list-group-heading" style="margin-top:0px;">会员中心</li>
               <li class="list-group-item " ><a href="index.php">账户中心</a></li>
			   <li class="list-group-item " ><a href="userinfo.php">个人设置</a></li>
               <li class="list-group-item "  ><a href="mingxi.php">购买会员</a></li>
			   <li class="list-group-item "><a href="kami.php">卡密兑换</a></li>
                <li class="list-group-item "><a href="yaoqing.php">邀请记录</a></li>
               <li class="list-group-item "><a href="playlist.php">播放记录</a></li>
               <li class="list-group-item "><a href="fav.php">收藏记录</a></li>
			    <li class="list-group-item "><a href="exit.php">退出登录</a></li>
            </ul>
          </div>
        </div>
