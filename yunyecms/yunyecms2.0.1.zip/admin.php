<?php
require './core/config/const.php';
require YUNYECMS_CORE.'init.php';
core::InitYUNYECMSAdmin();
?>