<?php
$LANG['content_model_notexist'] = '该信息模型不存在';
$LANG['submit_daylimit'] = '对不起，您一天之内只能提交10次!';
$LANG['form_email_msg'] = '您收到一封来自%s的%s';
$LANG['required_fdtitle'] = '%s不能为空，请重输入!';
$LANG['form_info_ok'] = '%s信息提交成功！';
$LANG['form_info_error'] = '%s信息提交失败！';
?>