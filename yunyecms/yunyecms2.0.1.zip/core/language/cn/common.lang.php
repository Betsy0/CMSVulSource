<?php
	$LANG['error_parameter'] = '参数错误!';
	$LANG['illegal_submit'] = '非法提交! ';
	$LANG['member_center'] = '会员中心';
	$LANG['model_notexist'] = '该模型不存在！';
	$LANG['operation_failed'] = '操作失败！';
?>