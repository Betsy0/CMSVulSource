<?php
	$LANG['error_parameter'] = 'Parameter error!';
	$LANG['illegal_submit'] = 'Illegal submission! ';
	$LANG['member_center'] = 'Member Center';
	$LANG['model_notexist'] = 'The model does not exist！';
	$LANG['operation_failed'] = 'Operation failed！';
?>