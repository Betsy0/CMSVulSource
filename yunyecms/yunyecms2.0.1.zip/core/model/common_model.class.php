<?php
defined('InYUNYECMS') or exit('No permission resources.');
core::load_class("model",0);
class common_model extends model{
	public $tablename = '';
	public function __construct() {
		parent::__construct();
	}
}
?>