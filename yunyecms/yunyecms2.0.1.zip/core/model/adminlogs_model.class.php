<?php
defined('InYUNYECMS') or exit('No permission resources.');
core::load_class("model",0);
class adminlogs_model extends model{
	public function __construct() {
		$this->tablename = 'adminlogs';
		parent::__construct();
	}
}
?>