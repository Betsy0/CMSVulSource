<?php defined('InYUNYECMS') or exit('No direct script access allowed');?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>YUNYECMS V2.0 信息提示</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="<?php echo YUNYECMS_UI;?>bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo YUNYECMS_UI;?>plugins/font-awesome-4.7.0/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo YUNYECMS_UI;?>dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="<?php echo YUNYECMS_UI;?>dist/css/admin.css">
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<body class="hold-transition rightbgcolor"  onload="changefrmHeight()">
  <!-- Content Wrapper. Contains page content -->
  <div class="container-fluid" id="mainwrap">
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box box-<?php echo $strcss;?>">
            <div class="box-header with-border" style="text-align:center;">
              <h3 class="box-title">信息提示</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body" style="text-align:center;">
              <div class="alert alert-<?php echo $strcss;?> alert-dismissible" >
                <h4><i class="icon fa fa-<?php echo $strico;?>"></i> <?php echo $msg;?></h4>
                 <?php if($msg2)echo $msg2;?>
                 <?php
				  $rethref="";
				  ?>
                <?php if($reurl&&$reurl!="nback") {
					   if($reurl=="back"){
						   $retjs="history.go(-1);";
						   $rethref="javascript:history.go(-1);";
						   }else{
						    if($target=='top'){
						       $retjs='top.location.href = "'.$reurl.'"';
							 }else{
						       $retjs='location.href = "'.$reurl.'"';
							}
						      $rethref=$reurl;
						   }
					?>
                系统将在 <b id="wait"> <?php echo floor($time/1000); ?></b> 秒后返回，如需立即返回点击确定按钮。
    <script type="text/javascript">
    (function(){
        var wait = document.getElementById('wait');
		var waittime=<?php echo $time;?>;
        var reurl = "<?php echo $reurl?>";
        var interval = setInterval(function(){
            var time = --wait.innerHTML;
            if(time == 0) {
                 <?php echo $retjs;?>
				//location.href = reurl;
                clearInterval(interval);
            };
        }, 1000);
    })();
   </script>						   				
                <?php     }?>
               </div>
               <?php if($reurl!="nback"):?>
                  <a  class="btn  btn-<?php echo $strcss;?>" href="<?php echo $rethref;?>"><i class="icon fa fa-check"></i> 确定</a>
              &nbsp;&nbsp;
              <button type="button" class="btn btn-default" onClick="javascript:history.go(-1);"> <i class="icon fa fa-history"></i> 返回</button>
				<?php endif?>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php require tpl_adm('foot');?>
<!-- jQuery 2.2.3 -->
<script src="<?php echo YUNYECMS_UI;?>plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo YUNYECMS_UI;?>dist/js/admin.js"></script>
</body>
</html>