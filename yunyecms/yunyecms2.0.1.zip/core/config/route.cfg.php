<?php
return array(
	'default'=>array('m'=>'content', 'c'=>'index', 'a'=>'index'),
	'admin'=>array('m'=>'admin', 'c'=>'main', 'a'=>'init'),
);
?>