<?php
return array(
'lang' => 'gb',  //网站语言包
);
?>