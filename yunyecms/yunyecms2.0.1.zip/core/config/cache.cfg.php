<?php

return array (
	'file1' => array (
		'type' => 'file',
		'debug' => true,
		'pconnect' => 0,
		'autoconnect' => 0
		),
	'template' => array (
		'hostname' => '127.0.0.1',
		'port' => 99999,
		'timeout' => 0,
		'type' => 'memcache',
		'debug' => true,
		'pconnect' => 0,
		'autoconnect' => 0
	)
);

?>