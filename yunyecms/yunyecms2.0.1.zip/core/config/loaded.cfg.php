<?php
define('YUNYECMS_URLADM',url_admin());
?>