<?php
 function savemsg($title,$flag=1,$content=array(),$userid=0,$status=1){
	if($userid){
		$userid=(int)$userid;
		}else{
			$userid=ugetcookie('userid');
			}
	$title=addslashes(stripslashes($title));
	$ip=getip();
	$ipport=getipport();
	$addtime=time();
	$strsql="insert into `#yunyecms_msg`(userid,title,content,flag,status,ip,ipport,addtime) values('$userid','$title','$content',$flag,$status,'$ip','$ipport',$addtime)";
	$sql=query($strsql);
	return $sql;
}
  function islogin(){
        $userid=ugetcookie("userid");
		if(empty($userid)){
	         messagebox('您还没有登录! ',url('login/member/member'));	 
		}
	}

//通过ID和栏目ID获取信息模型内容
function GetContentById($id,$catid){
	 if(empty($id)||empty($catid)) {
			return false;
		}
	    $modelid=getmodelid($catid);
	    if($modelid){
		   $curmodel=getmodel($modelid);
		   if(!$curmodel){ return false; }
			$tablename="m_".$curmodel['tablename'];
			$retres=getone("select * from `#yunyecms_{$tablename}` where `id`= {$id}");
		   if(empty($retres)){
			 return false;
		    }else{
			 return $retres;
			  } 			
		}else{
			return false;
		}
}


?>