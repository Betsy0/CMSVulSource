<?php
function GetCartTotal($userid,$cartarr=array(),$isajax=0){
	   $totalmoney=0;
	   if(empty($userid)){
			$userid=ugetcookie('userid');
		    if(!$userid) $totalmoney=0;
		}
	    $strsql="select * from `#yunyecms_cart` where gid<>'' and userid={$userid}  ";
	    if(!empty($cartarr)){
			$cartstr=implode(",",$cartarr);
			$strsql=$strsql." and id in($cartstr)";
		}
	    $cartlist=getlist($strsql);
	    if($cartlist){
		  foreach($cartlist as $key => $v) {
			 $money=$v['price'];
			 $num=$v['num'];
			 if(!empty($money)&&!empty($num)){
			    $totalmoney=$totalmoney+($money * $num);
			 }
			}
		  }else{
			$totalmoney=0;
		}
	   if($isajax) { echo $totalmoney; } else{ return $totalmoney;}; 
}

function makesn(){
	return date('YmdHis').substr(implode(NULL, array_map('ord', str_split(substr(uniqid(), 7, 13), 1))), 0, 8);
}

function checktoken($token){
	if(empty($token)||$token!=ugetcookie("loginrnd")){
				messagebox("非法提交!");		
		   }	
 }		 



?>