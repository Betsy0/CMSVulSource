<?php
defined('IN_YUNYECMSAdmin') or exit('No permission.');
core::load_admin_class('admin');
class membergroup extends YUNYE_admin {
	private $db;
	private $admuser;
	function __construct() {
		$this->db = core::load_model('membergroup_model');
		$this->admuser=IsAdmLogin($this->db);
		parent::__construct();
		 if(!getroot('member','membergroup')){
			messagebox(Lan('no_permission'),'back',"warn");			
		 } 
	}
	 //加载首页
	 public function init() {
		  $parnav='<li><a href=\"'.url_admin('init',"membergroup").'\" target=\"maincontent\">系统</a></li><li><a href=\"'.url_admin('init','membergroup').'\" target=\"maincontent\">会员组管理</a></li><li class=\"active\">会员组列表</li>';
		   if(!getroot('users','logs')){
			  messagebox(Lan('no_permission'),'back',"warn");			
		   }
		 $pagesize=20;
		 $sqlquery="select * from `#yunyecms_membergroup`  ";
		 $where=" where  groupname<>'' ";
		 $sqlcnt=" select count(*) from `#yunyecms_membergroup` ";
		 $order=" order by `ordernum` asc ";
		  if(isset($_REQUEST)){
		   if(!empty($_REQUEST["searchkey"])){
		        $searchkey=usafestr(trim($_REQUEST["searchkey"]));
		        $where=$where." and ( `groupname`  like '%{$searchkey}%' )";
			  }
		 }
		 $pagearr=$this->db->pagelist($sqlcnt,$sqlquery,$where,$order,$pagesize);
		 if($pagearr["count"]!=0){
			 $list=$pagearr["query"];
			 $page=$pagearr["page"];
		 }
		 require tpl_adm('membergroup_list');
	  }
	
	
 public function add(){
		   if(!empty($_GET["id"])){
					$parnav='<li><a href=\"'.url_admin('init','membergroup').'\" target=\"maincontent\">会员组管理</a></li><li class=\"active\">修改会员组</li>';
					$id=trim($_GET["id"]);
					 if(!is_numeric($id)){
					   messagebox("会员组参数错误",url_admin('init'));
					 }
					 $rsinfo=$this->db->find("select * from `#yunyecms_membergroup` where `id`= {$id}");
					 if(empty($rsinfo)){
						   messagebox("会员组不存在",$_SERVER['HTTP_REFERER']);			
					  }
					$yyact="edit";
			}else{
				$yyact=yyact_get("add");
				$parnav='<li><a href=\"'.url_admin('init','member').'\" target=\"maincontent\">用户</a></li><li><a href=\"'.url_admin('init','membergroup').'\" target=\"maincontent\">会员组管理</a></li><li class=\"active\">增加会员组</li>';
				$sqlordermax="select max(ordernum) as maxordernum from `#yunyecms_membergroup`";
				$ordermaxquery=$this->db->find($sqlordermax);
				$ordermax=$ordermaxquery["maxordernum"]+1;
				}
	        if(isset($_POST["yyact"])){
				      $_POST=ustripslashes($_POST);
				 	  $data["groupname"]=usafestr(trim($_POST["groupname"]));
				      $data["remark"]=uhtmlspecialchars(trim($_POST["remark"]));
				 	  $data["ordernum"]=usafestr(trim($_POST["ordernum"]));
				 	  $data["groupname_en"]=usafestr(trim($_POST["groupname_en"]));
				 	  $data["remark_en"]=usafestr(trim($_POST["remark_en"]));
				 	  $data["status"]=1;
					  if(empty($data["groupname"])){
							messagebox("会员组名称不能为空，谢谢!");		
					   }
			 if($_POST["yyact"]=="add"){
					 $retres=$this->db->insert($data);
					 if($retres){
								$doing="添加会员组—".$data["groupname"];
								$yyact="Add_MemberGroup";
								insert_admlogs($doing,$yyact);
								messagebox("添加会员组成功！",url_admin('init'),"success");
					 }else{
								messagebox("添加会员组失败！",url_admin('init'),"error");
					 }
			  }
		      if($_POST["yyact"]=="edit"){
					   $id=$_POST["id"];
					   if(!$this->check_exist($id)){
							messagebox("该消息不存在！",url_admin('init'),"warn");
					   }
					   $retres=$this->db->update($data,"membergroup","id={$id}");
						if($retres){
									$doing="更新会员组—".$data["groupname"];
									$yyact="Update_MemberGroup";
									insert_admlogs($doing,$yyact);
									messagebox("会员组更新成功！",url_admin('init'),"success");
						 }else{
									messagebox("会员组更新失败！",url_admin('init'),"error");
						 }
			  }			  
		  }
		require tpl_adm('membergroup_add');
	 }	
	
  public function finaldelete() {
		  if(!getroot('info','del')){
			    messagebox(Lan('no_permission'),'back');			
		   }
            $id = $_REQUEST["id"];
			$id=usafestr(trim($id));
			if(!is_array($id)){
			  $id=compact('id');
			}
			$idarray=$id;
            if (isset($idarray)){
				 $idarray=implode(",",$idarray);
				 $retres =$this->db->delete("membergroup","id in ({$idarray})");
                if ($retres !== false) {
						$yyact="Notice_Del";
						$logcontent['tablename']="membergroup";
						$logcontent['action']=$yyact;
						$logcontent['ids']=serialize($id);
						$logcontent=serialize($logcontent);
						$doing="删除会员组：{$idarray} ";
						insert_admlogs($doing,$yyact,$logcontent);
				    messagebox(Lan('admin_delete_success'),$_SERVER['HTTP_REFERER'],"success");
                } else {
				    messagebox(Lan('admin_delete_error'),$_SERVER['HTTP_REFERER'],"warn");
                }
            } else {
				    messagebox(Lan('admin_delete_error'),$_SERVER['HTTP_REFERER'],"warn");
            }
    }	
	
	
    public function check(){
        parent::infocheck("membergroup",$this->db);
    }	
	
    public function nocheck() {
        parent::infonocheck("membergroup",$this->db);
    }		
	 
	private function check_exist($id) {
		 $id = trim($id);
		 if(empty($id)){
		     return false;
			 }else{
			    if(!is_numeric($id)){
					  return false;
				 }
			  if ($this->db->find("select count(*) as cnt from `#yunyecms_membergroup` where `id`= {$id}")){
				  return true;
			  }				 
		  }
	  }	

	 
}
?>
