<?php
defined('InYUNYECMS')or exit('No permission resources.');
/**
 * session 数据存储
 */
class session
{
    /**
     * 构造函数
     *
     */
    public function __construct()
    {
        session_start();
    }
}

?>