<?php
if (!file_exists('./core/config/config.php')||!file_exists('./data/install.lock')) header("location: ./install");
require './core/config/const.php';
require YUNYECMS_CORE.'init.php';
core::InitApp();
?>