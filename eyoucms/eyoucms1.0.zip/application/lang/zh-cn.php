<?php
return array(
     'hello_EyouCms'  => 'application 你好 EyouCms',
     'I_love_you_EyouCms' => 'application 我爱你 EyouCms',
     'where' => '在 application zh-cn',
);