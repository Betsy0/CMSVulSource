<?php
return array(
     'hello_EyouCms'  => 'application hello EyouCms',
     'I_love_you_EyouCms' => 'application I love you EyouCms',
     'where' => 'in application en-us',    
);