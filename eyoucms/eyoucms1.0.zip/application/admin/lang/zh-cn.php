<?php
return array(
    // 'global'    => include dirname(__FILE__).'/zh-cn/global.php',
    // 'global_success_jump'  => '页面自动 <a id="href" href="%s">跳转</a> 等待时间： ',

    // 'system'    => include dirname(__FILE__).'/zh-cn/system.php',
    // 'system_index_web_desc_notic'    => '还可以输入<em>%s</em>个字',
);