<?php
return array(
    'successful_operation'  => 'Successful operation',
    'operation_failed' => 'operation failed',
	'website_status' => 'Web status',
);