<?php
$_CACHE['apps'] = array (
  1 => 
  array (
    'appid' => '1',
    'type' => 'OTHER',
    'name' => 'bluecms',
    'url' => 'http://localhost/bluecms',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => '',
    'dbcharset' => '',
    'synlogin' => '1',
    'recvnote' => '0',
    'extra' => false,
    'tagtemplates' => '<?xml version="1.0" encoding="ISO-8859-1"?>
<root>
 <item id="template"><![CDATA[]]></item>
</root>',
  ),
  2 => 
  array (
    'appid' => '2',
    'type' => 'OTHER',
    'name' => 'dede',
    'url' => 'http://localhost/dede4',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => '',
    'dbcharset' => '',
    'synlogin' => '1',
    'recvnote' => '0',
    'extra' => false,
    'tagtemplates' => '<?xml version="1.0" encoding="ISO-8859-1"?>
<root>
 <item id="template"><![CDATA[]]></item>
</root>',
  ),
  3 => 
  array (
    'appid' => '3',
    'type' => 'DISCUZ',
    'name' => '������',
    'url' => 'http://localhost/dz7',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => 'gbk',
    'dbcharset' => 'gbk',
    'synlogin' => '1',
    'recvnote' => '1',
    'extra' => false,
    'tagtemplates' => '<?xml version="1.0" encoding="ISO-8859-1"?>
<root>
 <item id="template"><![CDATA[<a href="{url}" target="_blank">{title}</a>]]></item>
 <item id="fields">
 <item id="title"><![CDATA[����]]></item>
 <item id="writer"><![CDATA[����]]></item>
 <item id="pubdate"><![CDATA[ʱ��]]></item>
 <item id="url"><![CDATA[��ַ]]></item>
 </item>
</root>',
  ),
);

?>