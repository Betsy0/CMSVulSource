<?php

define ( 'APP_DEBUG', true );
define('BIND_MODULE','Admin');
define ( 'APP_PATH', './Application/' );
define ('OS_THEME_PATH', './Theme/');
define ( 'RUNTIME_PATH', './Runtime/' );
require './ThinkPHP/ThinkPHP.php';