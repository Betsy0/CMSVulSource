<?php if (!defined('EMLOG_ROOT')) {exit('error!');}?>
<div id="footer"><?php doAction('adm_footer');?></div>
</div>
</div>
</body>
</html>
