<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>XiaoCms</title>
<script src="http://libs.baidu.com/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="../core/img/js/jquery.sobox.min.js"></script>
<script type="text/javascript" src="../core/img/uploadify/jquery.uploadify.min.js?ver=<?php echo microtime(TRUE);?>"></script>
<script type="text/javascript" src="../core/img/js/xiaocms.js"></script>
<link rel="stylesheet" type="text/css" href="./img/xiaocms.css" />
</head>
<body>