<?php return array (
  'file_explan' => 
  array (
    'template|default|' => 
    array (
      'images' => '图片目录',
      'member' => '会员中心模板',
      'category_news.html' => '新闻频道模板',
      'category_product.html' => '产品频道模板',
      'config.php' => '模板备注文件',
      'footer.html' => '通用底部模板',
      'form.html' => '表单模板',
      'header.html' => '通用头部模板',
      'index.html' => '首页模板',
      'left.html' => '内页左侧模板',
      'list_news.html' => '新闻列表模板',
      'list_product.html' => '产品列表模板',
      'page.html' => '单页面模板',
      'search.html' => '搜索模板',
      'show_news.html' => '新闻内容模板',
      'show_product.html' => '产品内容模板',
      'submit.html' => '游客投稿模板',
    ),
  ),
);?>