<?php
if (!defined('IN_XIAOCMS')) exit();
return array (
  'site_name' => 'XiaoCms企业建站版',
  'site_theme' => 'default',
  'site_mobile' => '1',
  'site_title' => 'XiaoCms演示站',
  'site_keywords' => 'xiaocms',
  'site_description' => '欢迎使用xiaocms内容管理系统 官方网站：http://www.xiaocms.com',
  'site_status' => '1|正常
2|头条
3|推荐
0|未审核',
  'site_download_image' => '1',
  'site_watermark' => '0',
  'site_watermark_pos' => '5',
  'member_modelid' => '5',
  'member_register' => '1',
  'member_status' => '1',
  'member_regcode' => '1',
  'member_logincode' => '1',
  'diy_url' => '0',
  'list_url' => '{catdir}/',
  'list_page_url' => '{catdir}/{page}',
  'show_url' => '{catdir}/{id}.html',
  'show_page_url' => '{catdir}/{id}_{page}.html',
  'rand_code' => '045aa962ab5e8a165f18767fa534d926',
);