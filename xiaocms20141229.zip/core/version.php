<?php
define('XIAOCMS_VERSION', 'XiaoCms 企业建站版');
define('XIAOCMS_RELEASE', '20141229');